({
    getFormData: function(component,event,helper,formId){
        var action = component.get("c.getFormGroupByType");
        action.setParams({
            'onboardingFormId' : formId
        });
        
        action.setCallback(this, function(response){
            var state = response.getState();
            var results = response.getReturnValue();
            
            if(state == "SUCCESS" && results){
                component.set("v.formWrapper", results);
                component.set("v.hasReadAccess", results.hasReadAccess);
                component.set("v.licenseList", results.licenseType);
                var onbForm = results.pageWrappers[0].formObject;
                if(onbForm.Status__c != 'Complete' || onbForm.Name == 'ABC Order User Setup'){
                    var lineItems = [];
                    for(var i=0; i<results.pageWrappers.length; i++){
                        for(var j=0; j<results.pageWrappers[i].sectionWrappers.length; j++){
                            var sectionVar = results.pageWrappers[i].sectionWrappers[j];
                            lineItems = lineItems.concat(sectionVar.leftColFields);
                            lineItems = lineItems.concat(sectionVar.rightColFields);
                        }
                    }
                    var onbLineItems = [];
                    for(var i=0;i<lineItems.length;i++){
                        onbLineItems.push(lineItems[i].formLineItem);
                    }
                    
                    component.set("v.onboardingFormLineItems",onbLineItems);
                    
                    /*  
                    if(onbForm.Name == 'CSRA 590 Practitioner Questionnaire'){
                        var indexValue = 0;
                        var licenseList = component.get("v.licenseList");
                        var formLineItem = component.get("v.formLineItem");
                        //alert("Insidde Form--->"+lineItems.length);
                        for(var i=0; i<lineItems.length; i++){
                            alert('Inside 1--->'+lineItems.length);
                            if(lineItems[i].formLineItem.Order__c == formLineItem.Order__c){
                                //alert('Inside 2--->'+formLineItem.Order__c);
                                indexValue = i;
                                break;
                            }
                        }	
                        for(var j = indexValue+1; j<lineItems.length; j++){                    
                            if(lineItems[j].formLineItem.Mapped_Object_Controlling_Field__c != null && 
                               lineItems[j].formLineItem.Mapped_Object_Controlling_Field__c == 'License_Type__c'){
                                //alert('Inside 3--->'+formLineItems[j].formLineItem.Question_Text__c);
                                if(licenseList.length == 0 || licenseList.toString().search(lineItems[j].formLineItem.Mapped_Object_Controlling_Field_Value__c) == -1){
                                    lineItems[j].formLineItem.IsRequired__c = true;
                                    lineItems[j].formLineItem.Show_on_Screen__c = true;
                                }else{
                                    lineItems[j].formLineItem.IsRequired__c = false;
                                    lineItems[j].formLineItem.Show_on_Screen__c = false;
                                }
                            }                    
                            if(lineItems[j].formLineItem.Response_Type__c == 'Add a New Contact'){
                                //alert('Inside 4--->'+formLineItems[j].formLineItem.Question_Text__c);
                                break;
                            }
                        }
                    }*/
                    for(var k=0; k<lineItems.length; k++){
                        if(onbForm.Name == 'AmerisourceBergen Personal Guaranty' && lineItems[k].formLineItem.Response__c == null){
                            var userRes = lineItems[k].formLineItem.Response__c;
                            if(lineItems[k].formLineItem.Question_Text__c == 'Ownership type'){
                                lineItems[k].formLineItem.Response__c = 'Sole proprietorship';
                            }
                        }
                        if(lineItems[k].formLineItem.Response__c == null && onbForm.Name =='Small Credit Program - Owner Combo Form'){
                           if(lineItems[k].formLineItem.Question_Text__c == 'Are you requesting a new payment term or changing your current payment term?'){
                               lineItems[k].formLineItem.Response__c = 'I\'m requesting a new payment term';
                          }
                           if(lineItems[k].formLineItem.Question_Text__c == 'Select a Payment Authorization Type.'){
                               lineItems[k].formLineItem.Response__c = 'Initiate New';
                          }
                        }
                        if(onbForm.Name == 'Additional Account Request'){
                            if(lineItems[k].formLineItem.Question_Text__c == 'Delivery hours'){
								lineItems[k].formLineItem.Show_on_Screen__c = true;
                            }
                        }
                        if(onbForm.Name == 'New Account Information'){
                            var userRes = lineItems[k].formLineItem.Response__c;
                            if(lineItems[k].formLineItem.Question_Text__c =='Is your location 340B eligible?'){
                                if(userRes == 'Yes'){
                                    lineItems[k+1].formLineItem.Show_on_Screen__c = true;
                                    lineItems[k+1].formLineItem.IsRequired__c = true;
                                }else if(userRes == 'No'){
                                    lineItems[k+1].formLineItem.Show_on_Screen__c = false;
                                    lineItems[k+1].formLineItem.IsRequired__c = false;
                                }
                            }
                            if(lineItems[k].formLineItem.Question_Text__c == 'Will AmerisourceBergen be your primary wholesaler?'){
                                if(userRes == 'S'){
                                    lineItems[k+1].formLineItem.Show_on_Screen__c = true;
                                    lineItems[k+1].formLineItem.IsRequired__c = true;
                                    lineItems[k+2].formLineItem.Show_on_Screen__c = true;
                                    lineItems[k+2].formLineItem.IsRequired__c = false;
                                    var asdCourtesyBilling = 'No';
                                    for(var p=k+1;p<lineItems.length;p++){
                                        if(lineItems[p].formLineItem.Question_Text__c == 'Will you be courtesy billing to your Wholesaler?'){
                                            lineItems[p].formLineItem.Show_on_Screen__c = true;
                                            lineItems[p].formLineItem.IsRequired__c = true;
                                            asdCourtesyBilling = lineItems[p].formLineItem.Response__c;
                                            if(asdCourtesyBilling == 'No'){
                                                break;
                                            }
                                        }
                                        if(asdCourtesyBilling == 'Yes'){
                                            if(lineItems[p].formLineItem.Response_Validation__c == '<b>Authorized Agent/ Officer</b>'){
                                                lineItems[p].formLineItem.Show_on_Screen__c = true;
                                                lineItems[p+1].formLineItem.IsRequired__c = true;
                                                lineItems[p+1].formLineItem.Show_on_Screen__c = true;
                                                lineItems[p+2].formLineItem.Show_on_Screen__c = true;
                                                break;
                            				}
                                        }
                                    }
                                }
                            }
                            if(lineItems[k].formLineItem.Question_Text__c == 'Are you a member of a GPO?'){
                                if(userRes == 'Yes'){
                                    lineItems[k+1].formLineItem.Show_on_Screen__c = true;
                                    lineItems[k+1].formLineItem.IsRequired__c = true;
                                }
                            }
                            if(lineItems[k].formLineItem.Question_Text__c == 'Is your location a 340B covered entity?'){
                                if(userRes == 'Yes'){
                                    lineItems[k+1].formLineItem.Show_on_Screen__c = true;
                                    lineItems[k+1].formLineItem.IsRequired__c = false;
                                }
                            }
                            if(lineItems[k].formLineItem.Question_Text__c == 'Is your business going through a change of ownership?'){
                                if(userRes == 'Yes'){
                                    lineItems[k+1].formLineItem.Show_on_Screen__c = true;
                                    lineItems[k+1].formLineItem.IsRequired__c = true;
                                }
                            }
                        }
                    }
                }
                if(onbForm.Last_Visited_Page__c > 0){
                    component.set("v.backButtonLabel", 'Back');
                    component.set("v.selectedStep", onbForm.Last_Visited_Page__c);
                    component.set("v.currentPgWrapper", results.pageWrappers[onbForm.Last_Visited_Page__c]);
                }else{
                    component.set("v.currentPgWrapper", results.pageWrappers[0]);
                }
                component.set("v.totalSteps", results.pageWrappers.length);
                this.disableButtons(component);
            }else{
                var errors = response.getError();
                if (errors) {
                    if (errors[0] && errors[0].message) {
                        console.log("Error message: " + errors[0].message);
                    }
                }
            }
        });
        $A.enqueueAction(action);
    },
    prevNext : function(component,step) {
        component.set("v.selectedStep", step);
        if(step == '-1'){
            this.navigateToFormPage(component);
        }else{
            var res = component.get("v.formWrapper");
            this.disableButtons(component);
            component.set("v.showSpinner", false);
            component.set("v.currentPgWrapper",res.pageWrappers[step]);
        }
    },
    navigateToFormPage : function(component){
        var onbForm = component.get("v.currentPgWrapper").formObject;
        var urlEvent = $A.get("e.force:navigateToURL");
        urlEvent.setParams({
            "url": "/onboarding-form-group/" + onbForm.Onboarding_Form_Group__c
        });
        urlEvent.fire();
    },
    disableButtons : function(component){
        var step = component.get("v.selectedStep");
        var totalSteps = component.get("v.totalSteps");
        if(step===0){
            component.set("v.backButtonLabel", 'Back to Forms');
        }else{
            component.set("v.previousIsDisabled", false);
        }
        if(step === totalSteps-1){
            component.set("v.nextButtonLabel", "Finish and Submit Form");
        }else{
            component.set("v.nextIsDisabled", false);
            component.set("v.nextButtonLabel", "Next");
        }
    },
    requiredValidation: function(component,event,helper){
        var currentPg = component.get("v.currentPgWrapper");
        var lineItems = [];
        var i;
        for(i=0; i<currentPg.sectionWrappers.length; i++){
            var sectionVar =  currentPg.sectionWrappers[i];
            lineItems = lineItems.concat(sectionVar.leftColFields);
            lineItems = lineItems.concat(sectionVar.rightColFields);
        }
        for(i=0; i<lineItems.length; i++){
            if(lineItems[i].formLineItem.Show_on_Screen__c && lineItems[i].formLineItem.IsRequired__c){
                if(lineItems[i].response == null || lineItems[i].response == ''){
                    var toastEvent = $A.get("e.force:showToast");
                    toastEvent.setParams({
                        title : 'Error',
                        message: 'Please fill all the required fields on the page.',
                        type: 'error',
                    });
                    toastEvent.fire();
                    return false;
                }
            }
        }
    },
    updateAccountAndOnboarding: function(component,event,helper,showAuthorizedAgent){
        var step = component.get("v.selectedStep");
        var formWrapper = component.get("v.formWrapper");
        var nextButtonLbl = component.get("v.nextButtonLabel");
        var currentPgWrp = component.get("v.currentPgWrapper");
        var action = component.get("c.populateAccountAndOnboarding");
        action.setParams({
            'frmWrapper' : formWrapper,
            'currenPgWrapper' : currentPgWrp,
            'nextButtonLabel' : nextButtonLbl,
            'lastVisitedPage' : step,
        });
        
        action.setCallback(this, function(response){
            var state = response.getState();
            var results = response.getReturnValue();
            
            if(state == "SUCCESS" && results){
                component.set("v.formWrapper", results);
                var stepNew = component.get("v.selectedStep");
                stepNew = parseInt(stepNew + 1);
                var isModalOpen = component.get("v.isModalOpen");
                if(isModalOpen){
                    var toastEvent = $A.get("e.force:showToast");
                    toastEvent.setParams({
                        title : 'Success',
                        message: 'Form submitted successfully.',
                        type: 'success',
                    });
                    toastEvent.fire();
                    this.navigateToFormPage(component);
                }else{
                    var showOnscreen = false;
                    if(showAuthorizedAgent == 'Yes'){
                        showOnscreen = true;
                    }
                    if(showAuthorizedAgent){
                        var res = component.get("v.formWrapper");
                        var lineItems = [];
                        for(var i=0; i<res.pageWrappers[stepNew].sectionWrappers.length; i++){
                            var sectionVar =  res.pageWrappers[stepNew].sectionWrappers[i];
                            lineItems = lineItems.concat(sectionVar.leftColFields);
                            lineItems = lineItems.concat(sectionVar.rightColFields);
                        }
                        for(var j=0;j<lineItems.length;j++){
                            if(lineItems[j].formLineItem.Response_Validation__c == '<b>Authorized Agent/ Officer</b>'){
                                lineItems[j].formLineItem.Show_on_Screen__c = showOnscreen;
                                lineItems[j+1].formLineItem.IsRequired__c = showOnscreen;
                                lineItems[j+1].formLineItem.Show_on_Screen__c = showOnscreen;
                                lineItems[j+2].formLineItem.Show_on_Screen__c = showOnscreen;
                                break;
                            }
                        }
                        component.set("v.formWrapper",res);
            		}
                    this.prevNext(component, stepNew);
                }
            }else{
                var errors = response.getError();
                if (errors) {
                    if (errors[0] && errors[0].message) {
                        console.log("Error message: " + errors[0].message);
                    }
                }
            }
        });
        $A.enqueueAction(action);
    }
});