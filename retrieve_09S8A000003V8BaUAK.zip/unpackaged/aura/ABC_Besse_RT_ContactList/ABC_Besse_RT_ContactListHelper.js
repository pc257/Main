({
	getLicense: function(component,event,helper,contID,accID) {
		var action = component.get("c.getLicenses");
        
        action.setParams({
            'contID' : contID,
            'accID' : accID
        });
        action.setCallback(this, function(response){
            var state = response.getState();
            var results = response.getReturnValue();           
            
            if(state == "SUCCESS" && results){
                component.set("v.licenseList", results);
                var formLineItems = component.get("v.formLineItems");
                var formLineItem = component.get("v.formLineItem");
                var form = component.get("v.form");
                var indexValue = 0;

                for(var i=0; i<formLineItems.length; i++){
                    if(formLineItems[i].formLineItem.Order__c == formLineItem.Order__c){
                        indexValue = i;
                        break;
                    }
                }
                for(var j = indexValue+1; j<formLineItems.length; j++){
                    if((form.Name == 'CSRA 590 Retail Pharmacy Questionnaire' && formLineItem.Display_Page_Number__c != 14) ||
                   	   (form.Name == 'CSRA 590 Hospital Questionnaire' && formLineItem.Display_Page_Number__c != 12) ||
                   	   (form.Name == 'CSRA 590 Practitioner Questionnaire') || (form.Name == 'Small Credit Program - Owner Combo Form')){                        
                        if(formLineItems[j].formLineItem.Mapped_Object_Controlling_Field__c != null && 
                           formLineItems[j].formLineItem.Mapped_Object_Controlling_Field__c == 'License_Type__c'){
                            if(results.length == 0 || results.toString().search(formLineItems[j].formLineItem.Mapped_Object_Controlling_Field_Value__c) == -1){
                                formLineItems[j].formLineItem.Response__c = '';
                                formLineItems[j].formLineItem.IsRequired__c = true;
                                formLineItems[j].formLineItem.Show_on_Screen__c = true;
                            }else{
                                formLineItems[j].formLineItem.IsRequired__c = false;
                                formLineItems[j].formLineItem.Show_on_Screen__c = false;
                                for(var k=0; k<results.length; k++){
                                    var str = results[k];
                                    if(str.includes('--') && str.split('--')[0] == formLineItems[j].formLineItem.Mapped_Object_Controlling_Field_Value__c){
                                        formLineItems[j].formLineItem.Response__c = str.split('--')[1];
                                        break;
                                    }
                                }
                                component.set("v.formLineItems",formLineItems);
                                component.set("v.formLineItem",formLineItem);
                            }
                        }
                    }

                    if(formLineItems[j].formLineItem.Mapped_Object__c != null &&
                       (formLineItems[j].formLineItem.Mapped_Object__c == 'Contact'|| 
                       formLineItems[j].formLineItem.Mapped_Object__c == 'AccountContactRelation') && 
                       (formLineItems[j].formLineItem.Response_Mapped_Field__c == 'Title'||
                       formLineItems[j].formLineItem.Response_Mapped_Field__c == 'Percentage_of_Ownership__c')){
                        //split and assign response value 
                        for(var m=0; m<results.length; m++){
                            var str = results[m];
                            if(str.includes('--') && str.split('--')[0] == formLineItems[j].formLineItem.Response_Mapped_Field__c){
                                formLineItems[j].formLineItem.Response__c = str.split('--')[1];
                                break;
                            }else{
                                formLineItems[j].formLineItem.Response__c = '';
                            }
                        }
                        if(form.Name !='Small Credit Program - Owner Combo Form'){               
                            if(results.length == 0 || results.toString().search(formLineItems[j].formLineItem.Response_Mapped_Field__c) == -1){
                                formLineItems[j].formLineItem.IsRequired__c = true;
                                formLineItems[j].formLineItem.Show_on_Screen__c = true;
                            }else{
                                formLineItems[j].formLineItem.IsRequired__c = false;
                                formLineItems[j].formLineItem.Show_on_Screen__c = false;
                                formLineItems[j].formLineItem.Response__c = '';
                            }
                        }
                    }
                if((form.Name !='Small Credit Program - Owner Combo Form' && 
                   formLineItems[j].formLineItem.Response_Type__c == 'Add a New Contact') || 
                   (form.Name !='Small Credit Program - Owner Combo Form' &&
                   formLineItems[j].formLineItem.Question_Text__c == 'Percent of Ownership')){
                    break;
                        }
                    }

                component.set("v.formLineItems",formLineItems);
            }else{
                var errors = response.getError();
                if (errors) {
                    if (errors[0] && errors[0].message) {
                        console.log("Error message: " + errors[0].message);
                    }
                }
            }
        });
        $A.enqueueAction(action);
	},
});