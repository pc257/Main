({
	doInit : function(component, event, helper) {
        var pgWrapper = component.get("v.formWrapper");
        var lineItems = [];
        for(var i=0; i < pgWrapper.sectionWrappers.length; i++){
            var sectionVar =  pgWrapper.sectionWrappers[i];
            lineItems = lineItems.concat(sectionVar.leftColFields);
            lineItems = lineItems.concat(sectionVar.rightColFields);
        }
        component.set("v.formLineItems",lineItems);
        var formLineItem = component.get("v.formLineItem");
        var selectedValue = formLineItem.Response__c;
        var storedValues = [];
        if(selectedValue != null && selectedValue != ''){
            storedValues = selectedValue.split(",");
        }
        var startLbl = 'From';
        var endLbl = 'To';
        if(formLineItem.Question_Text__c == 'What are the hours of operation for your business?'){
            startLbl = 'Opening Time';
        	endLbl = 'Closing Time';
        }else if(formLineItem.Question_Text__c == 'What are your earliest and latest delivery receiving hours?'){
            startLbl = 'Earliest';
        	endLbl = 'Latest';
        }
        var days = [];
        var dayOfWeek = {};
        dayOfWeek.weekDayName = 'Monday';
        dayOfWeek.startLabel = startLbl;
		dayOfWeek.endLabel = endLbl;
        if(storedValues != null && storedValues[0] != null){
            var timeVal = storedValues[0].split("-");
            dayOfWeek.startValue = timeVal[0];
            dayOfWeek.endValue = timeVal[1];
        }
        days.push(dayOfWeek);
        dayOfWeek = {};
        dayOfWeek.weekDayName = 'Tuesday';
        dayOfWeek.startLabel = startLbl;
		dayOfWeek.endLabel = endLbl;
        if(storedValues != null && storedValues[1] != null){
            var timeVal = storedValues[1].split("-");
            dayOfWeek.startValue = timeVal[0];
            dayOfWeek.endValue = timeVal[1];
        }
        days.push(dayOfWeek);
        dayOfWeek = {};
        dayOfWeek.weekDayName = 'Wednesday';
        dayOfWeek.startLabel = startLbl;
		dayOfWeek.endLabel = endLbl;
        if(storedValues != null && storedValues[2] != null){
            var timeVal = storedValues[2].split("-");
            dayOfWeek.startValue = timeVal[0];
            dayOfWeek.endValue = timeVal[1];
        }
        days.push(dayOfWeek);
        dayOfWeek = {};
        dayOfWeek.weekDayName = 'Thursday';
        dayOfWeek.startLabel = startLbl;
		dayOfWeek.endLabel = endLbl;
        if(storedValues != null && storedValues[3] != null){
            var timeVal = storedValues[3].split("-");
            dayOfWeek.startValue = timeVal[0];
            dayOfWeek.endValue = timeVal[1];
        }
        days.push(dayOfWeek);
        dayOfWeek = {};
        dayOfWeek.weekDayName = 'Friday';
        dayOfWeek.startLabel = startLbl;
		dayOfWeek.endLabel = endLbl;
        if(storedValues != null && storedValues[4] != null){
            var timeVal = storedValues[4].split("-");
            dayOfWeek.startValue = timeVal[0];
            dayOfWeek.endValue = timeVal[1];
        }
        days.push(dayOfWeek);
        dayOfWeek = {};
        dayOfWeek.weekDayName = 'Saturday';
        dayOfWeek.startLabel = startLbl;
		dayOfWeek.endLabel = endLbl;
        if(storedValues != null && storedValues[5] != null){
            var timeVal = storedValues[5].split("-");
            dayOfWeek.startValue = timeVal[0];
            dayOfWeek.endValue = timeVal[1];
        }
        days.push(dayOfWeek);
        dayOfWeek = {};
        dayOfWeek.weekDayName = 'Sunday';
        dayOfWeek.startLabel = startLbl;
		dayOfWeek.endLabel = endLbl;
        if(storedValues != null && storedValues[6] != null){
            var timeVal = storedValues[6].split("-");
            dayOfWeek.startValue = timeVal[0];
            dayOfWeek.endValue = timeVal[1];
        }
        days.push(dayOfWeek);
        component.set("v.daysOfWeek",days);
	},
    resetOtherDays: function(component, event, helper){
        var currentDayIndex = event.getSource().get("v.name");
        var currentDayLabel = event.getSource().get("v.label");
        var days = component.get("v.daysOfWeek");
        var i;
        var selectedValue = '';
        for(i = 0;i<=currentDayIndex; i++){
            selectedValue = selectedValue + days[i].startValue + '-' + days[i].endValue + ',';
        }
        var formLineItem = component.get("v.formLineItem");
        formLineItem.Response__c = selectedValue;
        component.set("v.formLineItem",formLineItem);
        component.set("v.daysOfWeek",days);
	},
    onCheckGetSameAsValue: function (component, event, helper){
        var formLineItem = component.get("v.formLineItem");
        var formLineItems = component.get("v.formLineItems");
        var dependentQuestion;
        if(formLineItem.Question_Text__c == 'What are your earliest and latest delivery receiving hours?'){
            dependentQuestion = 'What are the hours of operation for your business?';
        }else if(formLineItem.Question_Text__c == 'What are your preferred delivery hours?'){
            dependentQuestion = 'What are your earliest and latest delivery receiving hours?';
        }
        if(dependentQuestion != null){
            for(var i=0; i< formLineItems.length; i++){
                if(formLineItems[i].formLineItem.Question_Text__c == dependentQuestion){
                    formLineItem.Response__c = formLineItems[i].formLineItem.Response__c;
                }
            }
        }
        component.set("v.formLineItems", formLineItems);
        component.set("v.formLineItem", formLineItem);
        var selectedValue = formLineItem.Response__c;
        var storedValues = [];
        if(selectedValue != null && selectedValue != ''){
            storedValues = selectedValue.split(",");
        }
        var days = component.get("v.daysOfWeek");
        if(storedValues != null && storedValues[0] != null){
            var timeVal = storedValues[0].split("-");
            days[0].startValue = timeVal[0];
            days[0].endValue = timeVal[1];
        }
        if(storedValues != null && storedValues[1] != null){
            var timeVal = storedValues[2].split("-");
            days[1].startValue = timeVal[0];
            days[1].endValue = timeVal[1];
        }
        if(storedValues != null && storedValues[2] != null){
            var timeVal = storedValues[2].split("-");
            days[2].startValue = timeVal[0];
            days[2].endValue = timeVal[1];
        }
        if(storedValues != null && storedValues[3] != null){
            var timeVal = storedValues[3].split("-");
            days[3].startValue = timeVal[0];
            days[3].endValue = timeVal[1];
        }
        if(storedValues != null && storedValues[4] != null){
            var timeVal = storedValues[4].split("-");
            days[4].startValue = timeVal[0];
            days[4].endValue = timeVal[1];
        }
        if(storedValues != null && storedValues[5] != null){
            var timeVal = storedValues[5].split("-");
            days[5].startValue = timeVal[0];
            days[5].endValue = timeVal[1];
        }
        if(storedValues != null && storedValues[6] != null){
            var timeVal = storedValues[6].split("-");
            days[6].startValue = timeVal[0];
            days[6].endValue = timeVal[1];
        }
        component.set("v.daysOfWeek",days);
    },
});