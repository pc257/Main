({
    doInit: function(component, event, helper) {
        var isAddAccountForHSnCSP = component.get("v.isAddAccountForHSnCSP");
        var allLineItemsWrapper = component.get("v.allLineItemsWrapper"); 
        var formLineItems = component.get("v.formLineItems");
        var indexValue = component.get("v.indexValue");
        
        if(isAddAccountForHSnCSP == false){
            var shipToEntityResponse = allLineItemsWrapper.pageWrappers[0].sectionWrappers[0].leftColFields[2].formLineItem.Response__c; 
            if(formLineItems[0].formLineItem.Response__c == null || formLineItems[0].formLineItem.Response__c == '' || formLineItems[0].formLineItem.Response__c == undefined){
                formLineItems[0].formLineItem.Response__c = String(shipToEntityResponse);
            }
            component.set("v.previousSelectedValue", shipToEntityResponse);
        }else{
            var shipToEntityResponse = formLineItems[2].formLineItem.Response__c;
            if(formLineItems[16].formLineItem.Response__c == null || formLineItems[16].formLineItem.Response__c == '' || formLineItems[16].formLineItem.Response__c == undefined){
                formLineItems[16].formLineItem.Response__c = String(shipToEntityResponse);
            }
            component.set("v.previousSelectedValue", shipToEntityResponse); 
        }		
    },
    handleChange: function(component, event, helper){
        var indexValue = component.get("v.indexValue");
        var formlineitem = component.get("v.formLineItem");
        var form = component.get("v.form");
        var formLineItems = component.get("v.formLineItems");
        var dependantLI = formlineitem.Response_Validation__c;
        var checkStatus = event.getSource().get("v.checked");
        var previousSelectedValue = component.get("v.previousSelectedValue");
        var action = component.get("c.getAccountDetails");
        action.setParams({"lineItemOrder" : dependantLI, "onbFormId" : form.Id});
            action.setCallback(this, function(response) {
                var state = response.getState();
                if (state === "SUCCESS"){
                    var responseValue = response.getReturnValue();
                    formLineItems[indexValue-1].formLineItem.Response__c = '';
                    formLineItems[indexValue-1].MultiSelectResponse = '';
                    formLineItems[indexValue-1].multiSelectedOption = [];
                    formLineItems[indexValue+1].formLineItem.Response__c = responseValue.BillingStreet;
                    formLineItems[indexValue+2].formLineItem.Response__c = responseValue.BillingCity;
                    formLineItems[indexValue+3].formLineItem.Response__c = responseValue.BillingState;
                    formLineItems[indexValue+4].formLineItem.Response__c = responseValue.BillingPostalCode;
                    if(checkStatus){
						formLineItems[0].formLineItem.Response__c = String(responseValue.Name);            
                    }else{
                        formLineItems[0].formLineItem.Response__c = String(previousSelectedValue);
                    }
                    component.set("v.formLineItems", formLineItems);
                }else{
                }
            });
        $A.enqueueAction(action);
    },
});