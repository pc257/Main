({
    hideBillingAddress: function(component, event, helper){
        var response = component.get("v.response");
        var formWrapper = component.get("v.formWrapper");
        var formLineItems = component.get("v.formLineItems");
        var lineItemsFromOtherSection = component.get("v.lineItemsFromOtherSection");
        var indexValue = component.get("v.indexValue");
        var formLineItem = component.get("v.formLineItem");
        var responseMultiPicklist = component.get("v.responseMultiPicklist");
        var form = component.get("v.form");

        if(responseMultiPicklist == 'Same as Delivery Address' && form.Name == 'New Account Information'){
            var businessUnit = form.Onboarding__r.Onboarding_Customer_Type__c;
            if(businessUnit == 'OSC' || businessUnit == 'ASD'){
             	for(var i=1; i<=5; i++){
                	//formLineItems[indexValue+i].formLineItem.Show_on_Screen__c = false;
                	formLineItems[indexValue+i].formLineItem.Response__c = lineItemsFromOtherSection[i+1].formLineItem.Response__c;
            	}   
            }
            else if(businessUnit == 'Besse'){
                for(var i=1; i<=5; i++){
                	formLineItems[indexValue+i].formLineItem.Response__c = lineItemsFromOtherSection[i].formLineItem.Response__c;
            	}   
            }
        }else if(responseMultiPicklist == 'Same as Business Address' && form.Name == 'Credit Information'){
            for(var i=1; i<=4; i++){
                formLineItems[indexValue+i].formLineItem.Response__c = lineItemsFromOtherSection[i].formLineItem.Response__c;
            }
        }else if(responseMultiPicklist == 'Same as Delivery Address' && form.Name == 'Additional Account Request'){
            //Used Wrapper for getting the lineitems to match and copy to billing address
            formLineItems[indexValue+1].formLineItem.Response__c = false;
            formLineItems[indexValue+1].multiSelectedOption = [];
            var businessUnit = form.Onboarding__r.Onboarding_Customer_Type__c;
            var indexLI = 1;
            if(businessUnit == 'Besse'){
                indexLI = 2;	   
            }else if(businessUnit == 'OSC'){
                indexLI = 0;	   
            }
            for(var i=2; i<=5; i++){
                formLineItems[indexValue+i].formLineItem.Response__c = formWrapper.sectionWrappers[0].leftColFields[i-indexLI].formLineItem.Response__c;
            }
        }
        component.set("v.formLineItems", formLineItems);
    }, //Handle all CSRA forms dependency on multiselect
    CSRA590Dependencies: function(component,event,helper){
        var formLineItems = component.get("v.formLineItems");
        var indexValue = component.get("v.indexValue");
        var formLineItem = component.get("v.formLineItem");
        var responseMultiPicklist = component.get("v.responseMultiPicklist");
        var objString = responseMultiPicklist.toString();
        if(formLineItem.Question_Text__c == 'Please check all that apply to your business activity' || formLineItem.Question_Text__c == 'Which of the following are included in your due diligence processes?'){
            if(responseMultiPicklist.includes('Other')){
                formLineItems[indexValue+1].formLineItem.Show_on_Screen__c = true;
                formLineItems[indexValue+1].formLineItem.IsRequired__c = true;
            }else{
                formLineItems[indexValue+1].formLineItem.Show_on_Screen__c = false;
                formLineItems[indexValue+1].formLineItem.IsRequired__c = false;
           }
        }
        component.set("v.formLineItems", formLineItems);
        if(formLineItem.Question_Text__c == 'Select if you have a current account with any other ABC subsidiary and indicate applicable account number'){
            if(objString.search('Besse') != -1){
                formLineItems[indexValue+1].formLineItem.Show_on_Screen__c = true;
                formLineItems[indexValue+1].formLineItem.IsRequired__c = true;
                component.set("v.formLineItems", formLineItems);
            }else if(objString.search('Besse') == -1){
                formLineItems[indexValue+1].formLineItem.Show_on_Screen__c = false;
                formLineItems[indexValue+1].formLineItem.IsRequired__c = false;
                component.set("v.formLineItems", formLineItems);
            }
            if(objString.search('Oncology') != -1){
                formLineItems[indexValue+2].formLineItem.Show_on_Screen__c = true;
                formLineItems[indexValue+2].formLineItem.IsRequired__c = true;
                component.set("v.formLineItems", formLineItems);
            }else if(objString.search('Oncology') == -1){
                formLineItems[indexValue+2].formLineItem.Show_on_Screen__c = false;
                formLineItems[indexValue+2].formLineItem.IsRequired__c = false;
                component.set("v.formLineItems", formLineItems);
            }
            if(objString.search('MWI') != -1){
                formLineItems[indexValue+3].formLineItem.Show_on_Screen__c = true;
                formLineItems[indexValue+3].formLineItem.IsRequired__c = true;
                component.set("v.formLineItems", formLineItems);
            }else if(objString.search('MWI') == -1){
                formLineItems[indexValue+3].formLineItem.Show_on_Screen__c = false;
                formLineItems[indexValue+3].formLineItem.IsRequired__c = false;
                component.set("v.formLineItems", formLineItems);
            }
            if(objString.search('ASD') != -1){
                formLineItems[indexValue+4].formLineItem.Show_on_Screen__c = true;
                formLineItems[indexValue+4].formLineItem.IsRequired__c = true;
                component.set("v.formLineItems", formLineItems);
            }else if(objString.search('ASD') == -1){
                formLineItems[indexValue+4].formLineItem.Show_on_Screen__c = false;
                formLineItems[indexValue+4].formLineItem.IsRequired__c = false;
                component.set("v.formLineItems", formLineItems);
            }
            if(objString.search('ABDC') != -1){
                formLineItems[indexValue+5].formLineItem.Show_on_Screen__c = true;
                formLineItems[indexValue+5].formLineItem.IsRequired__c = true;
                component.set("v.formLineItems", formLineItems);
            }else if(objString.search('ABDC') == -1){
                formLineItems[indexValue+5].formLineItem.Show_on_Screen__c = false;
                formLineItems[indexValue+5].formLineItem.IsRequired__c = false;
                component.set("v.formLineItems", formLineItems);
            }
            if(objString.search('ICS') != -1){
                formLineItems[indexValue+6].formLineItem.Show_on_Screen__c = true;
                formLineItems[indexValue+6].formLineItem.IsRequired__c = true;
                component.set("v.formLineItems", formLineItems);
            }else if(objString.search('ICS') == -1){
                formLineItems[indexValue+6].formLineItem.Show_on_Screen__c = false;
                formLineItems[indexValue+6].formLineItem.IsRequired__c = false;
                component.set("v.formLineItems", formLineItems);
            }            
        }
        component.set("v.formLineItems", formLineItems);
    },    
});