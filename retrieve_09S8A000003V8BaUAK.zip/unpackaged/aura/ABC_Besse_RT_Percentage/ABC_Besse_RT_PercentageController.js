({
    handleOnBlur : function(component, event, helper) {
/*        var questionText = event.getSource().get("v.label");
        var current_year=new Date().getFullYear();

        if(questionText == 'Owner (s) since'){
            var dateString =  event.getSource().get("v.value");
            var month = dateString.substring(0,2);
            var year = dateString.substring(2,7);

            if((month < 1) || (month >12)){
                var errMessage = 'Please enter valid Month in MM format between 01 to 12';
                var toastEvent = $A.get("e.force:showToast");

                toastEvent.setParams({
                    title : 'Error',
                    message: errMessage,
                    type: 'error',
                });
                toastEvent.fire();

                return false;
            }
            else if((year < 1800) || (year > current_year)){
                var errMessage = 'Please enter valid Year. It should be  >1800 and <= Current Year';
                var toastEvent = $A.get("e.force:showToast");

                toastEvent.setParams({
                    title : 'Error',
                    message: errMessage,
                    type: 'error',
                });
                toastEvent.fire();

                return false;
            }
            else{

                var setDate = month + '/' +year ;
                event.getSource().set("v.value", setDate);
            }
        }*/
        var form = component.get("v.form");
        var formLineItem = component.get("v.formLineItem");
        var formLineItems = component.get("v.formLineItems");
        var formWrapper = component.get("v.formWrapper");
        var lineItems = [];
        var totalPercent = 0;
        var percentCount = 0 ;
        var questionText = event.getSource().get("v.label");
        var selectedOptionValue = event.getSource().get("v.name");
        for(i=0; i<formWrapper.sectionWrappers.length; i++){
            var sectionVar =  formWrapper.sectionWrappers[i];
            lineItems = lineItems.concat(sectionVar.leftColFields);
            lineItems = lineItems.concat(sectionVar.rightColFields);
        }
        if((form.Name == 'CSRA 590 Practitioner Questionnaire' || 
            form.Name == 'CSRA 590 Distributor Questionnaire'  ||
           	form.Name == 'CSRA 590 Retail Pharmacy Questionnaire'||
            form.Name == 'CSRA 590 Hospital Questionnaire')
           	&& form.Status__c != 'Complete'){
            for(var i=0; i<lineItems.length; i++){
                if(lineItems[i].formLineItem.Response_Type__c == 'Percentage' && lineItems[i].formLineItem.Response__c != null){ 
                    if(lineItems[i].formLineItem.HasDependent__c == true){
                        totalPercent += Number(lineItems[i].formLineItem.Response__c);
                        if(lineItems[i+1].formLineItem.Response_Type__c != 'Percentage'){
                            if(lineItems[i+1].formLineItem.Is_Summary__c == true){
                                lineItems[i+1].formLineItem.Response__c = totalPercent+'%';
                                percentCount = totalPercent;
                                totalPercent = 0;
                            }                            
                        }
                    }
                }
            }
            component.set("v.totalPercent", percentCount);
            percentCount = 0;            
            
            if((form.Name == 'CSRA 590 Retail Pharmacy Questionnaire' || 
                form.Name == 'CSRA 590 Practitioner Questionnaire' || 
                form.Name == 'CSRA 590 Hospital Questionnaire') && 
               	questionText == 'Other'){
                if(formLineItems[selectedOptionValue].formLineItem.Response__c == null || formLineItems[selectedOptionValue].formLineItem.Response__c == 0){
                    formLineItems[selectedOptionValue+2].formLineItem.IsRequired__c = false;
                    formLineItems[selectedOptionValue+2].formLineItem.Show_on_Screen__c = false;
                }else{
                    formLineItems[selectedOptionValue+2].formLineItem.IsRequired__c = true;
                    formLineItems[selectedOptionValue+2].formLineItem.Show_on_Screen__c = true;                
                }
            }
            component.set("v.formLineItems",formLineItems);  
            component.set("v.formWrapper",formWrapper);  
        } 
    },
});