({
    handleChange: function (component, event, helper) {
        var selectedOptionVal = event.getParam("value");//this is a numerical value, not sure what this represents
        var selectedOptionValue = event.getSource().get("v.name");//this is the selected text values of the radio

        console.log("selectedOptionVal: " + selectedOptionVal);
        console.log("selectedOptionValue: " + selectedOptionValue);

        var form = component.get("v.form");
        var formLineItem = component.get("v.formLineItem");
        var formLineItems = component.get("v.formLineItems");
        var formWrapper = component.get("v.formWrapper");

        console.log("form Name: " + form.Name);
        console.log("form Status__c: " + form.Status__c);
        if(form.Name == 'New Account Information'){
            helper.handleDependencyForNewAccountInformation(component, formLineItem, formLineItems, selectedOptionVal, selectedOptionValue);
        }
        else if(form.Name == 'Credit Information'){
            helper.handleDependencyForCreditInformation(component, formLineItem, formLineItems, selectedOptionVal, selectedOptionValue);
        }
        if(form.Name == 'AmerisourceBergen Personal Guaranty'){
             helper.handleDependencyForPersonalGuaranty(component, formLineItem, formLineItems, formWrapper, selectedOptionVal, selectedOptionValue);
        }
        if(form.Name == 'CSRA 590 Practitioner Questionnaire'){
             helper.handleDependencyForCSRA590PractitionerQuestionnaire(component, formLineItem, formLineItems, formWrapper, selectedOptionVal, selectedOptionValue);
        }
        if(form.Name == 'CSRA 590 Distributor Questionnaire'){
            helper.handleDependencyForCSRA590DistributorQuestionnaire(component, formLineItem, formLineItems, formWrapper, selectedOptionVal, selectedOptionValue);
        }
        if(form.Name == 'CSRA 590 Hospital Questionnaire'){
            helper.handleDependencyForCSRA590HospitalQuestionnaire(component, formLineItem, formLineItems, formWrapper, selectedOptionVal, selectedOptionValue);
        }
        if(form.Name == 'CSRA 590 Retail Pharmacy Questionnaire'){
            helper.handleDependencyForCSRA590RetailPharmacy(component, formLineItem, formLineItems, formWrapper, selectedOptionVal, selectedOptionValue);
        }
        if(form.Name == 'Small Credit Program - Owner Combo Form'){
            helper.handleDependencyForPaymntTrmSmallCred(component, formLineItem, formLineItems, formWrapper, selectedOptionVal, selectedOptionValue);
        }
        if(form.Name == 'Additional Account Request'){
            helper.handleDependencyForAdditionalAccountRequest(component, formLineItem, formLineItems, formWrapper, selectedOptionVal, selectedOptionValue, form);
        }
    }
});