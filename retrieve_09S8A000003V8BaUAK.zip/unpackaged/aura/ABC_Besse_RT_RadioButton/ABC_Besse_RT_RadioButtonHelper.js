({
    handleDependencyForNewAccountInformation : function(component, formLineItem, formLineItems, selectedOptionVal, selectedOptionValue) {
        var indexValue = component.get("v.indexValue");
        if(formLineItem.Question_Text__c == 'Will AmerisourceBergen be your primary wholesaler?'){
            var userRes = formLineItem.Response__c;
            if(userRes == 'S'){
                formLineItems[indexValue+1].formLineItem.Show_on_Screen__c = true;
                formLineItems[indexValue+1].formLineItem.IsRequired__c = true;
                formLineItems[indexValue+2].formLineItem.Show_on_Screen__c = true;
                formLineItems[indexValue+2].formLineItem.IsRequired__c = false;
                for(var i=indexValue;i<formLineItems.length;i++){
                    if(formLineItems[i].formLineItem.Question_Text__c == 'Will you be courtesy billing to your Wholesaler?'){
                        formLineItems[i].formLineItem.Show_on_Screen__c = true;
                        formLineItems[i].formLineItem.IsRequired__c = true;
                        break;
                    }
                }
            }else{
                formLineItems[indexValue+1].formLineItem.Show_on_Screen__c = false;
                formLineItems[indexValue+1].formLineItem.IsRequired__c = false;
                formLineItems[indexValue+2].formLineItem.Show_on_Screen__c = false;
                formLineItems[indexValue+2].formLineItem.IsRequired__c = false;
            }
        }
        if(formLineItem.Question_Text__c == 'Are you a member of a GPO?'){
            var userRes = formLineItem.Response__c;
            if(userRes == 'Yes'){
                formLineItems[indexValue+1].formLineItem.Show_on_Screen__c = true;
                formLineItems[indexValue+1].formLineItem.IsRequired__c = true;
            }else{
                formLineItems[indexValue+1].formLineItem.Show_on_Screen__c = false;
                formLineItems[indexValue+1].formLineItem.IsRequired__c = false;
            }
        }
        if(formLineItem.Question_Text__c == 'Is your location 340B eligible?'){
            var userRes = formLineItem.Response__c;
            if(userRes == 'Yes'){
                formLineItems[indexValue+1].formLineItem.Show_on_Screen__c = true;
                formLineItems[indexValue+1].formLineItem.IsRequired__c = false;
            }else{
                formLineItems[indexValue+1].formLineItem.Show_on_Screen__c = false;
                formLineItems[indexValue+1].formLineItem.IsRequired__c = false;
            }
        }
        if(formLineItem.Question_Text__c == 'Is your business going through a change of ownership?'){
            var userRes = formLineItem.Response__c;
            if(userRes == 'Yes'){
                formLineItems[indexValue+1].formLineItem.Show_on_Screen__c = true;
                formLineItems[indexValue+1].formLineItem.IsRequired__c = true;
            }else{
                formLineItems[indexValue+1].formLineItem.Show_on_Screen__c = false;
                formLineItems[indexValue+1].formLineItem.IsRequired__c = false;
            }
        }
        if(formLineItem.Question_Text__c == 'If you do not have a Health Industry Number, would you like to request for it?'){
            var userRes = formLineItem.Response__c;
            if(userRes == 'Yes'){
                formLineItems[indexValue+1].formLineItem.Show_on_Screen__c = true;
                formLineItems[indexValue+1].formLineItem.IsRequired__c = false;
            }else{
                formLineItems[indexValue+1].formLineItem.Show_on_Screen__c = false;
                formLineItems[indexValue+1].formLineItem.IsRequired__c = false;
            }
        }
        if(formLineItem.Question_Text__c == 'Will you be ordering controlled substances through AmerisourceBergen?'){
            var userRes = formLineItem.Response__c;
            if(userRes == 'Yes'){
               formLineItems[indexValue+1].formLineItem.IsRequired__c = true;
               formLineItems[indexValue+1].formLineItem.Show_on_Screen__c = true;
            }else{
               formLineItems[indexValue+1].formLineItem.IsRequired__c = false;
               formLineItems[indexValue+1].formLineItem.Show_on_Screen__c = false;
            }
        }
        component.set("v.formLineItems", formLineItems);
    },
    handleDependencyForCreditInformation : function(component, formLineItem, formLineItems, selectedOptionVal, selectedOptionValue) {
        var indexValue = component.get("v.indexValue");
        if(formLineItem.Question_Text__c == 'Will you have another party (example: a parent company, subsidiary, or management company of Applicant) place orders or coordinate payment to AmerisourceBergen on behalf of Applicant?'){
            var userRes = formLineItem.Response__c;
            if(userRes == 'Yes'){
                formLineItems[indexValue+1].formLineItem.Show_on_Screen__c = true;
                formLineItems[indexValue+1].formLineItem.IsRequired__c = true;
            }else{
                formLineItems[indexValue+1].formLineItem.Show_on_Screen__c = false;
                formLineItems[indexValue+1].formLineItem.IsRequired__c = false;
            }
        }
        if(formLineItem.Question_Text__c == 'What payment increment would you prefer?'){
            var userRes = formLineItem.Response__c;
            if(userRes == 'Other'){
                formLineItems[indexValue+1].formLineItem.Show_on_Screen__c = true;
                formLineItems[indexValue+1].formLineItem.IsRequired__c = true;
            }else{
                formLineItems[indexValue+1].formLineItem.Show_on_Screen__c = false;
                formLineItems[indexValue+1].formLineItem.IsRequired__c = false;
            }
        }
        component.set("v.formLineItems", formLineItems);
    },
    handleDependencyForPersonalGuaranty : function(component, formLineItem, formLineItems, formWrapper, selectedOptionVal, selectedOptionValue){
        var indexValue = component.get("v.indexValue");
        if(formLineItem.Question_Text__c == 'Ownership type'){
            var indexOfAddtitinalOwner;
            var showOnScreen = false;
            if(selectedOptionVal == 'Partnership'){
                showOnScreen = true;
            }else if(selectedOptionVal == 'Sole proprietorship'){
                showOnScreen = false;
            }
            for(var i = 10; i < formWrapper.sectionWrappers[1].leftColFields.length; i++){
                formWrapper.sectionWrappers[1].leftColFields[i].formLineItem.Show_on_Screen__c = showOnScreen;
            }                                
            component.set("v.formWrapper",formWrapper);
        }
    },
    handleDependencyForCSRA590PractitionerQuestionnaire : function(component, formLineItem, formLineItems, formWrapper, selectedOptionVal, selectedOptionValue){
        var indexValue = component.get("v.indexValue");
        if(formLineItem.Question_Text__c == 'Select the reason for CSRA review:'){
            var userRes = formLineItem.Response__c;
            if(userRes == 'New customer - Established business changing supplier(s) to ABC or ABC subsidiary'){
                formLineItems[indexValue+1].formLineItem.IsRequired__c = true;
                formLineItems[indexValue+1].formLineItem.Show_on_Screen__c = true;
                formLineItems[indexValue+2].formLineItem.IsRequired__c = false;
                formLineItems[indexValue+2].formLineItem.Show_on_Screen__c = false;
                formLineItems[indexValue+3].formLineItem.IsRequired__c = false;
                formLineItems[indexValue+3].formLineItem.Show_on_Screen__c = false;
                formLineItems[indexValue+4].formLineItem.IsRequired__c = false;
                formLineItems[indexValue+4].formLineItem.Show_on_Screen__c = false;
                formLineItems[indexValue+5].formLineItem.IsRequired__c = false;
                formLineItems[indexValue+5].formLineItem.Show_on_Screen__c = false;
            }else if(userRes == 'New customer - Established business adding ABC or ABC subsidiary as supplier(s)'){
                formLineItems[indexValue+1].formLineItem.IsRequired__c = false;
                formLineItems[indexValue+1].formLineItem.Show_on_Screen__c = false;
                formLineItems[indexValue+2].formLineItem.IsRequired__c = false;
                formLineItems[indexValue+2].formLineItem.Show_on_Screen__c = false;
                formLineItems[indexValue+3].formLineItem.IsRequired__c = true;
                formLineItems[indexValue+3].formLineItem.Show_on_Screen__c = true;
                formLineItems[indexValue+4].formLineItem.IsRequired__c = false;
                formLineItems[indexValue+4].formLineItem.Show_on_Screen__c = false;
                formLineItems[indexValue+5].formLineItem.IsRequired__c = false;
                formLineItems[indexValue+5].formLineItem.Show_on_Screen__c = false;
            }else if(userRes == 'New customer - Start-up business'){
                formLineItems[indexValue+1].formLineItem.IsRequired__c = false;
                formLineItems[indexValue+1].formLineItem.Show_on_Screen__c = false;
                formLineItems[indexValue+2].formLineItem.IsRequired__c = false;
                formLineItems[indexValue+2].formLineItem.Show_on_Screen__c = false;
                formLineItems[indexValue+3].formLineItem.IsRequired__c = false;
                formLineItems[indexValue+3].formLineItem.Show_on_Screen__c = false;
                formLineItems[indexValue+4].formLineItem.IsRequired__c = false;
                formLineItems[indexValue+4].formLineItem.Show_on_Screen__c = false;
                formLineItems[indexValue+5].formLineItem.IsRequired__c = false;
                formLineItems[indexValue+5].formLineItem.Show_on_Screen__c = false;
            }else if(userRes == 'Existing ABC Customer - Change in practitioner'){
                formLineItems[indexValue+1].formLineItem.IsRequired__c = false;
                formLineItems[indexValue+1].formLineItem.Show_on_Screen__c = false;
                formLineItems[indexValue+2].formLineItem.IsRequired__c = true;
                formLineItems[indexValue+2].formLineItem.Show_on_Screen__c = true;
                formLineItems[indexValue+3].formLineItem.IsRequired__c = false;
                formLineItems[indexValue+3].formLineItem.Show_on_Screen__c = false;
                formLineItems[indexValue+4].formLineItem.IsRequired__c = false;
                formLineItems[indexValue+4].formLineItem.Show_on_Screen__c = false;
                formLineItems[indexValue+5].formLineItem.IsRequired__c = false;
                formLineItems[indexValue+5].formLineItem.Show_on_Screen__c = false;
            }else if(userRes == 'Existing ABC Customer - Change in Ownership'){
                formLineItems[indexValue+1].formLineItem.IsRequired__c = false;
                formLineItems[indexValue+1].formLineItem.Show_on_Screen__c = false;
                formLineItems[indexValue+2].formLineItem.IsRequired__c = false;
                formLineItems[indexValue+2].formLineItem.Show_on_Screen__c = false;
                formLineItems[indexValue+3].formLineItem.IsRequired__c = false;
                formLineItems[indexValue+3].formLineItem.Show_on_Screen__c = false;
                formLineItems[indexValue+4].formLineItem.IsRequired__c = true;
                formLineItems[indexValue+4].formLineItem.Show_on_Screen__c = true;
                formLineItems[indexValue+5].formLineItem.IsRequired__c = false;
                formLineItems[indexValue+5].formLineItem.Show_on_Screen__c = false;
            }else if(userRes == 'Existing ABC Customer - Updated CSRA 590 form'){
                formLineItems[indexValue+1].formLineItem.IsRequired__c = false;
                formLineItems[indexValue+1].formLineItem.Show_on_Screen__c = false;
                formLineItems[indexValue+2].formLineItem.IsRequired__c = false;
                formLineItems[indexValue+2].formLineItem.Show_on_Screen__c = false;
                formLineItems[indexValue+3].formLineItem.IsRequired__c = false;
                formLineItems[indexValue+3].formLineItem.Show_on_Screen__c = false;
                formLineItems[indexValue+4].formLineItem.IsRequired__c = false;
                formLineItems[indexValue+4].formLineItem.Show_on_Screen__c = false;
                formLineItems[indexValue+5].formLineItem.IsRequired__c = true;
                formLineItems[indexValue+5].formLineItem.Show_on_Screen__c = true;
            }           
        }else if(formLineItem.Question_Text__c == 'For mid-level practitioners, do you have a supervising physician?'){
            var userRes = formLineItem.Response__c;
            if(userRes == 'Yes'){
                formLineItems[indexValue+1].formLineItem.IsRequired__c = true;
                formLineItems[indexValue+1].formLineItem.Show_on_Screen__c = true;
                formLineItems[indexValue+2].formLineItem.IsRequired__c = true;
                formLineItems[indexValue+2].formLineItem.Show_on_Screen__c = true;
            }else{
                formLineItems[indexValue+1].formLineItem.IsRequired__c = false;
                formLineItems[indexValue+1].formLineItem.Show_on_Screen__c = false;
                formLineItems[indexValue+2].formLineItem.IsRequired__c = false;
                formLineItems[indexValue+2].formLineItem.Show_on_Screen__c = false;
            }
        }else if(formLineItem.Question_Text__c == 'Has the practitioner been sanctioned or disciplined within the last 10 years in any state(s) where they are or have been licensed?'){
            var userRes = formLineItem.Response__c;
            if(userRes == 'Yes'){
                formLineItems[indexValue+1].formLineItem.IsRequired__c = true;
                formLineItems[indexValue+1].formLineItem.Show_on_Screen__c = true;
            }else{
                formLineItems[indexValue+1].formLineItem.IsRequired__c = false;
                formLineItems[indexValue+1].formLineItem.Show_on_Screen__c = false;
            }
        }else if(formLineItem.Question_Text__c == 'Has the practice had a DEA registration or State license or registration suspended, revoked, or disciplined within the last 10 years?'){
            var userRes = formLineItem.Response__c;
            if(userRes == 'Yes'){
                formLineItems[indexValue+1].formLineItem.IsRequired__c = true;
                formLineItems[indexValue+1].formLineItem.Show_on_Screen__c = true;
            }else{
                formLineItems[indexValue+1].formLineItem.IsRequired__c = false;
                formLineItems[indexValue+1].formLineItem.Show_on_Screen__c = false;
            }
        }else if(formLineItem.Question_Text__c == 'Has the owner or any employee of the practice had a DEA registration or State license or registration suspended, revoked, or disciplined within the last 10 years?'){
            var userRes = formLineItem.Response__c;
            if(userRes == 'Yes'){
                formLineItems[indexValue+1].formLineItem.IsRequired__c = true;
                formLineItems[indexValue+1].formLineItem.Show_on_Screen__c = true;
            }else{
                formLineItems[indexValue+1].formLineItem.IsRequired__c = false;
                formLineItems[indexValue+1].formLineItem.Show_on_Screen__c = false;
            }
        }else if(formLineItem.Question_Text__c == 'Has a supplier ever suspended or ceased controlled substance sales to the entity?'){
            var userRes = formLineItem.Response__c;
            if(userRes == 'Yes'){
                formLineItems[indexValue+1].formLineItem.IsRequired__c = true;
                formLineItems[indexValue+1].formLineItem.Show_on_Screen__c = true;
            }else{
                formLineItems[indexValue+1].formLineItem.IsRequired__c = false;
                formLineItems[indexValue+1].formLineItem.Show_on_Screen__c = false;
            }
        }else if(formLineItem.Question_Text__c == 'Will ABC or an ABC subsidiary be this customer\'s primary wholesaler?'){
            var userRes = formLineItem.Response__c;
            if(userRes == 'No'){
                formLineItems[indexValue+1].formLineItem.IsRequired__c = true;
                formLineItems[indexValue+1].formLineItem.Show_on_Screen__c = true;
                formLineItems[indexValue+2].formLineItem.IsRequired__c = true;
                formLineItems[indexValue+2].formLineItem.Show_on_Screen__c = true;
            }else{
                formLineItems[indexValue+1].formLineItem.IsRequired__c = false;
                formLineItems[indexValue+1].formLineItem.Show_on_Screen__c = false;
                formLineItems[indexValue+1].formLineItem.Response__c = '';
                formLineItems[indexValue+2].formLineItem.IsRequired__c = false;
                formLineItems[indexValue+2].formLineItem.Show_on_Screen__c = false;
                formLineItems[indexValue+2].formLineItem.Response__c = '';
            }
        }else if(formLineItem.Question_Text__c == 'Is there a PVA or equivalent with any other wholesaler?'){
            var userRes = formLineItem.Response__c;
            if(userRes == 'Yes'){
                formLineItems[indexValue+1].formLineItem.IsRequired__c = true;
                formLineItems[indexValue+1].formLineItem.Show_on_Screen__c = true;
            }else{
                formLineItems[indexValue+1].formLineItem.IsRequired__c = false;
                formLineItems[indexValue+1].formLineItem.Show_on_Screen__c = false;
            }
        }       
        component.set("v.formLineItems",formLineItems);
    },
    handleDependencyForCSRA590DistributorQuestionnaire: function(component, formLineItem, formLineItems, formWrapper, selectedOptionVal, selectedOptionValue){
        var indexValue = component.get("v.indexValue");
        if(formLineItem.Question_Text__c == 'Has the distributor ever operated under another name?'){
            var userRes = formLineItem.Response__c;
            if(userRes == 'Yes'){
                formLineItems[indexValue+1].formLineItem.IsRequired__c = true;
                formLineItems[indexValue+1].formLineItem.Show_on_Screen__c = true;
            }else{
                formLineItems[indexValue+1].formLineItem.IsRequired__c = false;
                formLineItems[indexValue+1].formLineItem.Show_on_Screen__c = false;
            }
        }else if(formLineItem.Question_Text__c == 'Will ABC or an ABC subsidiary be this customer\'s primary wholesaler?'){
            var userRes = formLineItem.Response__c;
            if(userRes == 'No'){
                formLineItems[indexValue+1].formLineItem.IsRequired__c = true;
                formLineItems[indexValue+1].formLineItem.Show_on_Screen__c = true;
                formLineItems[indexValue+2].formLineItem.Show_on_Screen__c = true;
            }else{
                formLineItems[indexValue+1].formLineItem.IsRequired__c = false;
                formLineItems[indexValue+1].formLineItem.Show_on_Screen__c = false;
                formLineItems[indexValue+2].formLineItem.Show_on_Screen__c = false;
            }
        }else if(formLineItem.Question_Text__c == 'Do you have a PVA or equivalent with any other wholesaler?'){
            var userRes = formLineItem.Response__c;
            if(userRes == 'Yes'){
                formLineItems[indexValue+1].formLineItem.IsRequired__c = true;
                formLineItems[indexValue+1].formLineItem.Show_on_Screen__c = true;
            }else{
                formLineItems[indexValue+1].formLineItem.IsRequired__c = false;
                formLineItems[indexValue+1].formLineItem.Show_on_Screen__c = false;
            }
        }else if(formLineItem.Question_Text__c == 'Select the reason for CSRA review:'){
            var userRes = formLineItem.Response__c;
             if(userRes == 'New customer - Established business changing supplier(s) to ABC or ABC subsidiary'){
                formLineItems[indexValue+1].formLineItem.IsRequired__c = true;
                formLineItems[indexValue+1].formLineItem.Show_on_Screen__c = true;
                formLineItems[indexValue+2].formLineItem.IsRequired__c = false;
                formLineItems[indexValue+2].formLineItem.Show_on_Screen__c = false;
                formLineItems[indexValue+3].formLineItem.IsRequired__c = false;
                formLineItems[indexValue+3].formLineItem.Show_on_Screen__c = false;
                formLineItems[indexValue+4].formLineItem.IsRequired__c = false;
                formLineItems[indexValue+4].formLineItem.Show_on_Screen__c = false;
            }else if(userRes == 'New customer - Established business adding ABC or ABC subsidiary as supplier(s)'){
                formLineItems[indexValue+1].formLineItem.IsRequired__c = false;
                formLineItems[indexValue+1].formLineItem.Show_on_Screen__c = false;
                formLineItems[indexValue+2].formLineItem.IsRequired__c = true;
                formLineItems[indexValue+2].formLineItem.Show_on_Screen__c = true;
                formLineItems[indexValue+3].formLineItem.IsRequired__c = false;
                formLineItems[indexValue+3].formLineItem.Show_on_Screen__c = false;
                formLineItems[indexValue+4].formLineItem.IsRequired__c = false;
                formLineItems[indexValue+4].formLineItem.Show_on_Screen__c = false;
            }else if(userRes == 'Existing ABC Customer - Change in ownership'){
                formLineItems[indexValue+1].formLineItem.IsRequired__c = false;
                formLineItems[indexValue+1].formLineItem.Show_on_Screen__c = false;
                formLineItems[indexValue+2].formLineItem.IsRequired__c = false;
                formLineItems[indexValue+2].formLineItem.Show_on_Screen__c = false;
                formLineItems[indexValue+3].formLineItem.IsRequired__c = true;
                formLineItems[indexValue+3].formLineItem.Show_on_Screen__c = true;
                formLineItems[indexValue+4].formLineItem.IsRequired__c = false;
                formLineItems[indexValue+4].formLineItem.Show_on_Screen__c = false;
            }else if(userRes == 'Existing ABC Customer - Updated CSRA 590 form'){
                formLineItems[indexValue+1].formLineItem.IsRequired__c = false;
                formLineItems[indexValue+1].formLineItem.Show_on_Screen__c = false;
                formLineItems[indexValue+2].formLineItem.IsRequired__c = false;
                formLineItems[indexValue+2].formLineItem.Show_on_Screen__c = false;
                formLineItems[indexValue+3].formLineItem.IsRequired__c = false;
                formLineItems[indexValue+3].formLineItem.Show_on_Screen__c = false;
                formLineItems[indexValue+4].formLineItem.IsRequired__c = true;
                formLineItems[indexValue+4].formLineItem.Show_on_Screen__c = true;
            }else if(userRes == 'New customer - Start-up business'){
                formLineItems[indexValue+1].formLineItem.IsRequired__c = false;
                formLineItems[indexValue+1].formLineItem.Show_on_Screen__c = false;
                formLineItems[indexValue+2].formLineItem.IsRequired__c = false;
                formLineItems[indexValue+2].formLineItem.Show_on_Screen__c = false;
                formLineItems[indexValue+3].formLineItem.IsRequired__c = false;
                formLineItems[indexValue+3].formLineItem.Show_on_Screen__c = false;
                formLineItems[indexValue+4].formLineItem.IsRequired__c = false;
                formLineItems[indexValue+4].formLineItem.Show_on_Screen__c = false;
            }    
        }else if(formLineItem.Question_Text__c == 'Does this distributor export?'){
            var userRes = formLineItem.Response__c;
            if(userRes == 'Yes'){
                formLineItems[indexValue+1].formLineItem.IsRequired__c = true;
                formLineItems[indexValue+1].formLineItem.Show_on_Screen__c = true;
            }else{
                formLineItems[indexValue+1].formLineItem.IsRequired__c = false;
                formLineItems[indexValue+1].formLineItem.Show_on_Screen__c = false;
            }
        }else if(formLineItem.Question_Text__c == 'Are any of the owners a licensed pharmacist or prescribing physician?'){
            var userRes = formLineItem.Response__c;
            if(userRes == 'Yes'){
                formLineItems[indexValue+1].formLineItem.IsRequired__c = true;
                formLineItems[indexValue+1].formLineItem.Show_on_Screen__c = true;
            }else{
                formLineItems[indexValue+1].formLineItem.IsRequired__c = false;
                formLineItems[indexValue+1].formLineItem.Show_on_Screen__c = false;
            }
        }else if(formLineItem.Question_Text__c == 'Are any of the owners associated with or own another distributor?'){
            var userRes = formLineItem.Response__c;
            if(userRes == 'Yes'){
                formLineItems[indexValue+1].formLineItem.IsRequired__c = true;
                formLineItems[indexValue+1].formLineItem.Show_on_Screen__c = true;
            }else{
                formLineItems[indexValue+1].formLineItem.IsRequired__c = false;
                formLineItems[indexValue+1].formLineItem.Show_on_Screen__c = false;
            }
        }else if(formLineItem.Question_Text__c == 'Has the distributor had a DEA registration or state license/registration (including any state where the distributor does business) suspended, revoked or disciplined within the last 10 years?'){
            var userRes = formLineItem.Response__c;
            if(userRes == 'Yes'){
                formLineItems[indexValue+1].formLineItem.IsRequired__c = true;
                formLineItems[indexValue+1].formLineItem.Show_on_Screen__c = true;
            }else{
                formLineItems[indexValue+1].formLineItem.IsRequired__c = false;
                formLineItems[indexValue+1].formLineItem.Show_on_Screen__c = false;
            }
        }else if(formLineItem.Question_Text__c == 'Is this distributor currently part of an active investigation at the federal, state or local level?'){
            var userRes = formLineItem.Response__c;
            if(userRes == 'Yes'){
                formLineItems[indexValue+1].formLineItem.IsRequired__c = true;
                formLineItems[indexValue+1].formLineItem.Show_on_Screen__c = true;
            }else{
                formLineItems[indexValue+1].formLineItem.IsRequired__c = false;
                formLineItems[indexValue+1].formLineItem.Show_on_Screen__c = false;
            }
        }else if(formLineItem.Question_Text__c == 'Has a supplier ever suspended or ceased controlled substance sales to the distributor?'){
            var userRes = formLineItem.Response__c;
            if(userRes == 'Yes'){
                formLineItems[indexValue+1].formLineItem.IsRequired__c = true;
                formLineItems[indexValue+1].formLineItem.Show_on_Screen__c = true;
            }else{
                formLineItems[indexValue+1].formLineItem.IsRequired__c = false;
                formLineItems[indexValue+1].formLineItem.Show_on_Screen__c = false;
            }
        }else if(formLineItem.Question_Text__c == 'Has the owner, family member, or any employee of the distributor had a DEA registration or state license/registration suspended, revoked or disciplined within the last 10 years?'){
            var userRes = formLineItem.Response__c;
            if(userRes == 'Yes'){
                formLineItems[indexValue+1].formLineItem.IsRequired__c = true;
                formLineItems[indexValue+1].formLineItem.Show_on_Screen__c = true;
            }else{
                formLineItems[indexValue+1].formLineItem.IsRequired__c = false;
                formLineItems[indexValue+1].formLineItem.Show_on_Screen__c = false;
            }
        }else if(formLineItem.Question_Text__c == 'Are other businesses or business activities located at the same location (retail pharmacy, etc.)?'){
            var userRes = formLineItem.Response__c;
            if(userRes == 'Yes'){
                formLineItems[indexValue+1].formLineItem.IsRequired__c = true;
                formLineItems[indexValue+1].formLineItem.Show_on_Screen__c = true;
            }else{
                formLineItems[indexValue+1].formLineItem.IsRequired__c = false;
                formLineItems[indexValue+1].formLineItem.Show_on_Screen__c = false;
            }
        }else if(formLineItem.Question_Text__c == 'Does the distributor service pain management clinics/physicians?'){
            var userRes = formLineItem.Response__c;
            if(userRes == 'Yes'){
                formLineItems[indexValue+1].formLineItem.IsRequired__c = true;
                formLineItems[indexValue+1].formLineItem.Show_on_Screen__c = true;
            }else{
                formLineItems[indexValue+1].formLineItem.IsRequired__c = false;
                formLineItems[indexValue+1].formLineItem.Show_on_Screen__c = false;
            }
        }
        component.set("v.formLineItems",formLineItems);
    },
    handleDependencyForCSRA590HospitalQuestionnaire: function(component, formLineItem, formLineItems, formWrapper, selectedOptionVal, selectedOptionValue){
        var indexValue = component.get("v.indexValue");
        if(formLineItem.Question_Text__c == 'Will ABC or an ABC subsidiary be this customer\'s primary wholesaler?'){
            var userRes = formLineItem.Response__c;
            if(userRes == 'No'){
                formLineItems[indexValue+1].formLineItem.IsRequired__c = true;
                formLineItems[indexValue+1].formLineItem.Show_on_Screen__c = true;
                formLineItems[indexValue+2].formLineItem.IsRequired__c = true;
                formLineItems[indexValue+2].formLineItem.Show_on_Screen__c = true;
            }else{
                formLineItems[indexValue+1].formLineItem.IsRequired__c = false;
                formLineItems[indexValue+1].formLineItem.Show_on_Screen__c = false;
                formLineItems[indexValue+2].formLineItem.IsRequired__c = false;
                formLineItems[indexValue+2].formLineItem.Show_on_Screen__c = false;
            }
        }else if(formLineItem.Question_Text__c == 'Is there a PVA or equivalent with any other wholesaler?'){
            var userRes = formLineItem.Response__c;
            if(userRes == 'Yes'){
                formLineItems[indexValue+1].formLineItem.IsRequired__c = true;
                formLineItems[indexValue+1].formLineItem.Show_on_Screen__c = true;
            }else{
                formLineItems[indexValue+1].formLineItem.IsRequired__c = false;
                formLineItems[indexValue+1].formLineItem.Show_on_Screen__c = false; 
            }
        }else if(formLineItem.Question_Text__c == 'Select the reason for CSRA review:'){
            var userRes = formLineItem.Response__c;
            if(userRes == 'New customer - Established business changing supplier(s) to ABC or ABC subsidiary'){
                formLineItems[indexValue+1].formLineItem.IsRequired__c = true;
                formLineItems[indexValue+1].formLineItem.Show_on_Screen__c = true;
                formLineItems[indexValue+2].formLineItem.IsRequired__c = false;
                formLineItems[indexValue+2].formLineItem.Show_on_Screen__c = false;
                formLineItems[indexValue+3].formLineItem.IsRequired__c = false;
                formLineItems[indexValue+3].formLineItem.Show_on_Screen__c = false;
                formLineItems[indexValue+4].formLineItem.IsRequired__c = false;
                formLineItems[indexValue+4].formLineItem.Show_on_Screen__c = false;
                formLineItems[indexValue+5].formLineItem.IsRequired__c = false;
                formLineItems[indexValue+5].formLineItem.Show_on_Screen__c = false;
            }else if(userRes == 'New customer - Established business adding ABC or ABC subsidiary as supplier(s)'){
                formLineItems[indexValue+1].formLineItem.IsRequired__c = false;
                formLineItems[indexValue+1].formLineItem.Show_on_Screen__c = false;
                formLineItems[indexValue+2].formLineItem.IsRequired__c = true;
                formLineItems[indexValue+2].formLineItem.Show_on_Screen__c = true;
                formLineItems[indexValue+3].formLineItem.IsRequired__c = false;
                formLineItems[indexValue+3].formLineItem.Show_on_Screen__c = false;
                formLineItems[indexValue+4].formLineItem.IsRequired__c = false;
                formLineItems[indexValue+4].formLineItem.Show_on_Screen__c = false;
                formLineItems[indexValue+5].formLineItem.IsRequired__c = false;
                formLineItems[indexValue+5].formLineItem.Show_on_Screen__c = false;
            }else if(userRes == 'New customer - Start-up business'){
                formLineItems[indexValue+1].formLineItem.IsRequired__c = false;
                formLineItems[indexValue+1].formLineItem.Show_on_Screen__c = false;
                formLineItems[indexValue+2].formLineItem.IsRequired__c = false;
                formLineItems[indexValue+2].formLineItem.Show_on_Screen__c = false;
                formLineItems[indexValue+3].formLineItem.IsRequired__c = false;
                formLineItems[indexValue+3].formLineItem.Show_on_Screen__c = false;
                formLineItems[indexValue+4].formLineItem.IsRequired__c = false;
                formLineItems[indexValue+4].formLineItem.Show_on_Screen__c = false;
                formLineItems[indexValue+5].formLineItem.IsRequired__c = false;
                formLineItems[indexValue+5].formLineItem.Show_on_Screen__c = false;
            }else if(userRes == 'Existing ABC Customer - Change in ownership'){
                formLineItems[indexValue+1].formLineItem.IsRequired__c = false;
                formLineItems[indexValue+1].formLineItem.Show_on_Screen__c = false;
                formLineItems[indexValue+2].formLineItem.IsRequired__c = false;
                formLineItems[indexValue+2].formLineItem.Show_on_Screen__c = false;
                formLineItems[indexValue+3].formLineItem.IsRequired__c = true;
                formLineItems[indexValue+3].formLineItem.Show_on_Screen__c = true;
                formLineItems[indexValue+4].formLineItem.IsRequired__c = false;
                formLineItems[indexValue+4].formLineItem.Show_on_Screen__c = false;
                formLineItems[indexValue+5].formLineItem.IsRequired__c = false;
                formLineItems[indexValue+5].formLineItem.Show_on_Screen__c = false;
            }else if(userRes == 'Existing ABC Customer - Additional account'){
                formLineItems[indexValue+1].formLineItem.IsRequired__c = false;
                formLineItems[indexValue+1].formLineItem.Show_on_Screen__c = false;
                formLineItems[indexValue+2].formLineItem.IsRequired__c = false;
                formLineItems[indexValue+2].formLineItem.Show_on_Screen__c = false;
                formLineItems[indexValue+3].formLineItem.IsRequired__c = false;
                formLineItems[indexValue+3].formLineItem.Show_on_Screen__c = false;
                formLineItems[indexValue+4].formLineItem.IsRequired__c = true;
                formLineItems[indexValue+4].formLineItem.Show_on_Screen__c = true;
                formLineItems[indexValue+5].formLineItem.IsRequired__c = false;
                formLineItems[indexValue+5].formLineItem.Show_on_Screen__c = false;
            }else if(userRes == 'Existing ABC Customer - Updated CSRA 590 form'){
                formLineItems[indexValue+1].formLineItem.IsRequired__c = false;
                formLineItems[indexValue+1].formLineItem.Show_on_Screen__c = false;
                formLineItems[indexValue+2].formLineItem.IsRequired__c = false;
                formLineItems[indexValue+2].formLineItem.Show_on_Screen__c = false;
                formLineItems[indexValue+3].formLineItem.IsRequired__c = false;
                formLineItems[indexValue+3].formLineItem.Show_on_Screen__c = false;
                formLineItems[indexValue+4].formLineItem.IsRequired__c = false;
                formLineItems[indexValue+4].formLineItem.Show_on_Screen__c = false;
                formLineItems[indexValue+5].formLineItem.IsRequired__c = true;
                formLineItems[indexValue+5].formLineItem.Show_on_Screen__c = true;
            }
        }else if(formLineItem.Question_Text__c == 'Please check all that apply to your business activity'){
            var userRes = formLineItem.Response__c;
            if(userRes == 'Other'){
                formLineItems[indexValue+1].formLineItem.IsRequired__c = true;
                formLineItems[indexValue+1].formLineItem.Show_on_Screen__c = true;
            }else{
                formLineItems[indexValue+1].formLineItem.IsRequired__c = false;
                formLineItems[indexValue+1].formLineItem.Show_on_Screen__c = false; 
            }
        }else if(formLineItem.Question_Text__c == 'Has a supplier ever suspended, reduced, or ceased controlled substance to the pharmacy?'){
            var userRes = formLineItem.Response__c;
            if(userRes == 'Yes'){
                formLineItems[indexValue+1].formLineItem.IsRequired__c = true;
                formLineItems[indexValue+1].formLineItem.Show_on_Screen__c = true;
            }else{
                formLineItems[indexValue+1].formLineItem.IsRequired__c = false;
                formLineItems[indexValue+1].formLineItem.Show_on_Screen__c = false; 
            }
        }else if(formLineItem.Question_Text__c == 'Is this hospital pharmacy currently part of an active investigation at the Federal, State or Local Level?'){
            var userRes = formLineItem.Response__c;
            if(userRes == 'Yes'){
                formLineItems[indexValue+1].formLineItem.IsRequired__c = true;
                formLineItems[indexValue+1].formLineItem.Show_on_Screen__c = true;
            }else{
                formLineItems[indexValue+1].formLineItem.IsRequired__c = false;
                formLineItems[indexValue+1].formLineItem.Show_on_Screen__c = false; 
            }
        }else if(formLineItem.Question_Text__c == 'Has the hospital pharmacy had a DEA registration or state license/registration suspended, revoked or disciplined within the last 10 years?'){
            var userRes = formLineItem.Response__c;
            if(userRes == 'Yes'){
                formLineItems[indexValue+1].formLineItem.IsRequired__c = true;
                formLineItems[indexValue+1].formLineItem.Show_on_Screen__c = true;
            }else{
                formLineItems[indexValue+1].formLineItem.IsRequired__c = false;
                formLineItems[indexValue+1].formLineItem.Show_on_Screen__c = false; 
            }
        }else if(formLineItem.Question_Text__c == 'Has any employee of the hospital pharmacy had a state license/registration suspended, revoked or disciplined within the last 10 years?'){
            var userRes = formLineItem.Response__c;
            if(userRes == 'Yes'){
                formLineItems[indexValue+1].formLineItem.IsRequired__c = true;
                formLineItems[indexValue+1].formLineItem.Show_on_Screen__c = true;
            }else{
                formLineItems[indexValue+1].formLineItem.IsRequired__c = false;
                formLineItems[indexValue+1].formLineItem.Show_on_Screen__c = false; 
            }
        }else if(formLineItem.Question_Text__c == 'Are you aware of any disciplinary actions/sanctions taken at any time against any of the above practitioners?'){
            var userRes = formLineItem.Response__c;
            if(userRes == 'Yes'){
                formLineItems[indexValue+1].formLineItem.IsRequired__c = true;
                formLineItems[indexValue+1].formLineItem.Show_on_Screen__c = true;
            }else{
                formLineItems[indexValue+1].formLineItem.IsRequired__c = false;
                formLineItems[indexValue+1].formLineItem.Show_on_Screen__c = false; 
            }
        }
        component.set("v.formLineItems",formLineItems);
    },
    handleDependencyForCSRA590RetailPharmacy: function(component, formLineItem, formLineItems, formWrapper, selectedOptionVal, selectedOptionValue){
        var indexValue = component.get("v.indexValue");
        if(formLineItem.Question_Text__c == 'Will ABC or an ABC subsidiary be this customer\'s primary wholesaler?'){
            var userRes = formLineItem.Response__c;
            if(userRes == 'No'){
                formLineItems[indexValue+1].formLineItem.IsRequired__c = true;
                formLineItems[indexValue+1].formLineItem.Show_on_Screen__c = true;
                formLineItems[indexValue+2].formLineItem.IsRequired__c = true;
                formLineItems[indexValue+2].formLineItem.Show_on_Screen__c = true;
            }else{
                formLineItems[indexValue+1].formLineItem.IsRequired__c = false;
                formLineItems[indexValue+1].formLineItem.Show_on_Screen__c = false;
                formLineItems[indexValue+2].formLineItem.IsRequired__c = false;
                formLineItems[indexValue+2].formLineItem.Show_on_Screen__c = false;
            }
        }else if(formLineItem.Question_Text__c == 'Do you have a Signed Prime Vendor agreement?'){
            var userRes = formLineItem.Response__c;
            if(userRes == 'Yes'){
                formLineItems[indexValue+1].formLineItem.IsRequired__c = true;
                formLineItems[indexValue+1].formLineItem.Show_on_Screen__c = true;
            }else{
                formLineItems[indexValue+1].formLineItem.IsRequired__c = false;
                formLineItems[indexValue+1].formLineItem.Show_on_Screen__c = false;
            }
        }else if(formLineItem.Question_Text__c == 'Do you have a PVA or equivalent with any other wholesaler?'){
            var userRes = formLineItem.Response__c;
            if(userRes == 'Yes'){
                formLineItems[indexValue+1].formLineItem.IsRequired__c = true;
                formLineItems[indexValue+1].formLineItem.Show_on_Screen__c = true;
            }else{
                formLineItems[indexValue+1].formLineItem.IsRequired__c = false;
                formLineItems[indexValue+1].formLineItem.Show_on_Screen__c = false;
            }
        }else if(formLineItem.Question_Text__c == 'Select the reason for CSRA review:'){
            var userRes = formLineItem.Response__c;
            if(userRes == 'New customer - Start-up business'){
                formLineItems[indexValue+1].formLineItem.IsRequired__c = false;
                formLineItems[indexValue+1].formLineItem.Show_on_Screen__c = false;
                formLineItems[indexValue+2].formLineItem.IsRequired__c = false;
                formLineItems[indexValue+2].formLineItem.Show_on_Screen__c = false;
                formLineItems[indexValue+3].formLineItem.IsRequired__c = false;
                formLineItems[indexValue+3].formLineItem.Show_on_Screen__c = false;
                formLineItems[indexValue+4].formLineItem.IsRequired__c = false;
                formLineItems[indexValue+4].formLineItem.Show_on_Screen__c = false;
                formLineItems[indexValue+5].formLineItem.IsRequired__c = false;
                formLineItems[indexValue+5].formLineItem.Show_on_Screen__c = false;;
            }else if(userRes == 'New customer - Established business changing supplier(s) to ABC or ABC subsidiary'){
                formLineItems[indexValue+1].formLineItem.IsRequired__c = true;
                formLineItems[indexValue+1].formLineItem.Show_on_Screen__c = true;
                formLineItems[indexValue+2].formLineItem.IsRequired__c = false;
                formLineItems[indexValue+2].formLineItem.Show_on_Screen__c = false;
                formLineItems[indexValue+3].formLineItem.IsRequired__c = false;
                formLineItems[indexValue+3].formLineItem.Show_on_Screen__c = false;
                formLineItems[indexValue+4].formLineItem.IsRequired__c = false;
                formLineItems[indexValue+4].formLineItem.Show_on_Screen__c = false;
                formLineItems[indexValue+5].formLineItem.IsRequired__c = false;
                formLineItems[indexValue+5].formLineItem.Show_on_Screen__c = false;
            }else if(userRes == 'New customer - Established business adding ABC or ABC subsidiary as supplier(s)'){
                formLineItems[indexValue+1].formLineItem.IsRequired__c = false;
                formLineItems[indexValue+1].formLineItem.Show_on_Screen__c = false;
                formLineItems[indexValue+2].formLineItem.IsRequired__c = true;
                formLineItems[indexValue+2].formLineItem.Show_on_Screen__c = true;
                formLineItems[indexValue+3].formLineItem.IsRequired__c = false;
                formLineItems[indexValue+3].formLineItem.Show_on_Screen__c = false;
                formLineItems[indexValue+4].formLineItem.IsRequired__c = false;
                formLineItems[indexValue+4].formLineItem.Show_on_Screen__c = false;
                formLineItems[indexValue+5].formLineItem.IsRequired__c = false;
                formLineItems[indexValue+5].formLineItem.Show_on_Screen__c = false;
            }else if(userRes == 'Existing ABC Customer - Change in ownership'){
                formLineItems[indexValue+1].formLineItem.IsRequired__c = false;
                formLineItems[indexValue+1].formLineItem.Show_on_Screen__c = false;
                formLineItems[indexValue+2].formLineItem.IsRequired__c = false;
                formLineItems[indexValue+2].formLineItem.Show_on_Screen__c = false;
                formLineItems[indexValue+3].formLineItem.IsRequired__c = true;
                formLineItems[indexValue+3].formLineItem.Show_on_Screen__c = true;
                formLineItems[indexValue+4].formLineItem.IsRequired__c = false;
                formLineItems[indexValue+4].formLineItem.Show_on_Screen__c = false;
                formLineItems[indexValue+5].formLineItem.IsRequired__c = false;
                formLineItems[indexValue+5].formLineItem.Show_on_Screen__c = false;
            }else if(userRes == 'Existing ABC Customer - Additional account'){
                formLineItems[indexValue+1].formLineItem.IsRequired__c = false;
                formLineItems[indexValue+1].formLineItem.Show_on_Screen__c = false;
                formLineItems[indexValue+2].formLineItem.IsRequired__c = false;
                formLineItems[indexValue+2].formLineItem.Show_on_Screen__c = false;
                formLineItems[indexValue+3].formLineItem.IsRequired__c = false;
                formLineItems[indexValue+3].formLineItem.Show_on_Screen__c = false;
                formLineItems[indexValue+4].formLineItem.IsRequired__c = true;
                formLineItems[indexValue+4].formLineItem.Show_on_Screen__c = true;
                formLineItems[indexValue+5].formLineItem.IsRequired__c = false;
                formLineItems[indexValue+5].formLineItem.Show_on_Screen__c = false;
            }else if(userRes == 'Existing ABC Customer - Updated CSRA 590 form'){
                formLineItems[indexValue+1].formLineItem.IsRequired__c = false;
                formLineItems[indexValue+1].formLineItem.Show_on_Screen__c = false;
                formLineItems[indexValue+2].formLineItem.IsRequired__c = false;
                formLineItems[indexValue+2].formLineItem.Show_on_Screen__c = false;
                formLineItems[indexValue+3].formLineItem.IsRequired__c = false;
                formLineItems[indexValue+3].formLineItem.Show_on_Screen__c = false;
                formLineItems[indexValue+4].formLineItem.IsRequired__c = false;
                formLineItems[indexValue+4].formLineItem.Show_on_Screen__c = false;
                formLineItems[indexValue+5].formLineItem.IsRequired__c = true;
                formLineItems[indexValue+5].formLineItem.Show_on_Screen__c = true;
            }
            
        }else if(formLineItem.Question_Text__c == 'Are any of the owners associated with or do they own other pharmacies?'){
            var userRes = formLineItem.Response__c;
            if(userRes == 'Yes'){
                formLineItems[indexValue+1].formLineItem.IsRequired__c = true;
                formLineItems[indexValue+1].formLineItem.Show_on_Screen__c = true;
            }else{
                formLineItems[indexValue+1].formLineItem.IsRequired__c = false;
                formLineItems[indexValue+1].formLineItem.Show_on_Screen__c = false;
            }
        }else if(formLineItem.Question_Text__c == 'Are any of the owners a licensed pharmacist?'){
            var userRes = formLineItem.Response__c;
            if(userRes == 'Yes'){
                formLineItems[indexValue+1].formLineItem.IsRequired__c = true;
                formLineItems[indexValue+1].formLineItem.Show_on_Screen__c = true;
            }else{
                formLineItems[indexValue+1].formLineItem.IsRequired__c = false;
                formLineItems[indexValue+1].formLineItem.Show_on_Screen__c = false;
            }
        }else if(formLineItem.Question_Text__c == 'Are any of the owners a prescribing physician at this pharmacy?'){
            var userRes = formLineItem.Response__c;
            if(userRes == 'Yes'){
                formLineItems[indexValue+1].formLineItem.IsRequired__c = true;
                formLineItems[indexValue+1].formLineItem.Show_on_Screen__c = true;
            }else{
                formLineItems[indexValue+1].formLineItem.IsRequired__c = false;
                formLineItems[indexValue+1].formLineItem.Show_on_Screen__c = false;
            }
        }else if(formLineItem.Question_Text__c == 'Has a supplier ever suspended or ceased controlled substance sales to the pharmacy?'){
            var userRes = formLineItem.Response__c;
            if(userRes == 'Yes'){
                formLineItems[indexValue+1].formLineItem.IsRequired__c = true;
                formLineItems[indexValue+1].formLineItem.Show_on_Screen__c = true;
            }else{
                formLineItems[indexValue+1].formLineItem.IsRequired__c = false;
                formLineItems[indexValue+1].formLineItem.Show_on_Screen__c = false;
            }
        }else if(formLineItem.Question_Text__c == 'Is this pharmacy currently part of an active investigation at the Federal, State or Local level?'){
            var userRes = formLineItem.Response__c;
            if(userRes == 'Yes'){
                formLineItems[indexValue+1].formLineItem.IsRequired__c = true;
                formLineItems[indexValue+1].formLineItem.Show_on_Screen__c = true;
            }else{
                formLineItems[indexValue+1].formLineItem.IsRequired__c = false;
                formLineItems[indexValue+1].formLineItem.Show_on_Screen__c = false;
            }
        }else if(formLineItem.Question_Text__c == 'Has the pharmacy had a DEA registration or state license/registration suspended, revoked or disciplined within the last 10 years?'){
            var userRes = formLineItem.Response__c;
            if(userRes == 'Yes'){
                formLineItems[indexValue+1].formLineItem.IsRequired__c = true;
                formLineItems[indexValue+1].formLineItem.Show_on_Screen__c = true;
            }else{
                formLineItems[indexValue+1].formLineItem.IsRequired__c = false;
                formLineItems[indexValue+1].formLineItem.Show_on_Screen__c = false;
            }
        }else if(formLineItem.Question_Text__c == 'Has the PIC been sanctioned and/or disciplined within the last 10 years in any state(s) where they were licensed as a pharmacist?'){
            var userRes = formLineItem.Response__c;
            if(userRes == 'Yes'){
                formLineItems[indexValue+1].formLineItem.IsRequired__c = true;
                formLineItems[indexValue+1].formLineItem.Show_on_Screen__c = true;
            }else{
                formLineItems[indexValue+1].formLineItem.IsRequired__c = false;
                formLineItems[indexValue+1].formLineItem.Show_on_Screen__c = false;
            }
        }else if(formLineItem.Question_Text__c == 'Has the owner, family member, or any employee of the pharmacy had a DEA registration or state license/registration suspended, revoked or disciplined within the last 10 years?'){
            var userRes = formLineItem.Response__c;
            if(userRes == 'Yes'){
                formLineItems[indexValue+1].formLineItem.IsRequired__c = true;
                formLineItems[indexValue+1].formLineItem.Show_on_Screen__c = true;
            }else{
                formLineItems[indexValue+1].formLineItem.IsRequired__c = false;
                formLineItems[indexValue+1].formLineItem.Show_on_Screen__c = false;
            }
        }else if(formLineItem.Question_Text__c == 'Does the pharmacy fill controlled substance and/or Gabapentin prescriptions for out-of-state patients?'){
            var userRes = formLineItem.Response__c;
            if(userRes == 'Yes'){
                formLineItems[indexValue+1].formLineItem.IsRequired__c = true;
                formLineItems[indexValue+1].formLineItem.Show_on_Screen__c = true;
            }else{
                formLineItems[indexValue+1].formLineItem.IsRequired__c = false;
                formLineItems[indexValue+1].formLineItem.Show_on_Screen__c = false;
            }
        }else if(formLineItem.Question_Text__c == 'Are you aware of any disciplinary actions/sanctions taken at any time against any of the above practitioners?'){
            var userRes = formLineItem.Response__c;
            if(userRes == 'Yes'){
                formLineItems[indexValue+1].formLineItem.IsRequired__c = true;
                formLineItems[indexValue+1].formLineItem.Show_on_Screen__c = true;
            }else{
                formLineItems[indexValue+1].formLineItem.IsRequired__c = false;
                formLineItems[indexValue+1].formLineItem.Show_on_Screen__c = false;
            }
        }
        component.set("v.formLineItems",formLineItems);
    },
    handleDependencyForAdditionalAccountRequest: function(component, formLineItem, formLineItems, formWrapper, selectedOptionVal, selectedOptionValue, form){
        var indexValue = component.get("v.indexValue");
        var businessUnit = form.Onboarding__r.Onboarding_Customer_Type__c;
        if(formLineItem.Question_Text__c == 'Are you a member of a GPO?' && businessUnit != 'OSC'){
            var userRes = formLineItem.Response__c;
            if(userRes == 'Yes'){
               formLineItems[indexValue+1].formLineItem.IsRequired__c = true;
               formLineItems[indexValue+1].formLineItem.Show_on_Screen__c = true;
               formLineItems[indexValue+2].formLineItem.IsRequired__c = true;
               formLineItems[indexValue+2].formLineItem.Show_on_Screen__c = true; 
            }else{
               formLineItems[indexValue+1].formLineItem.IsRequired__c = false;
               formLineItems[indexValue+1].formLineItem.Show_on_Screen__c = false;
               formLineItems[indexValue+2].formLineItem.IsRequired__c = false;
               formLineItems[indexValue+2].formLineItem.Show_on_Screen__c = false;  
            }
        }else if(formLineItem.Question_Text__c == 'Are you a member of a GPO?' && businessUnit == 'OSC'){
            var userRes = formLineItem.Response__c;
            if(userRes == 'Yes'){
               formLineItems[indexValue+1].formLineItem.IsRequired__c = true;
               formLineItems[indexValue+1].formLineItem.Show_on_Screen__c = true; 
            }else{
               formLineItems[indexValue+1].formLineItem.IsRequired__c = false;
               formLineItems[indexValue+1].formLineItem.Show_on_Screen__c = false;  
            }
        }else if(formLineItem.Question_Text__c == 'Legal Entity Type'){
            var userRes = formLineItem.Response__c;
            if(userRes == 'Other'){
               formLineItems[indexValue+1].formLineItem.IsRequired__c = true;
               formLineItems[indexValue+1].formLineItem.Show_on_Screen__c = true; 
            }else{
               formLineItems[indexValue+1].formLineItem.IsRequired__c = false;
               formLineItems[indexValue+1].formLineItem.Show_on_Screen__c = false;
            }
        }else if(formLineItem.Question_Text__c == 'Is your location 340B eligible?'){
            var userRes = formLineItem.Response__c;
            if(userRes == 'Yes'){
               formLineItems[indexValue+1].formLineItem.IsRequired__c = true;
               formLineItems[indexValue+1].formLineItem.Show_on_Screen__c = true; 
            }else{
               formLineItems[indexValue+1].formLineItem.IsRequired__c = false;
               formLineItems[indexValue+1].formLineItem.Show_on_Screen__c = false;
            }
        }else if(formLineItem.Question_Text__c == 'Will AmerisourceBergen be your primary wholesaler?' && businessUnit != 'OSC'){
            var userRes = formLineItem.Response__c;
            if(userRes == 'S'){
               formLineItems[indexValue+1].formLineItem.IsRequired__c = true;
               formLineItems[indexValue+1].formLineItem.Show_on_Screen__c = true;
               formLineItems[indexValue+2].formLineItem.IsRequired__c = true;
               formLineItems[indexValue+2].formLineItem.Show_on_Screen__c = true; 
            }else{
               formLineItems[indexValue+1].formLineItem.IsRequired__c = false;
               formLineItems[indexValue+1].formLineItem.Show_on_Screen__c = false;
               formLineItems[indexValue+2].formLineItem.IsRequired__c = false;
               formLineItems[indexValue+2].formLineItem.Show_on_Screen__c = false; 
            }
        }else if(formLineItem.Question_Text__c == 'Will AmerisourceBergen be your primary wholesaler?' && businessUnit == 'OSC'){
            var userRes = formLineItem.Response__c;
            if(userRes == 'S'){
               formLineItems[indexValue+1].formLineItem.IsRequired__c = true;
               formLineItems[indexValue+1].formLineItem.Show_on_Screen__c = true;
            }else{
               formLineItems[indexValue+1].formLineItem.IsRequired__c = false;
               formLineItems[indexValue+1].formLineItem.Show_on_Screen__c = false;
            }
        }else if(formLineItem.Question_Text__c == 'What payment increment would you prefer?'){
            var userRes = formLineItem.Response__c;
            if(userRes == 'Other'){
               formLineItems[indexValue+1].formLineItem.IsRequired__c = true;
               formLineItems[indexValue+1].formLineItem.Show_on_Screen__c = true;
            }else{
               formLineItems[indexValue+1].formLineItem.IsRequired__c = false;
               formLineItems[indexValue+1].formLineItem.Show_on_Screen__c = false;
            }
        }else if(formLineItem.Question_Text__c == 'Will you be ordering controlled substances through AmerisourceBergen?' && businessUnit == 'Besse'){
            var userRes = formLineItem.Response__c;
            if(userRes == 'Yes'){
               formLineItems[indexValue+1].formLineItem.IsRequired__c = true;
               formLineItems[indexValue+1].formLineItem.Show_on_Screen__c = true;
            }else{
               formLineItems[indexValue+1].formLineItem.IsRequired__c = false;
               formLineItems[indexValue+1].formLineItem.Show_on_Screen__c = false;
            }
        }
        component.set("v.formLineItems",formLineItems);
     },
     handleDependencyForPaymntTrmSmallCred: function(component, formLineItem, formLineItems, formWrapper, selectedOptionVal, selectedOptionValue){
        var indexValue = component.get("v.indexValue");
        if(formLineItem.Question_Text__c =='What payment increment would you prefer?'){
        var userRes = formLineItem.Response__c;
            if(userRes=='Other'){
              formLineItems[indexValue+1].formLineItem.IsRequired__c = true;
              formLineItems[indexValue+1].formLineItem.Show_on_Screen__c = true;
            }else{
              formLineItems[indexValue+1].formLineItem.IsRequired__c = false;
              formLineItems[indexValue+1].formLineItem.Show_on_Screen__c = false;  
             }
            }
             component.set("v.formLineItems",formLineItems);
        }
})