({
    handleOnFocus : function(component, event, helper) {

        var questionText = event.getSource().get("v.label");

        if(questionText == 'Owner (s) since'){
            var dateString =  event.getSource().get("v.value");
            var newTest = dateString.replace('/','');
            event.getSource().set("v.value", newTest);
        }
    },
    handleOnBlur : function(component, event, helper) {

        var questionText = event.getSource().get("v.label");
        var current_year=new Date().getFullYear();
		
        if(questionText == 'Owner (s) since'){
            var dateString =  event.getSource().get("v.value");
            var month = dateString.substring(0,2);
            var year = dateString.substring(2,7);

            if((month < 1) || (month >12)){
                var errMessage = 'Please enter valid Month in MM format between 01 to 12';
                var toastEvent = $A.get("e.force:showToast");

                toastEvent.setParams({
                    title : 'Error',
                    message: errMessage,
                    type: 'error',
                });
                toastEvent.fire();

                return false;
            }
            else if((year < 1800) || (year > current_year)){
                var errMessage = 'Please enter valid Year. It should be  >1800 and <= Current Year';
                var toastEvent = $A.get("e.force:showToast");

                toastEvent.setParams({
                    title : 'Error',
                    message: errMessage,
                    type: 'error',
                });
                toastEvent.fire();

                return false;
            }
            else{

                var setDate = month + '/' +year ;
                event.getSource().set("v.value", setDate);
            }
        }
        
        var formLineItem = component.get("v.formLineItem");
        var formLineItems = component.get("v.formLineItems");
        var formWrapper = component.get("v.formWrapper");
        var form = component.get("v.form");
        var questionText = event.getSource().get("v.label");
        
        if(form.Name == 'AmerisourceBergen Personal Guaranty' && questionText == 'Spouse name'){
            var spouseName = event.getSource().get("v.value");
            var currentIndex = event.getSource().get("v.name");
            var isRequired = false;
            var lastIndex = currentIndex + 7;
            if(spouseName != null && spouseName != ''){
                isRequired = true;
            }
            for(var i=currentIndex + 1; i< lastIndex; i++){
                formLineItems[i].formLineItem.IsRequired__c = isRequired;
            }
            component.set("v.formLineItems", formLineItems);
        }        
    },
});