({
	next_button : function(component, event, helper) {     
		  var tabValue = component.get("v.tabKey");      
          component.set("v.tabKey","three");
	},
    
     back_button : function(component, event, helper) {     
    	 var tabValue = component.get("v.tabKey");      
         component.set("v.tabKey","one");
     }
})