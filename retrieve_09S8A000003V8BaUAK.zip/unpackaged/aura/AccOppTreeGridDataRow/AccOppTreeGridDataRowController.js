({  
    init : function(component, event, helper) {
        var RowData = component.get("v.RowData");
        var Level = component.get("v.Level");
    },
    
    expandChild : function(component, event, helper) {
		component.set("v.IsAriaExpanded", !component.get("v.IsAriaExpanded"));
	}
})