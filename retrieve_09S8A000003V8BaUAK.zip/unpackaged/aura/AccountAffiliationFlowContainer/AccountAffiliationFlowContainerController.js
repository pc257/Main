({
    init : function (component) {
        var flow = component.find("accountAffiliationFlow");
        var inputVariables = [
            {
                name : "RouteOption",
                type : "String",
                value : component.get("v.routeType")
            },
            {
                name : "CurrentAccountId",
                type : "String",
                value : component.get("v.currentAccId")
            }
        ];
        flow.startFlow("Account_Affiliation_Flow", inputVariables);
    },
    
    statusChange : function (component, event, helper) {
        if (event.getParam('status') === "FINISHED_SCREEN" || event.getParam('status') === "FINISHED") {
            var toastEvent = $A.get("e.force:showToast");
            toastEvent.setParams({
                title: "Success!",
                message: "Account Affiliation record created successfully!",
                type: "success"
            });
            toastEvent.fire();
            
            var evt = component.getEvent("AccountAffiliationFlowEventt");
            evt.setParams({"closeModal" : false });
            evt.fire();
            
            var evt = component.getEvent("AccountAffiliationRefreshVieww");
            evt.setParams({"refreshCMP" : true });
            evt.fire();
        }
        else if (event.getParam('status') === "ERROR") {
            component.set("v.hasError", true);
        }
    },
    
    closeView : function(component, event, helper){
        var evt = component.getEvent("AccountAffiliationFlowEventt");
        evt.setParams({"closeModal" : false });
        evt.fire();
    }
})