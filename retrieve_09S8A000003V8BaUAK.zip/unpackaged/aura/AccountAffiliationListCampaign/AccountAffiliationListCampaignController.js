({
	doInit : function(component, event, helper) {
		helper.getAccountId(component, event, helper);
    }
})