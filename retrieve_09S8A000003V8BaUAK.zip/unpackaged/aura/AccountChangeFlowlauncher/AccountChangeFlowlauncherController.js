({
	beginFlow : function(component, event, helper) {
		
        var flow = component.find("flow");
        var inputVariables = [
        {
            name : 'recordId',
            type : 'String',
            value : component.get("v.recordId")
        },
        {
            name : 'SObjectName',
            type : 'String',
            value : component.get("v.sObjectName")
        }
        ];
        
        flow.startFlow("Account_Change", inputVariables);
        
	}
})