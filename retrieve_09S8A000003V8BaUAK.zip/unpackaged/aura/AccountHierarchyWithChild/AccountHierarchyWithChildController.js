({
	init : function(component, event, helper) {
		helper.getHierarchyWithRelatedRecords(component, event, helper);
	}
})