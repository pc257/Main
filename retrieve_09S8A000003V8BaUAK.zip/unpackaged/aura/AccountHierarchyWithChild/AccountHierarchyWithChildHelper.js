({
    getHierarchyWithRelatedRecords : function(component, event, helper) {
        var action = component.get('c.getHierarchyWithRelatedRecords'); 
        action.setParams({
            RecordId : component.get('v.recordId'), 
            ParentFieldSet : component.get('v.ParentFieldSet'), 
            ChildFieldSet : 'AccountHierarchy_OpportunityFields'
        });
        action.setCallback(this, function(data){
            var state = data.getState(); 
            if(state == 'SUCCESS') {
                var xData = data.getReturnValue();
                var treeAccount = helper.createTree(xData.Accounts, xData.Record5kId);
                component.set('v.AccountColumns', xData.AccountColumns);
                component.set('v.OpportunityColumns', xData.OpportunityColumns);
                component.set('v.AccountData', treeAccount["XXXXXXXXXXXXXXXXXX"]._children);
            }
        });
        $A.enqueueAction(action);
    },
    
    createTree : function(result, TempPID){
        var xHasChild = {};
        result.forEach(function(item){
            if(item.ParentId != "XXXXXXXXXXXXXXXXXX"){
            	xHasChild[item.ParentId] = true;
            }
        });
        
        var xRaw = {};
        xRaw["XXXXXXXXXXXXXXXXXX"] = {Id: "XXXXXXXXXXXXXXXXXX", _children: []};
        result.forEach(v => xRaw[v.Id] = {
            Id: v.Id, 
            ParentId: v.ParentId, 
            HasChildAccounts: v.HasChildAccounts, 
            HasOpportunities: v.HasOpportunities, 
            AriaExpanded: v.AriaExpanded, 
            Record: v.Record
        });
        
        result.forEach(function(item){
            if(xHasChild.hasOwnProperty(item.Id)){
                xRaw[item.Id]._children = [];
            }
        });
        result.forEach(v => xRaw[v.ParentId]._children.push(xRaw[v.Id]));
        return xRaw;
    }
})