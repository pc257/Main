({
	doInit : function(component, event, helper) {
		helper.fetchAccountHierarchyData(component, event, helper);
	},
    
    showSpinner: function(component, event, helper){
        component.set("v.Spinner", true);
    },
    
    hideSpinner : function(component, event, helper){   
        component.set("v.Spinner", false);
    },
    
    changeView:function(component,event,helper){
        helper.changeView(component, event, helper);
    },
    
    closeDetails : function(component, event, helper){
		component.destroy();        
    }
})