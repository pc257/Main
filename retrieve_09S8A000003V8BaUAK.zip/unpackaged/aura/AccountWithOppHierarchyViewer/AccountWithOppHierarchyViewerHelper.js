({
    fetchAccountHierarchyData : function(component, event, helper) {
        try{
            var columns = [
                {type: "url", fieldName: "Url", label: "Name", initialWidth: 350, typeAttributes: {label: {fieldName: "Name"}}, cellAttributes:
                 {iconName: { fieldName: 'TypeIcon' }, iconPosition: 'left'}},
                {type: 'text', fieldName: 'OpportunityStage', label: 'Opportunity Stage', initialWidth: 300},
                {type: "currency", fieldName: "Amount", label: "Opportunity Amount", initialWidth: 350, typeAttributes: {currencyCode: "USD"}},
                {type: "number", fieldName: "TotalOpportunities", label: "Opportunity Count"}
            ];
            
            component.set('v.gridColumns', columns);
            
            var action = component.get("c.getAccountOpportunityHierarchyData");
            var ddGrandParentId = component.get("v.ddGrandParentId");
            action.setParams({ddGrandParentId : ddGrandParentId});
            
            action.setCallback(this, function(data){
                var state = data.getState();
                if(state == "SUCCESS"){
                    var accounts = data.getReturnValue();
                    var rawGridData = {};             
                    var url = location.href;  // entire url including querystring - also: window.location.href;
                    var baseURL = url.substring(0, url.indexOf('/', 14)) + "/lightning/r/";
                    if(accounts){
                        accounts.forEach(function(account){
                            // For grand parent account, nullify parent id. This is to be done for avoiding circular object error
                            // while putting each account into map
                            if(account.Definitive_Data__r[0].Definitive_ID__c == ddGrandParentId){
                                account.Definitive_Data__r[0].Definitive_IDN_ID__c = '';
                            }else if(account.Definitive_Data__r[0].Definitive_IDN_ID__c == account.Definitive_Data__r[0].Definitive_ID__c){
                                account.Definitive_Data__r[0].Definitive_IDN_ID__c = account.Definitive_Data__r[0].Custom_IDN_Parent_ID__c;
                            }
                            
                            var accountGridRow = {
                                Id: account.Id,
                                Name: account.Name,
                                Url: baseURL + 'Account/' + account.Id + '/view',
                                Amount: 0,
                                TotalOpportunities: 0,
                                TypeIcon: "standard:account"
                            };
                        
                            if(account.Opportunities){
                                accountGridRow._children = [];
                                accountGridRow.TotalOpportunities = account.Opportunities.length;
                                account.Opportunities.forEach(function(oppty){
                                    var opptyGridRow = {
                                        Id: oppty.Id,
                                        Name: oppty.Name,
                                        OpportunityStage: oppty.StageName,
                                        Amount: oppty.Amount,
                                        Url: baseURL + 'Opportunity/' + oppty.Id + '/view',
                                        TypeIcon: "standard:opportunity"
                                    };
                                    accountGridRow._children.push(opptyGridRow);
                                    if(oppty.Amount)
                                        accountGridRow.Amount = accountGridRow.Amount + oppty.Amount;
                                });
                            }
                            rawGridData[account.Definitive_Data__r[0].Definitive_ID__c] = accountGridRow;
                        });
                        

                        // Build hierarchy tree for each account
                        accounts.forEach(function(account){
                            if(account.Definitive_Data__r[0].Definitive_IDN_ID__c){
                                
                                if(!rawGridData[account.Definitive_Data__r[0].Definitive_IDN_ID__c].hasOwnProperty('_children')){
                                    rawGridData[account.Definitive_Data__r[0].Definitive_IDN_ID__c]._children = [];
                                    
                                }
                                
                                rawGridData[account.Definitive_Data__r[0].Definitive_IDN_ID__c]._children.push(rawGridData[account.Definitive_Data__r[0].Definitive_ID__c]);
                                
                                if(account.Definitive_Data__r[0].Definitive_IDN_ID__c != ddGrandParentId){
                                	rawGridData[account.Definitive_Data__r[0].Definitive_IDN_ID__c].Amount += rawGridData[account.Definitive_Data__r[0].Definitive_ID__c].Amount;    
                                	rawGridData[account.Definitive_Data__r[0].Definitive_IDN_ID__c].TotalOpportunities += rawGridData[account.Definitive_Data__r[0].Definitive_ID__c].TotalOpportunities;        
                                }
                            }
                        });
                        
                        
                        helper.summarizeOpptyAmonutAndCount(component, rawGridData, ddGrandParentId);
                        helper.changeView(component, event, helper);
                    }
                }
            });       
            $A.enqueueAction(action);    
        }catch(err){
            
        }
    },
    
    summarizeOpptyAmonutAndCount : function(component, rawGridData, ddGrandParentId){
        rawGridData[ddGrandParentId]._children.forEach(function(child){
            if(child.Amount)
            	rawGridData[ddGrandParentId].Amount += child.Amount; 
            if(child.hasOwnProperty('TotalOpportunities'))
            	rawGridData[ddGrandParentId].TotalOpportunities += child.TotalOpportunities;
        });
        component.set("v.rawGridData", rawGridData); 
    },
    
    changeView : function(component, event, helper){
        var extendedView = component.find("extendedView").get("v.checked");
        var gridData = [];
        var rawGridData = component.get("v.rawGridData");
        gridData.push(rawGridData[extendedView ? component.get("v.ddGrandParentId") : component.get("v.ddId")]);
        component.set("v.gridData", gridData);
    },
    
    handleToggle : function(component, event, helper){
        var extendedView = component.find("extendedView").get("v.checked");
        component.set("v.ToExpand", extendedView);
    }
})