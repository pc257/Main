({
	myAction : function(component, event, helper) {
         var estatedata=component.get('c.getAllAccounts');
		 estatedata.setCallback(this,function(response){
           var mydata=response.getReturnValue();
            component.set('v.AccountList',mydata);
             console.log("123456789",mydata);
            });
        
         $A.enqueueAction(estatedata);
    }
    })