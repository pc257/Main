({
    doinit: function (component, event, helper) {
        var RecordId = component.get("v.recordId");
        var action = component.get("c.fetchInventoryService");
        action.setParams({
            recId: RecordId,
        });
        action.setCallback(this, function (data) {
            var state = data.getState();
            if (state == 'SUCCESS') {
                var InventoryServiceRecord = data.getReturnValue();
                if (InventoryServiceRecord.Request_Type__c == 'Add On' && InventoryServiceRecord.Status__c == 'In Progress') {
                    helper.fetchEquipments(component, event, helper);
                }
                else {
                    $A.util.removeClass(component.find("screen0"), "slds-hide");
                    $A.util.addClass(component.find("screen1"), "slds-hide");
                }
            }
        });
        $A.enqueueAction(action);
    },
    moveTOPheripheralEquipments: function (component, event, helper) {
        helper.displayPeripherals(component, event, helper);
    },
    fetchPeripherals: function (component, event, helper) {
        helper.fetchPeripheralEquipments(component, event, helper);
    },
    moveToPrimaryEquipments: function (component, event, helper) {
        $A.util.removeClass(component.find("screen1"), "slds-hide");
        $A.util.addClass(component.find("screen3"), "slds-hide");
    },
    saveAddOnEquipments: function (component, event, helper) {
        helper.saveAdditionalEquipments(component, event, helper);
    }
})