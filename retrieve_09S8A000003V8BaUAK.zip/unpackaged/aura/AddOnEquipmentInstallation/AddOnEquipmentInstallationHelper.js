({
    fetchEquipments : function(component, event, helper) {
        var action = component.get("c.fetchEquipments");
        action.setParams({
            recId: component.get("v.recordId"),
            equipmentCategory: 'Add On'
        });
        action.setCallback(this, function (data) {
            debugger;
            var listItem = [];
            console.log(data.getReturnValue());
            var state = data.getState();
            if (state == "SUCCESS") {
                debugger;
                listItem = data.getReturnValue();
                component.set("v.PrimaryEquipmentList", listItem);
            }
        });
        $A.enqueueAction(action);
    },
    displayPeripherals: function (component, event, helper) {
        var action = component.get("c.fetchEquipments");
        action.setParams({
            recId: component.get("v.recordId"),
            equipmentCategory: 'Peripheral',
        });
        action.setCallback(this, function (data) {
            var state = data.getState();
            if (state == "SUCCESS") {
                var equipmentTypeList = [];
                var listItem = data.getReturnValue();
                for (var count = 0; count < listItem.length; count++) {
                    debugger;
                    console.log('listItem[count].EquipmentType : ' + listItem[count].EquipmentType);
                    equipmentTypeList.push(listItem[count].EquipmentType);
                    debugger;
                }
                component.set("v.PeripheralEquipmentType", equipmentTypeList);
                $A.util.addClass(component.find("screen1"), "slds-hide");
                $A.util.removeClass(component.find("screen3"), "slds-hide");
                component.set("v.PeripheralEquipmentList", []);
            }
        });
        $A.enqueueAction(action);
    },
    fetchPeripheralEquipments: function (component, event, helper) {
        var PeripheralItems = component.get("v.PeripheralEquipmentList");
        var pObj = {};
        PeripheralItems.push(pObj);
        component.set("v.PeripheralEquipmentList", PeripheralItems);
    },
    saveAdditionalEquipments : function(component, event, helper){
        debugger;
        var RecordId = component.get("v.recordId");
        var PrimaryEquipments = component.get("v.PrimaryEquipmentList");
        var PeripheralEquipments = component.get("v.PeripheralEquipmentList");
        var allEquipments = PrimaryEquipments.concat(PeripheralEquipments);
        var action = component.get("c.saveAdditionalRecord");
        action.setParams({
            allEquipments : JSON.stringify(allEquipments),
            inventoryServiceId : RecordId,
        });
        action.setCallback(this,function(data){
            var state = data.getState();
            if(state == 'SUCCESS'){
                $A.util.removeClass(component.find("screen5"), "slds-hide");
                $A.util.addClass(component.find("screen3"), "slds-hide");
                helper.showToastSuccess(component, event, helper);
                component.set("v.saved",true);
            }
            else if(state == 'ERROR'){
                var errors = data.getError();
                helper.showToastFail(component,event,helper,errors[0].message);
            }
        });
        $A.enqueueAction(action);

    },
    showToastSuccess: function (component, event, helper) {
        console.log('Inside Show Toast');
        var toastEvent = $A.get("e.force:showToast");
        toastEvent.setParams({
            "type": "success",
            "title": "Success!",
            "message": "Service Equipment record has been created/updated successfully"
        });
        toastEvent.fire();
    },
    showToastFail: function (component, event, helper,message) {
        console.log('Inside Show Toast Fail');
        component.find('notifLib').showToast({
            "title": "Error!",
            "variant" : "error",
            "message": message
        });
    }
})