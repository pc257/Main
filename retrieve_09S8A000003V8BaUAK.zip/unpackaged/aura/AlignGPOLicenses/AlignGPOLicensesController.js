({
	doInit : function(component, event, helper) {
        var recId = component.get("v.recordId");            
        var action = component.get("c.fetchLicense");
        action.setParams({
            conId: recId
        });
        action.setCallback(this, function(response) {
            var state = response.getState();
            if (state === "SUCCESS") {
                var resList = response.getReturnValue();    
                if(resList != null){                       
                    component.set('v.licenseList', resList);                    
                } 
            }
        });
        var action2 = component.get('c.fetchGPOLicense');
        action2.setParams({
           conId: component.get("v.recordId")
        });
        
        action2.setCallback(this, function(response) {
            var state = response.getState();
            if (state == "SUCCESS") {
                var resGPOLicList = response.getReturnValue();
                if(resGPOLicList != null){
                 	component.set("v.gPOLicenseList", resGPOLicList);   
                }                
            }
        });
        $A.enqueueAction(action);   
        $A.enqueueAction(action2);
    },
    cancelButton : function(component, event, helper) {
        var dismissActionPanel = $A.get("e.force:closeQuickAction");
        dismissActionPanel.fire();
        
    },
    handleSearch : function(component, event, helper){
        var gPOMemVal = component.get("v.gPOMemName");
        var grpIdVal = component.get("v.grpID");
        var action = component.get("c.fetchGPOMembership");
        action.setParams({
            gPOMem: gPOMemVal,
            grpId: grpIdVal
        });
        action.setCallback(this, function(response) {
            var state = response.getState();
            if (state === "SUCCESS") {
                var resGPOMem = response.getReturnValue(); 
                if(resGPOMem != null){                       
                    component.set('v.gPOMembershipList',resGPOMem);
                }
            }
        });
        $A.enqueueAction(action); 
    },
    alignLicense: function(component, event, helper) {
        var selectedLicId = [];
        var selectedGPOMemId = [];
        var checkvalue = component.find("licPack");
        var checkGPOVal = component.find("gpoPack");
        if(checkGPOVal == undefined || checkvalue == undefined){
            alert('Please select atleast One License and One GPO Membership Record');                            
            return;
        }
        if(!Array.isArray(checkvalue)){
            if (checkvalue.get("v.value") == true) {
                selectedLicId.push(checkvalue.get("v.text"));
            }
        }else{
            for (var i = 0; i < checkvalue.length; i++) {
                if (checkvalue[i].get("v.value") == true) {
                    selectedLicId.push(checkvalue[i].get("v.text"));
                }
            }
        }
        
        if(!Array.isArray(checkGPOVal)){
            if (checkGPOVal.get("v.value") == true) {
                selectedGPOMemId.push(checkGPOVal.get("v.text"));
            }
        }else{
            for (var i = 0; i < checkGPOVal.length; i++) {
                if (checkGPOVal[i].get("v.value") == true) {
                    selectedGPOMemId.push(checkGPOVal[i].get("v.text"));
                }
            }
        }
        if(selectedLicId.length == '0' || selectedGPOMemId.length == '0'){
            alert('Please select GPO Membership/License');
            return;
        }
		var action = component.get("c.createGPOContactAndGPOLicense");
        var recId = component.get("v.recordId");
        console.log('recId'+recId);
        console.log('selectedLicId'+selectedLicId);
        console.log('selectedGPOMemId'+selectedGPOMemId);
        action.setParams({
            conId: recId,
            selLicenseIds: selectedLicId,
            selGPOMemIds: selectedGPOMemId
        });
        action.setCallback(this, function(response) {
            var state = response.getState();
            if (state === "SUCCESS") {
                alert('Records Created Successfully');
                var dismissActionPanel = $A.get("e.force:closeQuickAction");
                dismissActionPanel.fire();
            }
        });
        $A.enqueueAction(action);         
    }
})