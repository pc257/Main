({
    doInit : function(component, event, helper) {           
        var action=  component.get('c.buDetails');  // Calling apex method
        action.setParams({ AccountID : component.get("v.recordId") });

        action.setCallback(this,function(response)   // getting response back from apex method
             {
                 var state = response.getState();  // getting the state              
                 if(state === 'SUCCESS'){                                                               
                     component.set('v.lstBUwrapper', response.getReturnValue());                     
                     var lstWrap = response.getReturnValue();                   
                     helper.getDefaultBU(component, event, helper);
                 
                 }                                                              
             }); 
        $A.enqueueAction(action);
    }    
        
 })