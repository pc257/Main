({
	openModel : function(component, event, helper) {
		component.set("v.isOpen", true);
	},
    closeModel: function(component, event, helper) {
      
      component.set("v.isOpen", false);
   }
})