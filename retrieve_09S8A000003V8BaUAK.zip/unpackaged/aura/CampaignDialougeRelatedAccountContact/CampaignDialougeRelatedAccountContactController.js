({
    doInit : function(component, event, helper) {
        helper.getContacts(component, event, helper);
    },
    
    /*
    showSpinner: function(component, event, helper){
        component.set("v.Spinner", true); 
    }, */
    
    /* hideSpinner : function(component, event, helper){   
        component.set("v.Spinner", false);
    },*/
    
    firstPage: function(component, event, helper) {
        if(component.get("v.CurrentPage") < 1){
            helper.navigatePage(component, event, helper, 1);
        }
    },
    
    prevPage: function(component, event, helper) {
        if(component.get("v.CurrentPage") > 1){
            helper.navigatePage(component, event, helper, Math.max(component.get("v.CurrentPage") - 1, 1));
        }
    },
    
    nextPage: function(component, event, helper) {
        var TotalPages = component.get("v.TotalPages");
        if(component.get("v.CurrentPage") < TotalPages){
            helper.navigatePage(component, event, helper, Math.min(component.get("v.CurrentPage") + 1, component.get("v.TotalPages")));
        }
    },
    
    lastPage: function(component, event, helper) {
        var TotalPages = component.get("v.TotalPages");
        if(component.get("v.CurrentPage") < TotalPages){
            helper.navigatePage(component, event, helper, component.get("v.TotalPages"));
        }
    },
    
})