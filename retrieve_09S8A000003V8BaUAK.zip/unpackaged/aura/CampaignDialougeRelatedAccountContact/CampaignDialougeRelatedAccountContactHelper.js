({
    getContacts : function(component, event, helper) {
        var action = component.get("c.getContacts");
        action.setParams({
            //CampaignDialogueId : 'a368A000000NOaaQAG'
            CampaignDialogueId : component.get("v.recordId")
        });
        
        action.setCallback(this, function(data) {
            if (data.getState() === "SUCCESS") {
                debugger;
                var xData=data.getReturnValue();
                var PageSize = component.get("v.PageSize");
                var TotalPages = parseInt(xData.length / PageSize);
                if(parseInt(xData.length % PageSize) > 0){TotalPages++;}
                
                component.set("v.contacts", xData);
                component.set("v.AccountContactTitle", "Related Contacts (" + xData.length + ")");
                component.set("v.TotalPages", TotalPages);
                
                helper.sliceData(component, event, helper);
            } else if (data.getState() === "ERROR") {
                alert('getContacts: Error in calling server side action');
            }
        });       
        $A.enqueueAction(action);
    }, 
    sliceData : function(component, event, helper) {
        debugger;
        var PageSize = component.get("v.PageSize");
        var CurrentPage = component.get("v.CurrentPage");
        var contacts = component.get("v.contacts");
        var ContactsPaged = contacts.slice((CurrentPage - 1) * PageSize, CurrentPage * PageSize);
        component.set("v.ContactsPaged", ContactsPaged);
    },
    navigatePage : function(component, event, helper, pageno) {
        component.set("v.CurrentPage", pageno);
        helper.sliceData(component, event, helper);
    },
    
})