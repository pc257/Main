({
  doinit: function (component, event, helper) {
    var RecordId = component.get("v.recordId");
    var action = component.get("c.fetchInventoryService");
      
        action.setParams({
          recId : RecordId,
        });
        action.setCallback(this,function(data){
          var state = data.getState();
          if(state == 'SUCCESS'){
            var InventoryServiceRecord = data.getReturnValue();
            if(InventoryServiceRecord.Request_Type__c == 'Installation'&& InventoryServiceRecord.Status__c == 'In Progress'){
              helper.fetchEquipments(component, event, helper);
            }
            else{
              $A.util.removeClass(component.find("screen0"), "slds-hide");
              $A.util.addClass(component.find("screen1"), "slds-hide");
            }
          }
        });
        $A.enqueueAction(action);
  },
  populateSecondoryEquipments: function (component, event, helper) {
      //console.log('Test***', +selItem);
      
    helper.fetchSecondoryEquipments(component, event, helper);
  },
  moveToPrimaryEquipments: function (component, event, helper) {
    $A.util.removeClass(component.find("screen1"), "slds-hide");
    $A.util.addClass(component.find("screen2"), "slds-hide");
  },
  moveTOPheripheralEquipments: function (component, event, helper) {
    helper.displayPeripherals(component, event, helper);
  },
  fetchPeripherals: function (component, event, helper) {
    helper.fetchPeripheralEquipments(component, event, helper);
  },
  moveToSecondaryEquipment: function (component, event, helper) {
    $A.util.addClass(component.find("screen3"), "slds-hide");
    $A.util.removeClass(component.find("screen2"), "slds-hide");
  },
  moveToCloseOutReport: function (component, event, helper) {
    $A.util.removeClass(component.find("screen4"), "slds-hide");
    $A.util.addClass(component.find("screen3"), "slds-hide");
    helper.loadImsNucleus(component, event, helper);
  },
  moveToPeripheralEquipment: function (component, event, helper) {
    $A.util.removeClass(component.find("screen3"), "slds-hide");
    $A.util.addClass(component.find("screen4"), "slds-hide");
  },
  saveIMSNucleus: function (component, event, helper) {
    helper.saveIMSNucleusRecords(component, event, helper);
  },
  handleUploadFinished: function (component, event) {
    var uploadedFiles = event.getParam("files");
    console.log("Files uploaded : " + uploadedFiles.length);
    console.log("Files documentId : " + uploadedFiles.documentId);
    component.set("v.FileId", uploadedFiles[0].documentId);
  }
})