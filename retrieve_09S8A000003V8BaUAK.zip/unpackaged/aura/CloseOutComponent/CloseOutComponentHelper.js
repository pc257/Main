({
    fetchEquipments: function (component, event, helper) {
       
        var action = component.get("c.fetchEquipments");
        action.setParams({
            recId: component.get("v.recordId"),
            equipmentCategory: 'Primary'
        });
        action.setCallback(this, function (data) {
            
            var listItem = [];
            console.log('getReturnValue********' , data.getReturnValue());
            var state = data.getState();
            console.log('data************' , data);
            if (state == "SUCCESS") {
                
                listItem = data.getReturnValue();
                component.set("v.PrimaryEquipmentList", listItem);
                console.log('listItem********' , listItem);
            }
        });
        $A.enqueueAction(action);
    },
    fetchSecondoryEquipments: function (component, event, helper) {
        //debugger;
       
        var action = component.get("c.fetchEquipments");
        action.setParams({
            recId: component.get("v.recordId"),
            equipmentCategory: 'Secondary',
        });
        action.setCallback(this, function (data) {
          //  debugger;
            var EquipmentList = component.get("v.PrimaryEquipmentList");
            var listItem = [];
            var state = data.getState();
            if (state == "SUCCESS") {
                //debugger;
                var tempSet = new Set();
                var stationidList = [];
                for (var count = 0; count < EquipmentList.length; count++) {
                    //debugger;
                    console.log('StationId : ' + EquipmentList.StationId);
                    
                    tempSet.add(EquipmentList.StationId);
                    //debugger;
                }
                stationidList = Array.from(tempSet);
                component.set("v.StationIdList", stationidList);
                $A.util.addClass(component.find("screen1"), "slds-hide");
                $A.util.removeClass(component.find("screen2"), "slds-hide");
                listItem = data.getReturnValue();
                component.set("v.SecondaryEquipmentList", listItem);

            }
        });
        $A.enqueueAction(action);
    },
    displayPeripherals: function (component, event, helper) {
        var action = component.get("c.fetchEquipments");
        action.setParams({
            recId: component.get("v.recordId"),
            equipmentCategory: 'Peripheral',
        });
        action.setCallback(this, function (data) {
            var state = data.getState();
            if (state == "SUCCESS") {
                var equipmentTypeList = [];
                var listItem = data.getReturnValue();
                for (var count = 0; count < listItem.length; count++) {
                    debugger;
                    console.log('listItem[count].EquipmentType : ' + listItem[count].EquipmentType);
                    equipmentTypeList.push(listItem[count].EquipmentType);
                    debugger;
                }
                var EquipmentList = component.get("v.PrimaryEquipmentList");
                var tempSet = new Set();
                var stationidList = [];
                for (var count = 0; count < EquipmentList.length; count++) {
                    debugger;
                    console.log('Stationid : ' + EquipmentList.StationId);
                    tempSet.add(EquipmentList.StationId);
                    debugger;
                }
                stationidList = Array.from(tempSet);
                component.set("v.StationIdList", stationidList);
                component.set("v.PeripheralEquipmentType", equipmentTypeList);
                $A.util.addClass(component.find("screen2"), "slds-hide");
                $A.util.removeClass(component.find("screen3"), "slds-hide");
                component.set("v.PeripheralEquipmentList", []);
            }
        });
        $A.enqueueAction(action);
    },
    fetchPeripheralEquipments: function (component, event, helper) {
        var PeripheralItems = component.get("v.PeripheralEquipmentList");
        var pObj = {};
        PeripheralItems.push(pObj);
        component.set("v.PeripheralEquipmentList", PeripheralItems);
    },
    loadImsNucleus: function (component, event, helper) {

        var action = component.get("c.fetchInventoryService");
        action.setParams({
            recId: component.get("v.recordId"),
        });
        action.setCallback(this, function (data) {
          
            var state = data.getState();
            if (state == "SUCCESS") {
                debugger;
                var equipmentMap = new Map();
                var inventoryService = data.getReturnValue();
                var PrimaryEquipments = component.get("v.PrimaryEquipmentList");
                var StationId = PrimaryEquipments.StationId;
                var SecondaryEquipments = component.get("v.SecondaryEquipmentList");
                var PeripheralEquipments = component.get("v.PeripheralEquipmentList");
                var allEquipments = PrimaryEquipments.concat(SecondaryEquipments, PeripheralEquipments);
                for (var count = 0; count < allEquipments.length; count++) {
                    debugger;
                    if (equipmentMap.has(allEquipments[count].StationId)) {
                        var value = equipmentMap.get(allEquipments[count].StationId);
                        //var tagValue = equipmentMapTags.get(allEquipments[count].StationId);
                        value.DisplayLabel = value.DisplayLabel.concat(', ', allEquipments[count].EquipmentType);
                        //value.push(allEquipments[count]);
                        equipmentMap.set(allEquipments[count].StationId, value);
                        //tagValue = tagValue.concat(', ', allEquipments[count].EquipmentType);
                        //equipmentMapTags.set(allEquipments[count].StationId, tagValue);
                    }
                    else {
                        //var tempArray = [];
                        //var tempString;
                        var tempEquipment = allEquipments[count];
                        tempEquipment.StationId = StationId;
                        tempEquipment.Account = inventoryService.Account__c;
                        tempEquipment.SAPAccountNumber = inventoryService.SAP_Account_Number__c;
                        tempEquipment.Registration = inventoryService.Provider_Solution__c;
                        tempEquipment.InstallationCaseId = inventoryService.Id;
                        tempEquipment.SystemName = 'NUCLEUS';
                        tempEquipment.CurrentStatus = 'Pending Install';
                        tempEquipment.DomainFacility = '';
                        tempEquipment.DisplayLabel = allEquipments[count].EquipmentType;
                        console.log('Test*****' +tempEquipment);
                        //tempString = allEquipments[count].EquipmentType;
                        //equipmentMapTags.set(allEquipments[count].StationId, tempEquipment);
                        //tempArray.push();
                        equipmentMap.set(StationId, tempEquipment);
                        

                    }
                }
                console.log('equipmentMap Keys : ' + equipmentMap.size);
                console.log('equipmentMap.values() : ' + JSON.stringify(equipmentMap.values()));
                var tempArr = [];
                equipmentMap.forEach(function (value, key) {
                    tempArr.push(value);
                });
                var ImsOnbject = new Object();
                ImsOnbject.InformationWrapper = tempArr;
                console.log('equipmentMap.values() : ' + JSON.stringify(tempArr));
                component.set("v.IMSEquipmentList", ImsOnbject);
                component.set("v.loaded",true);
            }
        });
        $A.enqueueAction(action);


    },
    saveIMSNucleusRecords: function (component, event, helper) {
        debugger;
        var RecordId = component.get("v.recordId");
        var IMSNucleusRec = component.get("v.IMSEquipmentList");
        var FileId = component.get("v.FileId");
        var PrimaryEquipments = component.get("v.PrimaryEquipmentList");
        var SecondaryEquipments = component.get("v.SecondaryEquipmentList");
        var PeripheralEquipments = component.get("v.PeripheralEquipmentList");
        var allEquipments = PrimaryEquipments.concat(SecondaryEquipments, PeripheralEquipments);
        console.log('IMSNucleusRec : ' + JSON.stringify(IMSNucleusRec));
        console.log('FileId : ' + FileId);
        console.log('allEquipments : ' + JSON.stringify(allEquipments));
        if(IMSNucleusRec.EquipmentInformation == undefined || IMSNucleusRec.EquipmentInformation.WindowsCOA == undefined || IMSNucleusRec.EquipmentInformation.SolidStateSerial ==undefined || IMSNucleusRec.EquipmentInformation.NetworkTypes == '' || IMSNucleusRec.EquipmentInformation.LANIP ==undefined || IMSNucleusRec.EquipmentInformation.LANGW ==undefined
            || IMSNucleusRec.EquipmentInformation.VPNType == '' || IMSNucleusRec.EquipmentInformation.PrimaryDNS == undefined || IMSNucleusRec.EquipmentInformation.LANSubnet ==undefined || IMSNucleusRec.EquipmentInformation.SecondaryDNS ==undefined){
                helper.showToastFail(component, event, helper,'Required fields are missing!');
                return;
        }
        var action = component.get("c.createIMSRecord");
        action.setParams({
            imsRecords: JSON.stringify(IMSNucleusRec),
            allEquipments : JSON.stringify(allEquipments),
            fileId : FileId,
            inventoryServiceId : RecordId,
        });
        action.setCallback(this,function(data){
            var state = data.getState();
            if(state == 'SUCCESS'){
                var recId = data.getReturnValue();
                component.set("v.IMSNucleusId",recId);
                $A.util.removeClass(component.find("screen5"), "slds-hide");
                $A.util.addClass(component.find("screen4"), "slds-hide");
                helper.showToastSuccess(component, event, helper);
                component.set("v.saved",true);
            }
            else if(state == 'ERROR'){
                var errors = data.getError();
                helper.showToastFail(component,event,helper,errors[0].message);
            }
        });
        $A.enqueueAction(action);
    },
    showToastSuccess: function (component, event, helper) {
        console.log('Inside Show Toast');
        var toastEvent = $A.get("e.force:showToast");
        toastEvent.setParams({
            "type": "success",
            "title": "Success!",
            "message": "Service Equipment record has been created/updated successfully"
        });
        toastEvent.fire();
    },
    showToastFail: function (component, event, helper,message) {
        console.log('Inside Show Toast Fail');
        component.find('notifLib').showToast({
            "title": "Error!",
            "variant" : "error",
            "message": message
        });
    }
})