({
	init : function(component, event, helper) {
		var today = new Date();
	    var currentYear = today.getYear();
        component.set('v.today', today.getFullYear());
	},
    openTermsAndCondition : function(component, event, helper) {
    	window.open("/abcforceservice/s/terms-and-conditions");
    },
    openPrivacyAndStatement : function(component, event, helper) {
        window.open("/abcforceservice/s/privacy-statement");
    }
})