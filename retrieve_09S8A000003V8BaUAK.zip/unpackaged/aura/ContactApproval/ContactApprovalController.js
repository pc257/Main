({
	setOption : function(component, event, helper) {
		var selectedOpt = event.getParam("selectedOption");
        component.set("v.selectedChoice", selectedOpt);
	}
})