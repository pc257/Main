({
    handleYes : function(component, event, helper) {
        helper.toggleSpinner(component);
        var action = component.get("c.deleteApproval");
        action.setParams({ recId : component.get("v.entityId")});
        action.setCallback(this, function(response) {
            var state = response.getState();
            if (state === "SUCCESS"){
                helper.toggleSpinner(component);
                helper.showToast(response.getReturnValue(), 'success', 'Success!');
            }else{
                helper.toggleSpinner(component);
            }
        });
        $A.enqueueAction(action);
        
        window.setInterval(
            $A.getCallback(function() {
                var dismissActionPanel = $A.get("e.force:closeQuickAction");
                dismissActionPanel.fire();
            }), 5000
        );
    }
})