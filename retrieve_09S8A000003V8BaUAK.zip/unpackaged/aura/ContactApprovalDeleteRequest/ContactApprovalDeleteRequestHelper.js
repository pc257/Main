({
	showToast : function(strmessage, typeOfToast, titleToast) { // type 'error', 'warning', 'success',
        var toastEvent = $A.get("e.force:showToast");
        toastEvent.setParams({
            "title": titleToast,
            "type" : typeOfToast,
            "message": strmessage
        });
        toastEvent.fire();
    },
    
    toggleSpinner: function(component){
        var spinner = component.find("loading_spinner");
        $A.util.toggleClass(spinner, "slds-hide");
    }
})