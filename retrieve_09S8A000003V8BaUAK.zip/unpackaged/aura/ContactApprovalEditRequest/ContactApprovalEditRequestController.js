({
    doInit : function(component, event, helper) {
        var action = component.get("c.getAllFields");
        action.setParams({ recordId : component.get("v.entityId")});
        action.setCallback(this, function(response) {
            var state = response.getState();
            if (state === "SUCCESS") {
                var returnList = response.getReturnValue();
                returnList.sort(function(a, b) { 
                    return ((a.fieldLabel).toLowerCase() < (b.fieldLabel).toLowerCase()) ? -1 : ((a.fieldLabel).toLowerCase() > (b.fieldLabel).toLowerCase()) ? 1 : 0
                });
                component.set("v.contactFieldList", returnList);
                helper.toggleSpinner(component);
            }
        });
        $A.enqueueAction(action);
    },
    
    selectPickList : function(component, event, helper) {
        component.set("v.newVal", component.find("SelectedPickVal").get("v.value"));
    },
    
    selectField : function(component, event, helper) {
        var selectedVal = component.find("SelectedField").get("v.value");
        if(selectedVal != "" && selectedVal != undefined){
            component.set("v.isVisible", true);
            var fieldArray = selectedVal.split('-');
            var fieldApi = fieldArray[0];
            var fieldtype = fieldArray[1];
            var fieldLabl = fieldArray[2];
            var exactFieldTypename;
            switch (fieldtype) {
                case 'DATE':
                    exactFieldTypename = "Date";
                    break;
                case 'DATETIME':
                    exactFieldTypename = "DateTime";
                    break;
                case 'EMAIL': 
                    exactFieldTypename = "Email";
                    break;
                case 'PHONE':
                    exactFieldTypename = "tel";
                    break;
                case 'PICKLIST':
                    exactFieldTypename = "Picklist";
                    break;
                case 'BOOLEAN':
                    exactFieldTypename = "Boolean";
                    break;
                default:
                    exactFieldTypename = "Text";
            }
            component.set("v.fieldLabel", fieldLabl);
            component.set("v.fieldName", fieldApi);
            component.set("v.fieldType", exactFieldTypename);
            var action = component.get("c.getFieldDetails");
            action.setParams({ recId : component.get("v.entityId"), fieldApiName : fieldApi, fldType : fieldtype});
            action.setCallback(this, function(response) {
                var state = response.getState();
                if (state === "SUCCESS") {
                    var returnVal = response.getReturnValue();
                    component.set("v.currentVal", returnVal.fieldValue);
                    if(!helper.isBlank(returnVal.pickListValue)){
                        component.set("v.PickListValues", returnVal.pickListValue);
                    }
                }
            });
            $A.enqueueAction(action);
        }else{
            component.set("v.isVisible", false);
        }
    },
    
    handleAdd : function(component, event, helper) {
        var fldType = component.get("v.fieldType");
        var exactFieldTypename;
        switch (fldType) {
            case 'Date':
                exactFieldTypename = "Date";
                break;
            case 'DateTime':
                exactFieldTypename = "DateTime";
                break;
            case 'Email':
                exactFieldTypename = "Email";
                break;
            case 'tel':
                exactFieldTypename = "Phone";
                break;
            case 'Picklist':
                exactFieldTypename = "Picklist";
                break;
            case 'Boolean':
                exactFieldTypename = "Boolean";
                break;
            default:
                exactFieldTypename = "String";
        }
        var selectedobject = {"Prior_Value__c": component.get("v.currentVal"),
                              "Updated_Value__c": component.get("v.newVal"),
                              "Field_Name__c" : component.get("v.fieldName"),
                              "Field_Label__c" : component.get("v.fieldLabel"),
                              "Field_Type__c" : exactFieldTypename
                             };
        var arrayVal = component.get("v.updatedList");
        if(helper.isBlank(arrayVal)){
            arrayVal.push(selectedobject);
            component.set("v.updatedList", arrayVal);
            component.set("v.isVisible", false);
            component.set("v.newVal", undefined);
            component.set("v.currentVal", undefined);
            component.set("v.fieldLabel", undefined);
            component.set("v.fieldName", undefined);
            component.set("v.fieldType", undefined);        
            helper.showToast('Added Successfully', 'success', 'Success!');
        }else{
            var toBreak = false;
            for(var i in arrayVal){
                if(arrayVal[i]['Field_Name__c'] == selectedobject.Field_Name__c){
                    helper.showToast('This field is already added', 'warning', 'Caution!');
                    toBreak = true;
                }
            }
            if(!toBreak){
                arrayVal.push(selectedobject);
                component.set("v.updatedList", arrayVal);
                component.set("v.isVisible", false);
                component.set("v.newVal", undefined);
                component.set("v.currentVal", undefined);
                component.set("v.fieldLabel", undefined);
                component.set("v.fieldName", undefined);
                component.set("v.fieldType", undefined);
                helper.showToast('Added Successfully', 'success', 'Success!');
            }
        }
    },
    
    removeRow : function(component, event, helper) {
        var currentRow = parseInt(event.currentTarget.getAttribute('data-row-index'));
        var updatedList = component.get("v.updatedList");
        updatedList.splice(currentRow, 1);
        component.set("v.updatedList", updatedList);
    },
    
    handleSubmit: function(component, event, helper) {
        var action = component.get("c.saveApproval");
        action.setParams({ lstToUpdate : component.get("v.updatedList"), recId : component.get("v.entityId")});
        action.setCallback(this, function(response) {
            var state = response.getState();
            if (state === "SUCCESS") {
                component.set("v.updatedList", undefined);
                helper.showToast('Submitted Successfully', 'success', 'Success!');
            }
        });
        $A.enqueueAction(action);
        
        window.setInterval(
            $A.getCallback(function() {
                var dismissActionPanel = $A.get("e.force:closeQuickAction");
                dismissActionPanel.fire();
            }), 5000
        );
    }
})