({
    UpdateCMP : function(component, event, helper) {
        var evt = component.getEvent("ContactApprovalOptionEventt");
        evt.setParams({"selectedOption" : 'Edit'});
        evt.fire();
	},
    DeleteCMP : function(component, event, helper) {
        var evt = component.getEvent("ContactApprovalOptionEventt");
        evt.setParams({"selectedOption" : 'Delete'});
        evt.fire();
	}
})