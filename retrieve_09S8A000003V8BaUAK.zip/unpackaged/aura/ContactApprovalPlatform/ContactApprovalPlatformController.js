({
    doInit : function(component, event, helper) {
        var action = component.get("c.getApprovalRequest");
        action.setCallback(this, function(response) {
            var state = response.getState();
            if (state === "SUCCESS") {
                component.set("v.contactApprovalList", response.getReturnValue());
                helper.toggleSpinner(component);
            }
        });
        $A.enqueueAction(action);
    },
    
    handleApprove: function(component, event, helper) {
        helper.toggleSpinner(component);
        var approvalList = component.get("v.contactApprovalList");
        var currentRow = parseInt(event.currentTarget.getAttribute('data-row-index'));
        var updateConId = approvalList[currentRow].Id;
        var action = component.get("c.handleApproveReject");
        action.setParams({ conUpdateId : updateConId, ApproveOrReject : 'Approve'});
        action.setCallback(this, function(response) {
            var state = response.getState();
            if (state === "SUCCESS") {
                helper.toggleSpinner(component);
                if(response.getReturnValue() == 'Approved Successfully'){
                    helper.showToast(response.getReturnValue(), 'success', 'SUCCESS!');
                    approvalList.splice(currentRow, 1);
                    component.set("v.contactApprovalList", approvalList);
                }else{
                    helper.showToast(response.getReturnValue(), 'error', 'ERROR!');
                }
            }else if(state == "ERROR"){
                var errors = response.getError();                      
                helper.showToast(errors[0].message, 'error', 'ERROR!');
                helper.toggleSpinner(component);
            }
                else{
                    helper.toggleSpinner(component);
                    console.log('Server side issue..');
                }
        });
        $A.enqueueAction(action);
    },
    
    handleReject: function(component, event, helper) {
        helper.toggleSpinner(component);
        var approvalList = component.get("v.contactApprovalList");
        var currentRow = parseInt(event.currentTarget.getAttribute('data-row-index'));
        var updateConId = approvalList[currentRow].Id;
        var action = component.get("c.handleApproveReject");
        action.setParams({ conUpdateId : updateConId, ApproveOrReject : 'Reject'});
        action.setCallback(this, function(response) {
            var state = response.getState();
            if (state === "SUCCESS") {
                helper.toggleSpinner(component);
                if(response.getReturnValue() == 'Rejected Successfully'){
                    helper.showToast(response.getReturnValue(), 'success', 'SUCCESS!');
                    approvalList.splice(currentRow, 1);
                    component.set("v.contactApprovalList", approvalList);
                }else{
                    helper.showToast(response.getReturnValue(), 'error', 'ERROR!');
                }
            }
            else if(state == "ERROR"){
                var errors = response.getError();                      
                helper.showToast(errors[0].message, 'error', 'ERROR!');
                helper.toggleSpinner(component);
            }
                else{
                    helper.toggleSpinner(component);
                    console.log('Server side issue..');
                }
        });
        $A.enqueueAction(action);
    }
})