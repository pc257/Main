({
    doInit : function(component, event, helper){
         alert('call fetchContent');
        component.set('v.mycolumns', [
            {label: 'Title', fieldName: 'Title', type: 'text'}, 
            {label: 'FileType', fieldName: 'FileType', type: 'Text'},
            {label: 'Description', fieldName: 'Description', type: 'text'}
        ]);
        var action = component.get("c.getContent");
        action.setParams({
            "contentDocumentId" : component.get("v.recordId")
        });
       action.setCallback(this, function(response){
            var state = response.getState();
            if (state === "SUCCESS") {
               var records =response.getReturnValue();
                 component.set("v.contList", records)             
            }
        });
        $A.enqueueAction(action);
    
    },
    
    showSendDocument : function(component, event, helper) {
       
        var display = component.set("v.showWindow", true);
        console.log("***"+display);
    },
    openModel: function(component, event, helper) {
      component.set("v.isModalOpen", true);
   },
    closeModel: function(component, event, helper) {
      component.set("v.isModalOpen", false);
   },
  
   submitDetails: function(component, event, helper) {
      component.set("v.isModalOpen", false);
   },
     openModelUprate: function(component, event, helper) {
      component.set("v.openModelUprate", true);
   },
     closeModelUprate: function(component, event, helper) {
      component.set("v.openModelUprate", false);
   },
    
    openModelDownrate: function(component, event, helper) {
      component.set("v.openModelDownrate", true);
   },
    
     closeModelDownrate: function(component, event, helper) {
      component.set("v.openModelDownrate", false);
   },
    
    handleRecordUpdated : function(component, event, helper){
        
    },
    
    
    download: function(component, event, helper) {
        var recordId = component.get("v.recordId");
        
      /* var vfUrl = '/sfc/servlet.shepherd/document/download/'+recordId;
        var urlEvent = $A.get("e.force:navigateToURL");
        
        urlEvent.setParams({
            "url": vfUrl
        });
        urlEvent.fire();*/
    
        
            window.location= "/sfc/servlet.shepherd/document/download/"+recordId;
    },
    
    
    sendMail: function(component, event, helper) {
      // 	alert('enter sendemail');
        var getEmail = component.get("v.email");
        var getSubject = component.get("v.subject");
        var getbody = component.get("v.body");
        var getattachment = component.get("v.file");
        if ($A.util.isEmpty(getEmail) || !getEmail.includes("@")) {
            alert('Please Enter valid Email Address');
        } else {
            helper.sendHelper(component, getEmail, getSubject, getbody);
        }
    },
  
    closeMessage: function(component, event, helper) {
        component.set("v.mailStatus", false);
        component.set("v.email", null);
        component.set("v.subject", null);
        component.set("v.body", null);
        component.set("v.fiel", null);
    },
    
})