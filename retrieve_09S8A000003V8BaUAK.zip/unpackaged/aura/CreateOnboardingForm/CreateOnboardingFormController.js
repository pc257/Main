({
	createNewOnboardingForm: function(component, event, helper) {
        var recordTypeId = component.find("selectid").get("v.value");
        // alert('recordTypeId ---->> ' + recordTypeId);
        $A.get('e.force:closeQuickAction').fire();
        var createRecordEvent = $A.get("e.force:createRecord");
        createRecordEvent.setParams({
            "entityApiName":"Onboarding_Form__c",
            "Account__c":component.get("v.accountId")
        });
        createRecordEvent.fire();
    }
})