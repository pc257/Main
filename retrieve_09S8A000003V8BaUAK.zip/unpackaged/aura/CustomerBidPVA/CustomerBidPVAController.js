({
    doInit : function(component, event, helper) {
        helper.getColumns(component);
        helper.getTotalNumberOfAgreements(component);
        helper.getAgreements(component, event, 0);
    },
    
    loadMoreAgreements: function (component, event, helper) {
        event.getSource().set("v.isLoading", true);
        var currentList = component.get("v.agreementList");
        if(currentList && currentList.length < component.get("v.totalNumberOfRows")){
            helper.getAgreements(component, event, currentList.length);
        }
        if(currentList.length == component.get("v.totalNumberOfRows"))
            component.set("v.enableInfiniteLoading", false);
    },    
    
})