({
    getAgreements : function(component, event, offset) {
        var currentOpptyId=component.get("v.recordId");
        var action = component.get("c.getPVARecord");
        action.setParams({
            oppId : currentOpptyId,
            recordLimit: component.get("v.rowLimit"),
            recordOffset: offset
        });
        action.setCallback(this, function(response){
            var state = response.getState();
            if (state === "SUCCESS") {
                var records= response.getReturnValue();
                var url = location.href;  // entire url including querystring - also: window.location.href;
                var baseURL = url.substring(0, url.indexOf('/', 14)) + "/lightning/r/";
                records.forEach(function(record){
                    record.linkname = '/'+record.Id;
                    if(record.Original_Agreement__c){
                        record.Original = baseURL + 'ABC_Agreement__c/'+record.Original_Agreement__c + '/view';
                        record.OriginalName = record.Original_Agreement__r.Name;  
                    }
                });
                var currentList = component.get("v.agreementList");
                if(currentList)
                    currentList = currentList.concat(records);
                else
                    currentList = records;
                component.set("v.agreementList", currentList);
                event.getSource().set("v.isLoading", false);
            }
        });
        $A.enqueueAction(action);
    },
    
    getTotalNumberOfAgreements : function(component) {
        var action = component.get("c.getTotalPVARecords");
        action.setParams({
            oppId: component.get("v.recordId")
        });
        action.setCallback(this, function(response) {
            var state = response.getState();
            if (state === "SUCCESS" ) {
                var resultData = response.getReturnValue();
                component.set("v.totalNumberOfRows", resultData);
            }
        });
        $A.enqueueAction(action);
    },
    
    getColumns : function(component) {
        component.set('v.columns', [
            {label: 'ABC Agreement', fieldName: 'linkname', type: 'url', typeAttributes: {label: { fieldName: 'Name' }, target: '_blank'}},
            {label: 'Agreement Type', fieldName: 'Agreement_Type__c', type: 'text'},
            {label: 'Agreement Effective Date', fieldName: 'Cubixx_Agreement_Effective_Date__c', type: 'Date'},
            {label: 'Agreement Expiration Date', fieldName: 'Agreement_Expiration_Date__c', type: 'Date'},
            {label: 'Termination Date', fieldName: 'Termination_Date__c', type: 'Date'},
            {label: 'Agreement Status', fieldName: 'Cubixx_Agreement_Status__c', type: 'Date'},
            {label: 'Pricing Program', fieldName: 'Pricing_Program__c', type: 'Text'},
            {label: 'Original Agreement', fieldName: 'Original', type: 'url', typeAttributes: {label: { fieldName: 'OriginalName' }, target: '_blank'}}
        ]);
    }
})