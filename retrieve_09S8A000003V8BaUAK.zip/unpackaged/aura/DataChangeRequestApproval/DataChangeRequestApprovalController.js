({
    doInit : function(component, event, helper) {
        var action = component.get("c.getApprovalRequestForCase");
        action.setParams({ caseId : component.get("v.recordId")});
        action.setCallback(this, function(response) {
            var state = response.getState();
            if (state === "SUCCESS") {
                var wrapper =  response.getReturnValue();
                var authority = wrapper.hasAuthority;
                var dcrArray = wrapper.dcrList;
                for(var i in dcrArray){
                    if(dcrArray[i].Status__c == 'Pending' && authority){
                        dcrArray[i]['toDisable'] = false;
                    }else{
                        dcrArray[i]['toDisable'] = true;
                    }
                }
                component.set("v.contactApprovalList", dcrArray);
                helper.toggleSpinner(component);
            }else{
                helper.toggleSpinner(component);
            }
        });
        $A.enqueueAction(action);
    },
    
    handleApprove: function(component, event, helper) {
        helper.toggleSpinner(component);
        var approvalList = component.get("v.contactApprovalList");
        var currentRow = parseInt(event.currentTarget.getAttribute('data-row-index'));
        var updateConId = approvalList[currentRow].Id;
        var action = component.get("c.handleApproveReject");
        action.setParams({ conUpdateId : updateConId, ApproveOrReject : 'Approve'});
        action.setCallback(this, function(response) {
            var state = response.getState();
            if (state === "SUCCESS") {
                helper.toggleSpinner(component);
                if(response.getReturnValue() == 'Approved Successfully' 
                   || response.getReturnValue() == 'Deleted Request Processed Successfully'){
                    helper.showToast(response.getReturnValue(), 'success', 'SUCCESS!');
                    approvalList[currentRow].Status__c = 'Approved';
                    approvalList[currentRow]['toDisable'] = true;
                    if(approvalList[currentRow].To_Delete__c == true){
                        approvalList[currentRow].Message__c = 'Delete Approved, Please delete the record manually.';
                    }else{
                        approvalList[currentRow].Message__c = 'Update Approved and Processed.';
                    }
                    
                    component.set("v.contactApprovalList", approvalList);
                }else{
                    helper.showToast(response.getReturnValue(), 'error', 'ERROR!');
                }
            }else if(state == "ERROR"){
                var errors = response.getError();                      
                helper.showToast(errors[0].message, 'error', 'ERROR!');
                helper.toggleSpinner(component);
            }
                else{
                    helper.toggleSpinner(component);
                    console.log('Server side issue..');
                }
        });
        $A.enqueueAction(action);
    },
    
    handleReject: function(component, event, helper) {
        helper.toggleSpinner(component);
        var approvalList = component.get("v.contactApprovalList");
        var currentRow = parseInt(event.currentTarget.getAttribute('data-row-index'));
        var updateConId = approvalList[currentRow].Id;
        var action = component.get("c.handleApproveReject");
        action.setParams({ conUpdateId : updateConId, ApproveOrReject : 'Reject'});
        action.setCallback(this, function(response) {
            var state = response.getState();
            if (state === "SUCCESS") {
                helper.toggleSpinner(component);
                if(response.getReturnValue() == 'Rejected Successfully'){
                    helper.showToast(response.getReturnValue(), 'success', 'SUCCESS!');
                    approvalList[currentRow].Status__c = 'Rejected';
                    approvalList[currentRow]['toDisable'] = true;
                    if(approvalList[currentRow].To_Delete__c == true){
                        approvalList[currentRow].Message__c = 'Delete Rejected.';
                    }else{
                        approvalList[currentRow].Message__c = 'Update Rejected.';
                    }
                    component.set("v.contactApprovalList", approvalList);
                }else{
                    helper.showToast(response.getReturnValue(), 'error', 'ERROR!');
                }
            }
            else if(state == "ERROR"){
                var errors = response.getError();                      
                helper.showToast(errors[0].message, 'error', 'ERROR!');
                helper.toggleSpinner(component);
            }
                else{
                    helper.toggleSpinner(component);
                    console.log('Server side issue..');
                }
        });
        $A.enqueueAction(action);
    }
})