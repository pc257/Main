({
    doInit: function(component, event, helper){
        helper.drawColunms(component, event, helper);
        helper.getDefinitiveData(component, event, helper);
    },
    
    showSpinner: function(component, event, helper){
        component.set("v.Spinner", true);
    },
    
    hideSpinner : function(component, event, helper){   
        component.set("v.Spinner", false);
    },
    
    changeView:function(component,event,helper){
        helper.changeView(component, event, helper);
    },
    
    handleRowAction : function(component, event, helper){
        var action = event.getParam('action');
        var row = event.getParam('row');
        
        switch (action.name) {
            case 'show_details':
                $A.createComponent(
                    //"c:AccountOpportunityHierarchy", {
                    "c:AccountWithOppHierarchyViewer", {
                        "ddGrandParentId": row.DDGrandParentId,
                        "ddId": row.DDSelfId
                    },
                    function(detailsModal, status, errorMessage){
                        if(status === "SUCCESS"){
                            var detailsCmp = component.find("details");
                            var body = detailsCmp.get("v.body");
                            body.push(detailsModal);
                            detailsCmp.set("v.body", body);
                        }else if(status === "ERROR"){
                            
                        }
                    }
                );
                break;
        }
    },
    
    downloadCsvFile:function(component,event,helper){
        helper.downloadCsvFile(component, event, helper);
    },
})