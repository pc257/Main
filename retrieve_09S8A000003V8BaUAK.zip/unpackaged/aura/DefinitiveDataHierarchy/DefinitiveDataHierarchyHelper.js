({
    drawColunms : function(component, event, helper) {
        // Row level actions
        var rowActions = [
            {label: 'Show Details', name: 'show_details' }
        ];
        
        var columns = [
            {type: "url", fieldName: "DDURL", label: "Name", initialWidth: 350, typeAttributes: {label: {fieldName: "Name"}}}, 
            {type: "url", fieldName: "AccountURL", label: "Account Name", initialWidth: 350, typeAttributes: {label: {fieldName: "AccountName"}}}, 
            {type: "currency", fieldName: "PharmacyCosts", label: "Pharmacy Costs", typeAttributes: {currencyCode: "USD"}}, 
            {type: "text", fieldName: "BillingAddressStreet", label: "Billing Street"}, 
            {type: "text", fieldName: "BillingAddressCity", label: "Billing City"}, 
            {type: "text", fieldName: "BillingAddressState", label: "Billing State"}, 
            {type: "text", fieldName: "BillingAddressZip", label: "Billing Zip"},
            {type: "currency", fieldName: "AccountTotalRevenue", label: "Total ABC Revenue",typeAttributes: {currencyCode: "USD"}},
            // CRM :20102 (Total Gross Profit field not in use)
            // {type: "currency", fieldName: "AccountTotalGrossProfit", label: "Total ABC Gross Profit",typeAttributes: {currencyCode: "USD"}}, 
            {type: "text", fieldName: "OpportunityCountText", label: "Opportunity Count"},
            {type: "currency", fieldName: "TotalOpportunityAmount", label: "Opportunity Amount Total",typeAttributes: {currencyCode: "USD"}}, 
            {type: "action", typeAttributes: { rowActions: rowActions }}
        ];
        
        component.set("v.gridColumns", columns);
    },
    
    getDefinitiveData : function(component, event, helper) {
        var action = component.get("c.getDefinitiveData");
        action.setParams({AccountId : component.get('v.recordId')});
        action.setCallback(this, function(data){
            var state = data.getState();
            if(state == "SUCCESS"){
                var xData = data.getReturnValue();
                component.set("v.accountRecordsData",xData);
                var xHasChild = {};
                var selectedRows = [];
                xData.forEach(function(item){
                    if(item.IsSelected){selectedRows.push(item.Id);}
                    xHasChild[item.DDParentId] = xHasChild.hasOwnProperty(item.DDParentId);
                });
                var xRaw = {};
                if(xData && xData.length > 0){
                    xRaw["000000"] = {DDParentId: "000000", DDSelfId: xData[0].DDGrandParentId, _children: []};
                    
                    xData.forEach(v => xRaw[v.DDSelfId] = {
                        Id: v.Id, 
                        Name: v.Name, 
                        AccountId: v.AccountId,
                        DDURL: v.DDURL, 
                        AccountName: v.AccountName, 
                        AccountURL: v.AccountURL,
                        // CRM :20102 (Total Gross Profit field not in use)
                        // AccountTotalGrossProfit:v.AccountTotalGrossProfit,
                        PharmacyCosts: v.PharmacyCosts, 
                        BillingAddressStreet: v.BillingAddressStreet,  
                        BillingAddressCity: v.BillingAddressCity, 
                        BillingAddressState: v.BillingAddressState, 
                        BillingAddressZip: v.BillingAddressZip, 
                        AccountTotalRevenue: v.AccountTotalRevenue,
                        DDGrandParentId: v.DDGrandParentId, 
                        DDSelfId: v.DDSelfId, 
                        DDParentId: v.DDParentId, 
                        SelfOpportunityCount: parseInt(v.OpportunityCount),
                        SelfOpportunityTotalAmount: parseFloat(v.OpportunityTotalAmount),
                        get ChildOpportunityCount(){
                            if(this.hasOwnProperty("_children")){
                                var iCount = 0;
                                this["_children"].forEach(function(iChild){
                                    iCount += parseInt(iChild.TotalOpportunityCount);
                                });
                                return iCount;
                            }
                            return 0;
                        },
                        get ChildOpportunityAmount(){
                            if(this.hasOwnProperty("_children")){
                                var opportunityAmount = 0;
                                this["_children"].forEach(function(iChild){
                                    opportunityAmount += parseFloat(iChild.TotalOpportunityAmount);
                                });
                                return opportunityAmount;
                            }
                            return 0;
                        },
                        get TotalOpportunityAmount(){
                            return parseFloat(this.SelfOpportunityTotalAmount) + parseFloat(this.ChildOpportunityAmount);
                            //return parseFloat(this.ChildOpportunityAmount);
                        },
                        get TotalOpportunityCount(){
                            return parseInt(this.SelfOpportunityCount) + parseInt(this.ChildOpportunityCount);
                        },
                        get OpportunityCountText(){
                            //return " " + this.SelfOpportunityCount + " [" + this.TotalOpportunityCount + "]";
                            return " " + this.TotalOpportunityCount;
                        }
                    });
                    xData.forEach(function(item){
                        if(xHasChild.hasOwnProperty(item.DDParentId)){
                            xRaw[item.DDParentId]["_children"] = [];
                        }
                    });
                    
                    xData.forEach(v => xRaw[v.DDParentId]._children.push(xRaw[v.DDSelfId]));
                    component.set("v.gridDataLong", xRaw["000000"]._children[0]);                    
                    if(selectedRows && selectedRows.length > 0){
                        var selectedAccount = helper.searchTree(xRaw["000000"]._children[0], selectedRows[0]);
                        component.set("v.gridDataShort", selectedAccount);
                    }
                    component.set('v.selectedRows', selectedRows);
                    helper.changeView(component, event, helper);
                }
            }
        });       
        $A.enqueueAction(action);
    },
    
    searchTree : function(element, AccountId){
        if(element.Id == AccountId){
            return element;
        }else if(element._children != null){
            var result = null;
            for(var iCount=0; result == null && iCount < element._children.length; iCount++){
                result = this.searchTree(element._children[iCount], AccountId);
            }
            return result;
            
        }
        return null;
    },
    
    changeView : function(component, event, helper){
        var extendedView = component.find("extendedView").get("v.checked");
        component.set("v.gridData", extendedView ? component.get("v.gridDataLong") : component.get("v.gridDataShort"));
        
        window.setTimeout(
            $A.getCallback(function(){
                var tree = component.find('treeGrid');
                tree.expandAll();
                component.set('v.selectedRows', component.get("v.selectedRows"));
            }), 200
        );
    },
    
    downloadCsvFile : function(component, event, helper){
        var exportAccountdata=component.get("v.gridDataLong");
        
        var fArray = [];
        helper.convertTreeToFlatArray(exportAccountdata[0], 1, 'Id', '_children', fArray, {});
        
        var refined = [];
        var toDelete = ["level", "Id", "AccountId", "AccountURL", "DDURL", "DDParentId", "DDGrandParentId", "DDSelfId", 
                        "ChildOpportunityAmount", "ChildOpportunityCount", "OpportunityCountText", "SelfOpportunityCount", 
                        "SelfOpportunityTotalAmount"];
        for(var iChild = 0; iChild < fArray.length; iChild++){
            var row = fArray[iChild];
            row.Name = helper.adjustName(row);
            for(var iCol = 0; iCol < toDelete.length; iCol++){
                delete row[toDelete[iCol]];
            }
            refined.push(row);
        }
        
        var xcsv = helper.convertArrayOfObjectsToCSV({data: refined, columnDelimiter: '","', lineDelimiter: "\"" + "\n" + "\""});
        var csv = "\"" + xcsv.substring(0, xcsv.length - 1);
        if(csv == null) return;
        
        var hiddenElement = document.createElement('a');
        hiddenElement.href = 'data:text/csv;charset=utf-8,' + encodeURI(csv);
        hiddenElement.target = '_self'; //
        hiddenElement.download = 'DefinitiveDataHierarchy.csv';  
        document.body.appendChild(hiddenElement);
        hiddenElement.click();
    },
    
    convertTreeToFlatArray : function(tree, level, key, childKey, collection, nodeVisited){
        if(!nodeVisited.hasOwnProperty(tree[key])){
            nodeVisited[tree[key]] = true;
            var xNode = {};
            Object.keys(tree).forEach(function(iKey){
                if(iKey != childKey){
                    xNode[iKey] = tree[iKey];
                }
            });
            xNode["level"] = level++;
            collection.push(xNode);
        }
        if(tree[childKey]){
            for(var iChild = 0; iChild < tree[childKey].length; iChild++){
                this.convertTreeToFlatArray(tree[childKey][iChild], level, key, childKey, collection, nodeVisited);
            }
        }
        return;
    },
    
    adjustName : function(row){
        var xString = '';
        for(var iSpace = 1; iSpace < (row.level - 1) * 6; iSpace++) {
            xString += ' ';
        }
        xString += row.Name;
        return xString;
    },
    
    convertArrayOfObjectsToCSV : function(args) {
        var data = args.data || null;
        if(data == null || !data.length){return null;}
        
        var columnDelimiter = args.columnDelimiter || ',';
        var lineDelimiter = args.lineDelimiter || '\n';

        var xkeys = [];
        for(var iCount = 0; iCount < data.length; iCount++){
            var row = data[iCount];
            var cols = Object.keys(row);
            for(var iCol = 0; iCol < cols.length; iCol++){
                xkeys.push(cols[iCol]);
            }
        }
        
        var keys = xkeys.filter(function(item, pos){
            return xkeys.indexOf(item) == pos;
        });
        
        var result = "";
        result += keys.join(columnDelimiter);
        result += lineDelimiter;
        
        data.forEach(function(item){
            var ctr = 0;
            keys.forEach(function(key){
                if(ctr > 0) result += columnDelimiter;
                result += item[key] == undefined ? "" : item[key];
                ctr++;
            });
            result += lineDelimiter;
        });
        return result;
    }
    
})