({
	/*
	init : function(component, event, helper) {
		var accountVisPageRef = component.get("v.pageReference");
        var accountId = component.get("v.pageReference").state.c__AccountId;
        component.set("v.accId", accountId);   
        
    },
    handleClick: function(cmp, event, helper) {
        var navService = cmp.find("navService");
        // Uses the pageReference definition in the init handler
        var pageReference = {
            type: "standard__navItemPage",
            attributes: {
                "apiName": "HS_Opportunity_Management"
            }
        };
        event.preventDefault();
        navService.navigate(pageReference);
    }
    */
})