({
    doInit : function(component, event, helper){
        helper.doInit(component, event, helper);
    },
    
    search : function(component, event, helper){
        component.set("v.contentversionList", []);
        helper.search(component, event, helper);
    }
})