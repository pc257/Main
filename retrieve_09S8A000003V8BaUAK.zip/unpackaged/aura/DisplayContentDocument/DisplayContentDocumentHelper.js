({
    doInit : function(component, event, helper){
        var optionVal = [
            {'label': 'Search All', 'value': 'all'}, 
            {'label': 'HS Only', 'value': 'Health Systems Content Library', },
            {'label': 'CSP Only', 'value': 'Community & Specialty Pharmacy Content Library'}
        ];
        component.set("v.options", optionVal);
        component.set("v.minHeightList", 'min-height: '+(screen.height*0.45)+'px;');
        component.set("v.minHeightFilter", 'min-height: '+(screen.height*0.32)+'px;');
    },
    
    search : function(component, event, helper){
        this.toggleSpinner(component);
        var searchT = component.find("enter-search").get("v.value");
        var action =component.get("c.getContentVersion");  
        action.setParams({"searchTerm" : searchT, "searchArea" : component.get("v.libraryfilter")});
        action.setCallback(this, function(res){
            var state = res.getState();
            if (state === "SUCCESS") {
                var returnList = this.sortByRelavance(res.getReturnValue());
                for(var i in returnList){
                    returnList[i]['FileExtensionIcon'] = this.fileExtensionIcon(returnList[i]['FileExtension']);
                }
                component.set("v.contentversionList", returnList);
                this.toggleSpinner(component);
            }else if(state === "ERROR"){
                this.toggleSpinner(component);
                alert('Error calling server side..');
                
            }else{
                this.toggleSpinner(component);
                alert('Error: contact system admin');
            }
        });
        $A.enqueueAction(action);
    },
    
    toggleSpinner: function(component){
        var spinner = component.find("loading_spinner");
        $A.util.toggleClass(spinner, "slds-hide");
    },
    
    fileExtensionIcon: function(fExt){
        var fileExtReturn;
        
        if(fExt == 'pdf'){
            fileExtReturn = 'doctype:pdf';
        }else if (fExt == 'mp3' || fExt == 'mp4' || fExt == 'wav' || fExt == 'png' || fExt == 'jpg' || fExt == 'm4a' || fExt == 'wmv'
                  || fExt == 'avi' || fExt == 'mov'){
            fileExtReturn = 'doctype:video';
        }
            else if(fExt == 'docx' || fExt == 'word'){
                fileExtReturn = 'doctype:word';
            }
                else if(fExt == 'xlsx' || fExt == 'xlsm'){
                    fileExtReturn = 'doctype:excel';
                }
                    else if(fExt == 'pptx'){
                        fileExtReturn = 'doctype:ppt';
                    }
                        else if(fExt == 'html' || fExt == 'htm' || fExt == 'url'){
                            fileExtReturn = 'doctype:link';
                        }else{
                            fileExtReturn = 'doctype:unknown';
                        }
        return fileExtReturn;
    },
    
    sortByRelavance : function(docList){
        docList.sort(function(a, b) { return (parseInt(a.order) < parseInt(b.order)) ? 1 : (parseInt(a.order) > parseInt(b.order)) ? -1 : 0});
        return docList;
    },
    
    isBlank : function(val){
        return(val == undefined || val == '' || val == "" || val == null);
    }
})