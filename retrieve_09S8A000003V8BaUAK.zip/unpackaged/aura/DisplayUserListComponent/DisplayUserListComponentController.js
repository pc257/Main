({
    getUsers: function(component, event) {
        var action = component.get("c.getUser");
        action.setCallback(this, function(response) {
            var state = response.getState();
            if (state === "SUCCESS") {
                var userListResp = response.getReturnValue();
                var userListObj = [];
                var i = 0;
                for(i=0; i < userListResp.length; i++){
                    userListObj.push({
                        'label': userListResp[i].Name,
                        'value': userListResp[i].Email
                    });
                }
                component.set('v.userList', userListObj);
            }
        });
        $A.enqueueAction(action);
    },
    handleUserSelection: function (component, event) {
        var selectedUser = event.getParam("value");
        if(selectedUser.length > 4){
            var toastEvent = $A.get("e.force:showToast");
            toastEvent.setParams({
                title : 'Error',
                message: 'Maximum 4 users are allowed',
                type: 'error',
            });
            toastEvent.fire();
            return false;
        }
        var emailIdString = selectedUser.toString();
        component.set('v.emailIds', emailIdString);
    }
})