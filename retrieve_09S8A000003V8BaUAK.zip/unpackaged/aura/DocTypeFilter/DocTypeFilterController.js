({
    handleChange : function(component, event, helper) {
        var selVal = component.get("v.SelectedDocType");
        var appEvent = $A.get("e.c:DocumentSearchFileTypeEvent"); 
        appEvent.setParams({"selectedFileType" : selVal}); 
        appEvent.fire();	
    },
    clearAll : function(component, event, helper) {
        component.set("v.SelectedDocType", []);
        var appEvent = $A.get("e.c:DocumentSearchFileTypeEvent"); 
        appEvent.setParams({"selectedFileType" : []}); 
        appEvent.fire();
    }
})