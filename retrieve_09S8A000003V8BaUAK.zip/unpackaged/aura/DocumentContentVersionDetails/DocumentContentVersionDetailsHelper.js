({
    doInit : function(component, event, helper){
        var conDoc = component.get("v.contentDoc");
        var conSizeStr = "0 MB";
        
        if(!this.isBlank(conDoc.LatestPublishedVersion.ContentSize)){
            var conSize = parseInt(conDoc.LatestPublishedVersion.ContentSize/1000000);
            conSizeStr = conSize.toString()+" MB";
        }
        
        component.set("v.contentDocSize", conSizeStr);
        
        if(!this.isBlank(conDoc.LatestPublishedVersion.CreatedDate)){
            var CDateString = conDoc.LatestPublishedVersion.CreatedDate;
            component.set("v.contentUploadDate", $A.localizationService.formatDate(CDateString));
        }
        
        if(!this.isBlank(conDoc.LatestPublishedVersion.Content_Review_Date__c)){
            var CRdateString = conDoc.LatestPublishedVersion.CreatedDate;
            component.set("v.contentExpDate", $A.localizationService.formatDate(CRdateString));
        }
    },
    
    isBlank : function(val){
        return(val == undefined);
    }
})