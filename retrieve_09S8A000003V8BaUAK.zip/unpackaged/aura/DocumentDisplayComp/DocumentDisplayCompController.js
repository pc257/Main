({
    loadForms: function(component, event, helper) {
        helper.onLoad(component, event);
    },
    selectAll: function(component, event, helper) {
        var selectedHeaderCheck = event.getSource().get("v.value");
        var getAllId = component.find("boxPack");
        if(! Array.isArray(getAllId)){
            if(selectedHeaderCheck == true){
                component.find("boxPack").set("v.value", true);
            }else{
                component.find("boxPack").set("v.value", false);
            }
        }else{
            
            if (selectedHeaderCheck == true) {
                for (var i = 0; i < getAllId.length; i++) {
                    component.find("boxPack")[i].set("v.value", true);
                }
            } else {
                for (var i = 0; i < getAllId.length; i++) {
                    component.find("boxPack")[i].set("v.value", false);
                }
            }
        }
    },

    handleReturn:function(cmp, event){
        var selectedOptionValue = cmp.get("v.selectedDoc");
        var retDetail = cmp.get("v.returnDetail");
        var buttonLabel = cmp.get("v.returnCancelButtonLabel");
        cmp.set("v.showSpinner",true);
        var action = cmp.get("c.returnDocument");
        action.setParams({
            lineItemId: selectedOptionValue.lineItemId,
            onbId: selectedOptionValue.onbId,
            fileName: selectedOptionValue.docName,
            path : selectedOptionValue.redirectionURL,
            uri : selectedOptionValue.fileUri,
            retDet : retDetail
        });
        action.setCallback(this, function(response) {
            var state = response.getState();
            
            if (state === "SUCCESS") {
                var toastMessage = 'Document is cancelled Successfully';
                if(buttonLabel == 'Return'){
                    toastMessage = 'Document is returned Successfully'
                }
                var response = response.getReturnValue();
                var toastEvent = $A.get("e.force:showToast");
                toastEvent.setParams({
                    title : 'Success',
                    message: toastMessage,
                    type: 'Success',
                });  
                toastEvent.fire();
                cmp.set("v.showFormModal", false);
                cmp.set("v.returnDetail", '');
                $A.get('e.force:refreshView').fire();
                
            } else if (state === "INCOMPLETE") {
                
            } else if (state === "ERROR") {
                var errors = response.getError();
                if (errors) {
                    if (errors[0] && errors[0].message) {
                        console.log("Error message: " + errors[0].message);
                    }
                } else {
                    console.log("Unknown error");
                }
            }
            cmp.set("v.showSpinner",false);
        });
        $A.enqueueAction(action);
    },
    showFormReturnModal : function(component, event, helper) {
        component.set("v.selectedDoc", event.getSource().get("v.name"));
        var buttonLabel = event.getSource().get("v.label");
        if(buttonLabel == 'Cancel'){
            component.set("v.returnDetailLabel", 'Cancellation Details');
            component.set("v.returnCancelButtonLabel", 'Cancel');
        }else{
            component.set("v.returnDetailLabel", 'Return Details');
            component.set("v.returnCancelButtonLabel", 'Return');
        }
        component.set("v.showFormModal", true);
    },
    openFileUploadModal : function(component, event, helper) {
        component.set("v.showFileUploadModal", true);
    },
    closeFileUploadModal : function(component, event, helper) {
        component.set("v.showFileUploadModal", false);
    },
    closeModel: function(component, event, helper) {
        
        component.set("v.returnDetail", '');
        component.set("v.showFormModal", false);
    },
    showSpinner: function (component, event, helper){
        var spinner = component.find("mySpinner");
        $A.util.removeClass(spinner, "slds-hide");
    },
    hideSpinner: function (component, event, helper){
        var spinner = component.find("mySpinner");
        $A.util.addClass(spinner, "slds-hide");
    },
    handleFilesChange: function(component, event, helper) {      
        if (component.find("fileId").get("v.files").length > 0) {
            component.set("v.showSpinner",true);
            helper.uploadHelper(component, event);
            component.set("v.showSpinner",false);
        } 
    },
})