({
    doInit : function(component, event, helper){
        helper.toggleSpinner(component);
        helper.doInit(component, event, helper);
        helper.toggleSpinner(component);
    },
    
    filterSearch : function(component, event, helper){
        helper.toggleSpinner(component);
        helper.filterSearch(component, event, helper);
        helper.toggleSpinner(component);
    },
    
    sortList : function(component, event, helper){
        helper.toggleSpinner(component);
        helper.sortList(component, event, helper);
        helper.toggleSpinner(component);
    },
    
    filterFileLink : function(component, event, helper){
        helper.toggleSpinner(component);
        helper.filterFileLink(component, event, helper);
        helper.toggleSpinner(component);
    },
    
    filterContentType : function(component, event, helper){
        helper.toggleSpinner(component);
        helper.filterContentType(component, event, helper);
        helper.toggleSpinner(component);
    },
    
    firstPage: function(component, event, helper) {
        helper.toggleSpinner(component);
        helper.navigatePage(component, event, helper, 1);
        helper.toggleSpinner(component);
    },
    
    prevPage: function(component, event, helper) {
        helper.toggleSpinner(component);
        helper.navigatePage(component, event, helper, Math.max(component.get("v.CurrentPage") - 1, 1));
        helper.toggleSpinner(component);
    },
    
    nextPage: function(component, event, helper) {
        helper.toggleSpinner(component);
        helper.navigatePage(component, event, helper, Math.min(component.get("v.CurrentPage") + 1, component.get("v.TotalPages")));
        helper.toggleSpinner(component);
    },
    
    lastPage: function(component, event, helper) {
        helper.toggleSpinner(component);
        helper.navigatePage(component, event, helper, component.get("v.TotalPages"));
        helper.toggleSpinner(component);
    }
})