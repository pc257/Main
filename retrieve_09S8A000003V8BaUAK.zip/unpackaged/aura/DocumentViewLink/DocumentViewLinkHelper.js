({
    doInit : function(component, event, helper){
        component.set("v.maxHeight", 'max-height: '+(screen.height*0.45)+'px;');
        this.sliceData(component, event, helper);
    },
    
    filterSearch : function(component, event, helper){
        var searchKey = component.find("filter-search").get("v.value");   
        var allList =  component.get("v.doclist"); 
        var filteredListIds = [];
        var toDisable = false;
        
        if(allList != undefined){   
            var filtereddata = allList.filter(
                word => (!searchKey) || word.Title.toLowerCase().indexOf(searchKey.toLowerCase()) > -1
            );   
        }
        
        for(var i in filtereddata){
            filteredListIds.push(filtereddata[i]['cvId']);
        }
        for(var i in allList){
            if(filteredListIds.includes(allList[i]['cvId'])){
                allList[i]['isVisible'] = true;
            }else{
                allList[i]['isVisible'] = false;
            }
        }
        
        if(this.isBlank(filtereddata) && !this.isBlank(searchKey)){
            toDisable = true;
        }
        
        if(this.isBlank(searchKey)){
            for(var i in allList){
                allList[i]['isVisible'] = true;
            }
            toDisable = false;
        }  
        component.set("v.noListMessage", toDisable);
        component.set("v.disableSort", toDisable);
        component.set("v.doclist", allList);
        this.sliceData(component, event, helper);
    },
    
    isBlank : function(val){
        return(val == undefined || val == '' || val == "" || val == null);
    },
    
    sortList : function(component, event, helper){
        var picklistval = component.find("sort-type").get("v.value");
        if(picklistval == 'Relevance'){
            this.sortByRelavance(component, event, helper);
        }else if(picklistval == 'Name Ascending'){
            this.sortByNameAsc(component, event, helper);
        }
            else if(picklistval == 'Name Descending'){
                this.sortByNameDesc(component, event, helper);
            }
                else if(picklistval == 'Higest Downloads'){
                    this.sortByHighestDownloads(component, event, helper);
                }
        this.sliceData(component, event, helper);
    },
    
    sortByRelavance : function(component, event, helper){
        var mainList = component.get("v.doclist");
        mainList.sort(function(a, b) { return (parseInt(a.order) < parseInt(b.order)) ? 1 : (parseInt(a.order) > parseInt(b.order)) ? -1 : 0});
        component.set("v.doclist", mainList);
    },
    
    sortByNameAsc : function(component, event, helper){
        var mainList = component.get("v.doclist");
        mainList.sort(function(a, b) { 
            return ((a.Title).toLowerCase() < (b.Title).toLowerCase()) ? -1 : ((a.Title).toLowerCase() > (b.Title).toLowerCase()) ? 1 : 0
        });
        component.set("v.doclist", mainList);
    },
    
    sortByNameDesc : function(component, event, helper){
        var mainList = component.get("v.doclist");
        mainList.sort(function(a, b) { 
            return ((a.Title).toLowerCase() < (b.Title).toLowerCase()) ? 1 : ((a.Title).toLowerCase() > (b.Title).toLowerCase()) ? -1 : 0
        });
        component.set("v.doclist", mainList);
    },
    
    sortByHighestDownloads : function(component, event, helper){
        var mainList = component.get("v.doclist");
        mainList.sort(function(a, b) { return (parseInt(a.Downloads) < parseInt(b.Downloads)) ? 1 : (parseInt(a.Downloads) > parseInt(b.Downloads)) ? -1 : 0});
        component.set("v.doclist", mainList);
    },
    
    filterFileLink : function(component, event, helper){
        var listFileTypes = event.getParam("selectedFileType");
        var mainList = component.get("v.doclist");
        var hasntList = true;
        
        if(!this.isBlank(listFileTypes)){
            var listFileTypesArray = [];
            var listFileTypesArrayFlat = [];
            for(var i in listFileTypes){
                listFileTypesArray.push(listFileTypes[i].split(","));
            }
            listFileTypesArrayFlat = listFileTypesArray.flat(Infinity);
            for(var i in mainList){
                if(listFileTypesArrayFlat.includes(mainList[i]['FileExtension'])){
                    mainList[i]['isVisibleFExt'] = true;
                }else{
                    mainList[i]['isVisibleFExt'] = false;
                }
            }
        }
        else{
            for(var i in mainList){
                mainList[i]['isVisibleFExt'] = true;
            }
        }
        
        for(var i in mainList){
            if(mainList[i]['isVisibleFExt'] == true){
                hasntList = false;
                break;
            }
        }
        component.set("v.noListMessage", hasntList);
        component.set("v.disableSearchFilter", hasntList);
        component.set("v.disableSort", hasntList);
        component.set("v.doclist", mainList);
        this.sliceData(component, event, helper);
    },
    
     filterContentType : function(component, event, helper){
        var listFileTypes = event.getParam("selectedContentTopic");
        var mainList = component.get("v.doclist");
        var hasntList = true;
        
        if(!this.isBlank(listFileTypes)){
            var listFileTypesArray = [];
            var listFileTypesArrayFlat = [];
            for(var i in listFileTypes){
                listFileTypesArray.push(listFileTypes[i].split(","));
            }
            listFileTypesArrayFlat = listFileTypesArray.flat(Infinity);
            for(var i in mainList){
                if(!this.isBlank(mainList[i]['ContentTopics'])){
                    var conTopicArr = mainList[i]['ContentTopics'].toString().split(";");
                    for(var val in conTopicArr){
                        if(listFileTypesArrayFlat.includes(conTopicArr[val])){
                            mainList[i]['isVisibleTopic'] = true;
                            break;
                        }else{
                            mainList[i]['isVisibleTopic'] = false;
                        }
                    }
                }else{
                    mainList[i]['isVisibleTopic'] = false;
                }
            }
        }
        else{
            for(var i in mainList){
                mainList[i]['isVisibleTopic'] = true;
            }
        }
        
        for(var i in mainList){
            if(mainList[i]['isVisibleTopic'] == true){
                hasntList = false;
                break;
            }
        }
        component.set("v.noListMessage", hasntList);
        component.set("v.disableSearchFilter", hasntList);
        component.set("v.disableSort", hasntList);
        component.set("v.doclist", mainList);
        this.sliceData(component, event, helper);
    },
    
    sliceData : function(component, event, helper){
        
        var PageSize = component.get("v.PageSize");
        var CurrentPage = component.get("v.CurrentPage");
        var doclistAll = component.get("v.doclist");
        var docIdFiltered = [];
        
        for(var i in doclistAll){
            if(doclistAll[i]['isVisible'] == true && doclistAll[i]['isVisibleFExt'] == true && doclistAll[i]['isVisibleTopic'] == true){
                doclistAll[i]['position'] = 1;
                docIdFiltered.push(doclistAll[i]['cvId']);
            }else{
                doclistAll[i]['position'] = 0;
            }
        }
        
        //Sorting to bring the true list forward.
        doclistAll.sort(function(a, b) {
            return (parseInt(a.position) < parseInt(b.position)) ? 1 : (parseInt(a.position) > parseInt(b.position)) ? -1 : 0
        });
        
        if(!this.isBlank(docIdFiltered)){
            var TotalPages = parseInt(docIdFiltered.length / PageSize);
            if(parseInt(docIdFiltered.length % PageSize) > 0){
                TotalPages++;
            }
            component.set("v.TotalPages", TotalPages);
            
            if(CurrentPage > TotalPages){
               CurrentPage =  TotalPages;
                component.set("v.CurrentPage", CurrentPage);
            }            
            
            var fromIndex =((CurrentPage - 1) * PageSize);
            var toIndex = (CurrentPage * PageSize);
            
            for(var index in doclistAll){
                if(docIdFiltered.includes(doclistAll[index]['cvId']) && index >= fromIndex && index < toIndex){
                    doclistAll[index]['indexed'] = true;
                }else{
                    doclistAll[index]['indexed'] = false;
                }
            }
            component.set("v.doclist", doclistAll);
        }
    },
    
    navigatePage : function(component, event, helper, pageno){
        component.set("v.CurrentPage", pageno);
        helper.sliceData(component, event, helper);
    },
    
    toggleSpinner: function(component){
        var spinner = component.find("lightningIconDsli");
        $A.util.toggleClass(spinner, "slds-hide");
    }
})