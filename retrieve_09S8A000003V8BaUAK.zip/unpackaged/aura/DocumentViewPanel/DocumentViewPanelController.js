({
    doInit : function(component, event, helper){
        helper.doInit(component, event, helper);
    },
    
	closeView : function(component, event, helper){
        helper.closeView(component, event, helper);
    }
})