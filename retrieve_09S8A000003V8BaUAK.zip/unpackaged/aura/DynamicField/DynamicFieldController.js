({
	doInit : function(component, event, helper) {
		var Section = component.get("v.Section");
        var ValueSet = component.get("v.ValueSet");
        
        var Fields = [];
        Section.Fields.forEach(function(item){
            item["Value"] = ValueSet["" + item.Field__c + ""].Value;
        });
        
        component.set("v.Section", Section);
        component.set("v.ReadyForRender", true);
	}
})