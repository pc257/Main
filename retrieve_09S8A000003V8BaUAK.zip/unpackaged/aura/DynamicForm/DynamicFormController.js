({
    doInit: function(cmp, event, helper) {
        var responseValue = [];
        var formObj = cmp.get("v.onboardingForm");        
        if(formObj.Has_Dependency__c == true){
            var action = cmp.get("c.getFormLineItems");
            action.setParams({"formName" : formObj.Name,"accountId" : formObj.Account__c});
            action.setCallback(this, function(response) {
                var state = response.getState();
                if (state === "SUCCESS"){
                    responseValue = response.getReturnValue();
                    helper.inithelper(cmp, responseValue, formObj);                    
                }
                else{
                    var errors = response.getError();
                    if (errors) {
                        if (errors[0] && errors[0].message) {
                            console.log("Error message: " + errors[0].message);
                            var toastEvent = $A.get("e.force:showToast");
                            toastEvent.setParams({
                                title : 'Error',
                                message: errors[0].message,
                                type: 'error',
                            });
                            toastEvent.fire();
                        }
                    }
                }
            });
            $A.enqueueAction(action);
        }else{
            helper.inithelper(cmp, responseValue, formObj);
        }
        
        cmp.set('v.mycolumns', [
            { label: 'Name',fieldName:'FileLeafRef',type: 'text'},
            {label: 'Delete',fieldName: 'FileRef',type: 'button', initialWidth: 0, typeAttributes: { label: '', name: 'delete_details', title: '',iconName: "action:close"}}
            
        ]);
        //var action = event.getParam('action');
        //var row = event.getParam('row');
        //helper.fetchData(cmp,row.LineItemId);
    },
    handleNext : function(cmp,event,helper) {
        var OnboardingForm = cmp.get("v.onboardingForm");
        var currentSection = cmp.get("v.sectionName");
        var currentPage = cmp.get("v.pageNumber");
        var formLineItemObject = cmp.get("v.formWrapperObject");
        var sectionSet = cmp.get("v.sectionNameSet");
        var pageSet = cmp.get("v.pageNumberSet");
        var pgIndex = cmp.get("v.pgNumberIndex");
        var pgIndexMap = cmp.get("v.pgNumberIndexMap");
        var goToPreviousPage = false;
        var totalCSRAPercent = cmp.get("v.totalPercent");       
        var nextBtnLabel = cmp.get("v.nextButtonLabel");
        if(OnboardingForm.Status__c == 'Complete' && nextBtnLabel == 'Finish & Submit Form'){
            var successMessage = 'Back to Form Page'
            helper.navigateToFormPage(cmp,OnboardingForm,successMessage);
        }
        var ownerId = '';
        var additionalOwner = '';
        var additionalOwnerLbl;
        var a = pageSet.indexOf(currentPage);
        var formLineItemSectionWise = [];
        var totalPercent = 0;
        var isAddAcc = false;
        if(OnboardingForm.Name != 'Required Uploads - Credit Application'){            
            for(var i=0; i<formLineItemObject.length; i++){
                if(OnboardingForm.Name == 'Additional Account Request' && OnboardingForm.Status__c != 'Complete'){
                    if(formLineItemObject[i].formLineItem.Question_Text__c == 'Additional Account Type' && (formLineItemObject[i].formLineItem.Response__c == 'Closed Door' || formLineItemObject[i].formLineItem.Response__c == 'LTC (Long Term Care)')){
                        isAddAcc = true;
                    }
                    if(formLineItemObject[i].formLineItem.Question_Text__c == 'Delivery hours'){
                        if(isAddAcc == true){
                            formLineItemObject[i].formLineItem.Show_on_Screen__c = true;
                            formLineItemObject[i].formLineItem.IsRequired__c = true;
                        }else if (isAddAcc == false){
                            formLineItemObject[i].formLineItem.Show_on_Screen__c = false;
                            formLineItemObject[i].formLineItem.IsRequired__c = false;
                        }
                    }
                }  
                if(OnboardingForm.Name == 'New Account Merchandising Request' && formLineItemObject[i].formLineItem.Question_Text__c == 'Do you need merchandising services or labeling for your store?'
                   && formLineItemObject[i].formLineItem.Display_Page_Number__c == currentPage){
                    if(formLineItemObject[i].formLineItem.Response__c == 'I\'m an existing store and I need labeling.'){
                        formLineItemObject[i+5].formLineItem.Show_on_Screen__c = false;
                        formLineItemObject[i+5].formLineItem.IsRequired__c = false;
                        formLineItemSectionWise.push(formLineItemObject[i+5].formLineItem);
                    }else if(formLineItemObject[i].formLineItem.Response__c == 'I\'m a new store and need the Start-Up Service.'){
                        formLineItemObject[i+5].formLineItem.Show_on_Screen__c = true;
                        formLineItemObject[i+5].formLineItem.IsRequired__c = true;
                        formLineItemSectionWise.push(formLineItemObject[i+5].formLineItem);
                    }
                }
                if(formLineItemObject[i].formLineItem.Display_Page_Number__c == currentPage){
                    if(typeof(formLineItemObject[i].MultiSelectResponse) === 'object' && formLineItemObject[i].MultiSelectResponse != null && formLineItemObject[i].formLineItem.Response_Type__c == 'Multi-Select Picklist' && formLineItemObject[i].formLineItem.Show_on_Screen__c == true){
                        var resp = formLineItemObject[i].MultiSelectResponse.toString();
                        resp = resp.replace(/,/g, ';');//For ASD Conga form replaced all ',' with ';'
                        formLineItemObject[i].formLineItem.Response__c = resp;
                    }
                    if(formLineItemObject[i].formLineItem.Response_Type__c == 'Contact List' && formLineItemObject[i].formLineItem.Response__c != null 
                       && formLineItemObject[i].formLineItem.Show_on_Screen__c == true && formLineItemObject[i].formLineItem.IsRequired__c == true){
                        /* ---- This block of code is Used for CSP and not for Speciality, hence will need this.----
                        var additionalOwner1 = [];
                        if(OnboardingForm.Name == 'CSRA 590 Retail Pharmacy Questionnaire'){
                            if(formLineItemObject[i].formLineItem.Question_Text__c == 'Prescribing Practitioner 1'){
                                additionalOwnerLbl = 'Prescribing Practitioner';
                                additionalOwner1[0] = formLineItemObject[i].formLineItem.Response__c;
                                for(var j=i+1;j<formLineItemObject.length;j++){
                                    if(formLineItemObject[j].formLineItem.Question_Text__c == 'Prescribing Practitioner 2'){
                                        additionalOwner1[1] = formLineItemObject[j].formLineItem.Response__c;								
                                    }
                                    if(formLineItemObject[j].formLineItem.Question_Text__c == 'Prescribing Practitioner 3'){
                                        additionalOwner1[2] = formLineItemObject[j].formLineItem.Response__c;								
                                    }
                                    if(formLineItemObject[j].formLineItem.Question_Text__c == 'Prescribing Practitioner 4'){
                                        additionalOwner1[3] = formLineItemObject[j].formLineItem.Response__c;								
                                    }
                                    if(formLineItemObject[j].formLineItem.Question_Text__c == 'Prescribing Practitioner 5'){
                                        additionalOwner1[4] = formLineItemObject[j].formLineItem.Response__c; 
                                        break;
                                    }
                                }
                            }
                            for (var l = 0; l < additionalOwner1.length; l++) {
                                for (var k = 0; k < additionalOwner1.length; k++) {
                                    if((additionalOwner1[l] == additionalOwner1[k]) && (l != k)){
                                        var errMessage = additionalOwnerLbl + ' must be different.';
                                        var toastEvent = $A.get("e.force:showToast");
                                        toastEvent.setParams({
                                            title : 'Error',
                                            message: errMessage,
                                            type: 'error',
                                        });
                                        toastEvent.fire();
                                        return false;
                                    }
                                }
                            }
                        }*/
                        if(nextBtnLabel == 'Finish & Submit Form' && OnboardingForm.Name == 'AmerisourceBergen Credit Application'){
                            if(formLineItemObject[i].formLineItem.Question_Text__c == 'Authorized Agent/Officer Name'){
                                ownerId = formLineItemObject[i].formLineItem.Response__c;
                                for(var j=i+1;j<formLineItemObject.length;j++){
                                    if(formLineItemObject[j].formLineItem.Question_Text__c == 'Authorized Agent/Officer Name'){
                                        additionalOwner = formLineItemObject[j].formLineItem.Response__c;
                                        additionalOwnerLbl = 'Authorized Agent/Officer Name';
                                        break;
                                    }
                                }
                            }
                            if(formLineItemObject[i].formLineItem.Question_Text__c == 'Authorized Agent/Officer Name'&& ownerId == additionalOwner){
                                var errMessage = additionalOwnerLbl + ' must be different.';
                                var toastEvent = $A.get("e.force:showToast");
                                toastEvent.setParams({
                                    title : 'Error',
                                    message: errMessage,
                                    type: 'error',
                                });
                                toastEvent.fire();
                                return false;
                            }
                        }
                        if(OnboardingForm.Name == 'Payment Term and Method Agreement (up to $25k)' || OnboardingForm.Name == 'AmerisourceBergen Personal Guaranty'){
                            if(formLineItemObject[i].formLineItem.Question_Text__c == 'Owner\'s Name'){
                                ownerId = formLineItemObject[i].formLineItem.Response__c;
                                for(var j=i+1;j<formLineItemObject.length;j++){
                                    if(formLineItemObject[j].formLineItem.Question_Text__c == 'Additional Owner\'s Name (if applicable)'){
                                        additionalOwner = formLineItemObject[j].formLineItem.Response__c;
                                        additionalOwnerLbl = 'Owner and Additional Owner';
                                        break;
                                    }
                                }
                            }
                            if(formLineItemObject[i].formLineItem.Question_Text__c == 'Guarantor'){
                                ownerId = formLineItemObject[i].formLineItem.Response__c;
                                for(var j=i+1;j<formLineItemObject.length;j++){
                                    if(formLineItemObject[j].formLineItem.Question_Text__c == 'Additional Guarantor'){
                                        additionalOwner = formLineItemObject[j].formLineItem.Response__c;
                                        additionalOwnerLbl = 'Guarantor and Additional Guarantor';
                                        break;
                                    }
                                }
                            }
                            if((formLineItemObject[i].formLineItem.Question_Text__c == 'Guarantor' || formLineItemObject[i].formLineItem.Question_Text__c == 'Owner\'s Name') && ownerId == additionalOwner){
                                var errMessage = additionalOwnerLbl + ' must be different.';
                                var toastEvent = $A.get("e.force:showToast");
                                toastEvent.setParams({
                                    title : 'Error',
                                    message: errMessage,
                                    type: 'error',
                                });
                                toastEvent.fire();
                                return false;
                            }
                        }
                    }
                    if(formLineItemObject[i].formLineItem.Response_Type__c == 'Encrypted/ Masked'&& formLineItemObject[i].formLineItem.Response__c != null 
                       && formLineItemObject[i].formLineItem.Response__c != '' && formLineItemObject[i].formLineItem.Response__c != undefined
                       && formLineItemObject[i].formLineItem.Show_on_Screen__c == true && formLineItemObject[i].formLineItem.IsRequired__c == true){
                        var resp = formLineItemObject[i].formLineItem.Response__c;
                        if(isNaN(resp) && resp != '*********' && resp != '******************'){
                            var errMessage = 'Please enter valid '+formLineItemObject[i].formLineItem.Question_Text__c+'.';
                            var toastEvent = $A.get("e.force:showToast");
                            toastEvent.setParams({
                                title : 'Error',
                                message: errMessage,
                                type: 'error',
                            });
                            toastEvent.fire();
                            return false;
                        }
                        if(OnboardingForm.Name == 'AmerisourceBergen Credit Application' && formLineItemObject[i].formLineItem.Question_Text__c == 'Social Security Number'){
                            if(resp.length < 9){
                                var errMessage = 'Social Security Number must have 9 digits.';
                                var toastEvent = $A.get("e.force:showToast");
                                toastEvent.setParams({
                                    title : 'Error',
                                    message: errMessage,
                                    type: 'error',
                                });
                                toastEvent.fire();
                                return false;
                            }
                            if(resp != formLineItemObject[i+1].formLineItem.Response__c && 
                               formLineItemObject[i+1].formLineItem.Question_Text__c == 'Re-enter Social Security Number'){
                                var errMessage = 'The entered Social Security Number entered does not match.';
                                var toastEvent = $A.get("e.force:showToast");
                                toastEvent.setParams({
                                    title : 'Error',
                                    message: errMessage,
                                    type: 'error',
                                });
                                toastEvent.fire();
                                return false;
                            }
                        }
                        if(formLineItemObject[i].formLineItem.Response_Mapped_Field__c == 'Bank_Account__c'){
                            if(resp != formLineItemObject[i+1].formLineItem.Response__c && formLineItemObject[i+1].formLineItem.Question_Text__c == 'Re-enter bank account number'){
                                var errMessage = 'The entered Bank account number entered does not match.';
                                var toastEvent = $A.get("e.force:showToast");
                                toastEvent.setParams({
                                    title : 'Error',
                                    message: errMessage,
                                    type: 'error',
                                });
                                toastEvent.fire();
                                return false;
                            }
                        }
                    }
                    if(formLineItemObject[i].formLineItem.Response_Type__c == 'Text'&& formLineItemObject[i].formLineItem.Response__c != null 
                       && formLineItemObject[i].formLineItem.Show_on_Screen__c == true && formLineItemObject[i].formLineItem.IsRequired__c == true){
                        if((OnboardingForm.Name == 'CSRA 590 Practitioner Questionnaire' ||
                        	OnboardingForm.Name == 'CSRA 590 Distributor Questionnaire'  ||
                            OnboardingForm.Name == 'CSRA 590 Hospital Questionnaire'  ||
           					OnboardingForm.Name == 'CSRA 590 Retail Pharmacy Questionnaire')&&
                           formLineItemObject[i].formLineItem.Question_Text__c == 'Website'){
                            var resp = formLineItemObject[i].formLineItem.Response__c;
                            var pattern = new RegExp(/(https?:\/\/(?:www\.|(?!www))[a-zA-Z0-9][a-zA-Z0-9-]+[a-zA-Z0-9]\.[^\s]{2,}|www\.[a-zA-Z0-9][a-zA-Z0-9-]+[a-zA-Z0-9]\.[^\s]{2,}|https?:\/\/(?:www\.|(?!www))[a-zA-Z0-9]+\.[^\s]{2,}|www\.[a-zA-Z0-9]+\.[^\s]{2,})/gi);
                            if(pattern.test(resp) == false){
                                var errMessage = 'Please enter valid '+formLineItemObject[i].formLineItem.Question_Text__c+'.';
                                var toastEvent = $A.get("e.force:showToast");
                                toastEvent.setParams({
                                    title : 'Error',
                                    message: errMessage,
                                    type: 'error',
                                });
                                toastEvent.fire();
                                return false;
                            }                            
                        }
                        if(OnboardingForm.Name == 'AmerisourceBergen Credit Application' && formLineItemObject[i].formLineItem.Question_Text__c == 'Owner (s) since'){
                            var current_year=new Date().getFullYear();
                            var dateString =  formLineItemObject[i].formLineItem.Response__c;
                            var month = dateString.substring(0,2);
                            var year = dateString.substring(2,7);
                            if((month < 1) || (month >12)){
                                var errMessage = 'Please enter valid Month in MM format between 01 to 12';
                                var toastEvent = $A.get("e.force:showToast");
                                toastEvent.setParams({
                                    title : 'Error',
                                    message: errMessage,
                                    type: 'error',
                                });
                                toastEvent.fire();
                                return false;
                            }
                            else if((year < 1800) || (year > current_year)){
                                var errMessage = 'Please enter valid Year. It should be  >1800 and <= Current Year';
                                var toastEvent = $A.get("e.force:showToast");
                                toastEvent.setParams({
                                    title : 'Error',
                                    message: errMessage,
                                    type: 'error',
                                });
                                toastEvent.fire();
                                return false;
                            }
                        }
                    }
                    if(formLineItemObject[i].formLineItem.Response_Type__c == 'Email' && formLineItemObject[i].formLineItem.Show_on_Screen__c == true &&
                       formLineItemObject[i].formLineItem.IsRequired__c == true && formLineItemObject[i].formLineItem.Response__c != null){
                        var resp = formLineItemObject[i].formLineItem.Response__c;
                        var mailformat = /^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/;
						if(mailformat.test(resp) == false){
                            var errMessage = 'Please enter valid '+formLineItemObject[i].formLineItem.Question_Text__c+'.';
                            var toastEvent = $A.get("e.force:showToast");
                            toastEvent.setParams({
                                title : 'Error',
                                message: errMessage,
                                type: 'error',
                            });
                            toastEvent.fire();
                            return false;
                        }
                    }
                    if((formLineItemObject[i].formLineItem.Response_Type__c == 'Number') && formLineItemObject[i].formLineItem.Response__c != null
                       && formLineItemObject[i].formLineItem.Show_on_Screen__c == true ){
                        var resp = formLineItemObject[i].formLineItem.Response__c;
                        if(isNaN(resp)){
                            var errMessage = 'Please enter valid '+formLineItemObject[i].formLineItem.Question_Text__c+'.';
                            var toastEvent = $A.get("e.force:showToast");
                            toastEvent.setParams({
                                title : 'Error',
                                message: errMessage,
                                type: 'error',
                            });
                            toastEvent.fire();
                            return false;
                        }
                        if(OnboardingForm.Name == 'AmerisourceBergen Credit Application' && formLineItemObject[i].formLineItem.Question_Text__c == 'Year business started'){
                            var current_year = new Date().getFullYear();
                            if((formLineItemObject[i].formLineItem.Response__c < 1800) || (formLineItemObject[i].formLineItem.Response__c > current_year)){
                                var errMessage = 'Please enter valid '+formLineItemObject[i].formLineItem.Question_Text__c+'. It should be  >1800 and <= Current Year';
                                var toastEvent = $A.get("e.force:showToast");
                                toastEvent.setParams({
                                    title : 'Error',
                                    message: errMessage,
                                    type: 'error',
                                });
                                toastEvent.fire();
                                return false;
                            }
                        }
                    }
                    /*if(formLineItemObject[i].formLineItem.Response_Type__c == 'Phone' && 
                       formLineItemObject[i].formLineItem.Response__c != null && formLineItemObject[i].formLineItem.Response__c != '' &&
                       formLineItemObject[i].formLineItem.Show_on_Screen__c == true){
                        var resp = formLineItemObject[i].formLineItem.Response__c;
                        // Regex to check phone number with extention(optional) 555-555-5555 Ext:1234
                        var phoneNoExtRegex = /^[0-9]{3}-[0-9]{3}-[0-9]{4}$|^[0-9]{3}-[0-9]{3}-[0-9]{4}\sext\s[0-9]{4}$/; 
                        if(!phoneNoExtRegex.test(resp)){
                            var errMessage = 'Please enter valid '+formLineItemObject[i].formLineItem.Question_Text__c+'.';
                            var toastEvent = $A.get("e.force:showToast");
                            toastEvent.setParams({
                                title : 'Error',
                                message: errMessage,
                                type: 'error',
                            });
                            toastEvent.fire();
                            return false;
                        }
                    }*/
                    if((formLineItemObject[i].formLineItem.Response_Type__c == 'Single Checkbox' || formLineItemObject[i].formLineItem.Response_Type__c == 'Existing Account Address') && formLineItemObject[i].formLineItem.Show_on_Screen__c == true){
                        //var resp = formLineItemObject[i].formLineItem.Response__c.toString();
                        var resp = formLineItemObject[i].booleanResponse.toString();
                        //formLineItemObject[i].formLineItem.Response__c = resp;
                        if(resp == 'true'){
                            formLineItemObject[i].formLineItem.Response__c = 'true';
                        }else if(resp == 'false'){
                            formLineItemObject[i].formLineItem.Response__c = 'false';
                        }
                    }
                    if(formLineItemObject[i].formLineItem.Question_Text__c == 'Are there additional owners?' && formLineItemObject[i].formLineItem.Response__c == 'Yes' && OnboardingForm.Name == 'CSRA 590 Retail Pharmacy Questionnaire' && formLineItemObject[i].formLineItem.Show_on_Screen__c == true){
                        goToPreviousPage = true;
                    }
                    if(formLineItemObject[i].formLineItem.Response_Type__c == 'Percentage' && formLineItemObject[i].formLineItem.Response__c != null && formLineItemObject[i].formLineItem.Show_on_Screen__c == true){
                        if(Number(formLineItemObject[i].formLineItem.Response__c) > 100){
                            var toastEvent = $A.get("e.force:showToast");
                            toastEvent.setParams({
                                title : 'Error',
                                message: 'Percentage should not be greater than 100%',
                                type: 'error',
                            });
                            toastEvent.fire();
                            return false;
                        }
                        if(formLineItemObject[i].formLineItem.HasDependent__c == true){
                            totalPercent = totalPercent + Number(formLineItemObject[i].formLineItem.Response__c);                            
                            if(formLineItemObject[i+1].formLineItem.Response_Type__c != 'Percentage' && formLineItemObject[i+1].formLineItem.Is_Summary__c == true){
                                if(totalPercent != 100){
                                    var toastEvent = $A.get("e.force:showToast");
                                    toastEvent.setParams({
                                        title : 'Error',
                                        message: 'Total selection(s) should add up to 100%',
                                        type: 'error',
                                    });
                                    toastEvent.fire();
                                    return false;
                                } else{
                                    totalPercent = 0;
                                }
                            }
                        }                          
                    }
                    if(formLineItemObject[i].formLineItem.IsRequired__c == true && formLineItemObject[i].formLineItem.Show_on_Screen__c == true && (formLineItemObject[i].formLineItem.Response__c == null || formLineItemObject[i].formLineItem.Response__c == '') && formLineItemObject[i].disabled != true){
                        var toastEvent = $A.get("e.force:showToast");
                        toastEvent.setParams({
                            title : 'Error',
                            message: 'Please fill all the required fields on the page.',
                            type: 'error',
                        });
                        toastEvent.fire();
                        return false;
                    }else if(formLineItemObject[i].formLineItem.IsRequired__c == true && formLineItemObject[i].formLineItem.Show_on_Screen__c == true 
                             && formLineItemObject[i].disabled != true && formLineItemObject[i].formLineItem.Response_Type__c == 'Single Checkbox' 
                             && formLineItemObject[i].formLineItem.Response__c == 'false'){
                        var toastEvent = $A.get("e.force:showToast");
                        toastEvent.setParams({
                            title : 'Error',
                            message: 'Please fill all the required fields on the page.',
                            type: 'error',
                        });
                        toastEvent.fire();
                        return false;
                    }else{
                        //cmp.set("v.backButtonLabel", 'Back');
                    }
                    formLineItemSectionWise.push(formLineItemObject[i].formLineItem); 
                }
            }
            
            if(OnboardingForm.Name == 'CSRA 590 Retail Pharmacy Questionnaire' && currentPage == 8){
                var calulatedPercent;
                calulatedPercent = 0;
                for(var i=0; i<formLineItemObject.length; i++){
                    if(formLineItemObject[i].formLineItem.Display_Page_Number__c == currentPage){
                        if(formLineItemObject[i].formLineItem.Response_Type__c == 'Percentage' && formLineItemObject[i].formLineItem.Response__c != null 
                           && formLineItemObject[i].formLineItem.Show_on_Screen__c == true && formLineItemObject[i].formLineItem.HasDependent__c == true){  
                            calulatedPercent += Number(formLineItemObject[i].formLineItem.Response__c);
                        }
                    }
                } 
                if(calulatedPercent != 100){
                    var toastEvent = $A.get("e.force:showToast");
                    toastEvent.setParams({
                        title : 'Error',
                        message: 'Total selection(s) should add up to 100%',
                        type: 'error',
                    });
                    toastEvent.fire();
                    return false;
                }
            }
        }
        var updateLastVisitedPage;
        //if(currentPage+1 > pageSet.length){
        if(pgIndex+1 > pageSet.length){
            updateLastVisitedPage = 1
        }else{
            updateLastVisitedPage = pgIndex+1;
        }
        if(OnboardingForm.Name == 'New Account Information' && updateLastVisitedPage == 4){
            
            var sameAsList = [];
            var sameAsObj = {'Order':26,'DependentOrder':34};
            sameAsList.push(sameAsObj);
            sameAsObj = {'Order':27,'DependentOrder':35};
            sameAsList.push(sameAsObj);
            sameAsObj = {'Order':28,'DependentOrder':36};
            sameAsList.push(sameAsObj);
            sameAsObj = {'Order':29,'DependentOrder':37};
            sameAsList.push(sameAsObj);
            sameAsObj = {'Order':30,'DependentOrder':38};
            sameAsList.push(sameAsObj);
            sameAsObj = {'Order':31,'DependentOrder':39};
            sameAsList.push(sameAsObj);
            var isChanged = false;
            for(var k=0;k<sameAsList.length;k++){
                var question = sameAsList[k].Order;
                var dependent = sameAsList[k].DependentOrder;
                for(var i=20; i<formLineItemObject.length; i++){
                    if(isChanged == true){
                        break;
                    }
                    if(formLineItemObject[i].formLineItem.Order__c == question){
                        for(var j=i+1; j<formLineItemObject.length; j++){
                            if(formLineItemObject[j].formLineItem.Order__c == dependent){
                                if(formLineItemObject[i].formLineItem.Response__c != formLineItemObject[j].formLineItem.Response__c){
                                    isChanged = true;
                                    break;
                                }
                            }
                        }
                    }
                }
            }
            if(isChanged == true){
                for(var i=0;i<sameAsList.length;i++){
                    var dependent = sameAsList[i].DependentOrder;
                    for(var j=21; j<formLineItemObject.length; j++){
                        if(formLineItemObject[j].formLineItem.Order__c == 33.00){
                            formLineItemObject[j].formLineItem.Response__c = '';
                			formLineItemObject[j].MultiSelectResponse = [];
                        }
                        if(formLineItemObject[j].formLineItem.Order__c == dependent){
                            formLineItemObject[j].formLineItem.IsProtectedData__c = false;
                            formLineItemObject[j].disabled = false;
                            break;
                        }
                    }
                }
            }
        }
        if(nextBtnLabel == 'Finish & Submit Form' && OnboardingForm.Name == 'Required Uploads - Credit Application'){
            var errorText = '';
            for(var i=0; i<formLineItemObject.length; i++){
                if(formLineItemObject[i].formLineItem.IsRequired__c == true && (formLineItemObject[i].formLineItem.Response__c == null || formLineItemObject[i].formLineItem.Response__c == '')){
                    errorText = errorText + formLineItemObject[i].formLineItem.Display_Page_Number__c  + ', ';                
                }
            }
            if(errorText != ''){
                errorText = errorText.substring(0, errorText.length - 2);
                var pos = errorText.lastIndexOf(',');
                errorText = errorText.substring(0,pos) + ' and' + errorText.substring(pos+1)
                var toastEvent = $A.get("e.force:showToast");
                toastEvent.setParams({
                    title : 'Error',
                    message: 'You have not uploaded the required documents on Page ' + errorText,
                    type: 'error',
                });
                //toastEvent.fire();
                //return false;
            }
        }
        //This is to navigate to respective screens as per AC 4473
        var accountNumber;
        var validateAccountNumber;
        if(OnboardingForm.Name == 'Price Stickers Information'){
            if(currentPage == 1){
                if(formLineItemObject[2].formLineItem.Response__c == 'Default format option'){
                    cmp.set("v.pageNumber", 2);
                    cmp.set("v.backButtonLabel", 'Back');
                    updateLastVisitedPage = 2;
                } 
                if(formLineItemObject[2].formLineItem.Response__c == 'Custom format options'){
                    updateLastVisitedPage = 3;
                } 
                if(formLineItemObject[2].formLineItem.Response__c == 'Sticker option from an existing account'){
                    if(formLineItemObject[3].formLineItem.Response__c != null){
                        accountNumber = formLineItemObject[3].formLineItem.Response__c;
                        validateAccountNumber = true;
                        updateLastVisitedPage = 4;
                    }    
                }
            }else if(currentPage == 2){
                updateLastVisitedPage = 4;
            }
        }
        if(nextBtnLabel == 'Finish & Submit Form' && cmp.get("v.isModalOpen") == false){
            cmp.set("v.isModalOpen", true);
            return false;
        }else{
            var action = cmp.get('c.updateLineItem');
            action.setParams({
                "formLineItem" : formLineItemSectionWise,
                "NextButtonLabel" : nextBtnLabel,
                "OnbForm" : OnboardingForm,
                "PageNumber" : updateLastVisitedPage,
                "AccountNumber" : accountNumber,
                "valAccountNumber" : validateAccountNumber
            });
            action.setCallback(this, function(res){
                var state = res.getState(); // get the response state
                if(state == 'SUCCESS') {
                    if(res.getReturnValue() == false){
                        var toastEvent = $A.get("e.force:showToast");
                        toastEvent.setParams({
                            title : 'Error',
                            message: 'You must enter a valid account number to proceed with this option. If you need further assistance please contact your Onboarding Specialist',
                            type: 'error',
                        });
                        toastEvent.fire();
                        return false;
                    }
                    if(OnboardingForm.Name == 'Price Stickers Information' && formLineItemSectionWise[0].Display_Page_Number__c == 1 &&
                       formLineItemSectionWise[2].Response__c == 'Sticker option from an existing account'){
                        cmp.set("v.pageNumber", 4);
                        cmp.set("v.pgNumberIndex", 4);
                        cmp.set("v.nextButtonLabel", 'Finish & Submit Form');
                        cmp.set("v.backButtonLabel", 'Back');
                        return false;
                    }
                    if(OnboardingForm.Name == 'Price Stickers Information' && formLineItemSectionWise[0].Display_Page_Number__c == 1 &&
                       formLineItemSectionWise[2].Response__c == 'Custom format options'){
                        cmp.set("v.pageNumber", 3);
                        cmp.set("v.pgNumberIndex", 3);
                        cmp.set("v.nextButtonLabel", 'Next');
                        cmp.set("v.backButtonLabel", 'Back');
                        return false;
                    }
                    if(OnboardingForm.Name == 'Price Stickers Information' && 
                       formLineItemSectionWise[0].Display_Page_Number__c == 2){
                        cmp.set("v.pageNumber", 4);
                        cmp.set("v.pgNumberIndex", 4);
                        cmp.set("v.nextButtonLabel", 'Finish & Submit Form');
                        cmp.set("v.backButtonLabel", 'Back');
                        return false; 
                    }
                    if(nextBtnLabel == 'Finish & Submit Form'){
                        var successMessage = 'Records are saved successfully.'
                        helper.navigateToFormPage(cmp,OnboardingForm,successMessage);
                    }else{
                        if(goToPreviousPage == true){
                            var newSection = pageSet[a-1];
                            cmp.set("v.pgNumberIndex", pgIndex-1);//cmp.set("v.pgNumberIndex", 3);
                            cmp.set("v.pageNumber", newSection);
                        }else{
                            if(pageSet.length > a+1){
                                var newSection = pageSet[a+1];
                                cmp.set("v.pgNumberIndex", pgIndex+1);
                                cmp.set("v.pageNumber", newSection);
                                helper.getSummaryQuestion(cmp);
                            }
                        }
                        var onboardingLineItemId = '';
                        var newPgNumber = cmp.get("v.pageNumber");
                        for(var i=0; i<formLineItemObject.length; i++){
                            if(formLineItemObject[i].formLineItem.Display_Page_Number__c == newPgNumber){
                                if(formLineItemObject[i].formLineItem.Response_Type__c == 'Sharepoint File Upload' && onboardingLineItemId == ''){
                                    onboardingLineItemId = formLineItemObject[i].formLineItem.Id;
                                    break;
                                }
                            }
                        }
                        if(onboardingLineItemId != ''){
                            helper.fetchData(cmp, onboardingLineItemId);
                        }
                        if(a==pageSet.length-2){
                            cmp.set("v.nextButtonLabel", 'Finish & Submit Form');
                        }
                    }
                    cmp.set("v.backButtonLabel", 'Back');
                }
            });
            $A.enqueueAction(action);
            cmp.set("v.fileName",null);
        }
        window.scrollTo(0, 0);
    },
    handlePrevious : function(cmp,event,helper) {
        cmp.set("v.nextButtonLabel", 'Next');
        var bkLabel = cmp.get("v.backButtonLabel");
        if(bkLabel == 'Back to Forms'){
            var OnboardingForm = cmp.get("v.onboardingForm");
            var urlEvent = $A.get("e.force:navigateToURL");
            urlEvent.setParams({
                "url": "/form/"+OnboardingForm.Onboarding_Form_Group__c
            });
            urlEvent.fire();
        }
        //cmp.set("v.disableNext", false);
        var currentSection = cmp.get("v.sectionName");
        var currentPage = cmp.get("v.pageNumber");
        var pageSet = cmp.get("v.pageNumberSet");
        var formLineItemObject = cmp.get("v.formWrapperObject");
        var formLineItem = cmp.get("v.onboardingFormLineItems");
        var sectionSet = cmp.get("v.sectionNameSet");
        var a = pageSet.indexOf(currentPage);
        var pgIndex = cmp.get("v.pgNumberIndex");
        var pgIndexMap = cmp.get("v.pgNumberIndexMap");
        var form = cmp.get("v.onboardingForm");
        //var a = sectionSet.indexOf(currentSection);
        if(a-1>=0){
            var newSection = pageSet[a-1];
            cmp.set("v.pageNumber", newSection);
            cmp.set("v.pgNumberIndex", pgIndex-1);
            if(form.Name == 'New Account Merchandising Request'){
                //$A.get('e.force:refreshView').fire();
            }
            // This is to back navigate to respective screens as per AC
            if(form.Name == 'Price Stickers Information'){
                if(formLineItemObject[2].formLineItem.Response__c == 'Sticker option from an existing account' && currentPage==4){
                    cmp.set("v.pageNumber", 1);
                    cmp.set("v.pgNumberIndex", 1);
                    cmp.set("v.nextButtonLabel", 'Next');
                    cmp.set("v.backButtonLabel", 'Back to Forms');
                    return false;
                }else if(formLineItemObject[2].formLineItem.Response__c == 'Custom format options' && currentPage==3){
                    cmp.set("v.pageNumber", 1);
                    cmp.set("v.pgNumberIndex", 1);
                    cmp.set("v.nextButtonLabel", 'Next');  
                    cmp.set("v.backButtonLabel", 'Back to Forms');
                    return false; 
                }else if(formLineItemObject[2].formLineItem.Response__c == 'Default format option' && currentPage == 4){
                    cmp.set("v.pageNumber", 2);
                    cmp.set("v.pgNumberIndex", 2);
                    cmp.set("v.nextButtonLabel", 'Next');  
                    cmp.set("v.backButtonLabel", 'Back');
                    return false; 
                }
            }
            //cmp.set("v.sectionName", newSection);
        }
        if((a-1)==0){
            cmp.set("v.disablePrevious", false)
            cmp.set("v.backButtonLabel", 'Back to Forms');
        }
        var formLineItemObject = cmp.get("v.formWrapperObject");
        var onboardingLineItemId = '';
        var newPgNumber = cmp.get("v.pageNumber");
        for(var i=0; i<formLineItemObject.length; i++){
            if(formLineItemObject[i].formLineItem.Display_Page_Number__c == newPgNumber){
                if(formLineItemObject[i].formLineItem.Response_Type__c == 'Sharepoint File Upload' && onboardingLineItemId == ''){
                    onboardingLineItemId = formLineItemObject[i].formLineItem.Id;
                    break;
                }
            }
        }
        if(onboardingLineItemId != ''){
            helper.fetchData(cmp, onboardingLineItemId);
        }
        window.scrollTo(0, 0);
    },
    handleChange: function (cmp, event, helper) {
        // This will contain an array of the "value" attribute of the selected options
        var selectedOptionVal = event.getParam("value");
        var selectedOptionValue = event.getSource().get("v.name");
        //var form = cmp.get("v.onboardingForm");
        var formLineItemObject = cmp.get("v.formWrapperObject");
        var currentLineItemObj = formLineItemObject[selectedOptionValue];
        var form = cmp.get("v.onboardingForm");
        if(form.Name == 'CSRA 600 Retail Pharmacy Chain Questionnaire'){
			var questionText = event.getSource().get("v.label");
            if(questionText == 'Choose the selection that most closely describes your business.'){
                if(selectedOptionVal == 'Anticipated Go-Live Date (if applicable)'){
                formLineItemObject[selectedOptionValue+1].formLineItem.Show_on_Screen__c = true;
                    formLineItemObject[selectedOptionValue+1].formLineItem.IsRequired__c = true;
                }else{
                    formLineItemObject[selectedOptionValue+1].formLineItem.Show_on_Screen__c = false;
                    formLineItemObject[selectedOptionValue+1].formLineItem.IsRequired__c = false;
                }
            }            

        }        
        if(form.Name == 'AmerisourceBergen Personal Guaranty'){
            var questionText = event.getSource().get("v.label");
            if(questionText == 'Ownership type'){
                var indexOfAddtitinalOwner;
                var showOnScreen = false;
                if(selectedOptionVal == 'Partnership'){
                    showOnScreen = true;
                }
                for(var i=selectedOptionValue+1; i<formLineItemObject.length; i++){
                    if(formLineItemObject[i].formLineItem.Question_Text__c == 'Additional Guarantor'){
                        indexOfAddtitinalOwner = i;
                        break;
                    }
                }
                for(var i=indexOfAddtitinalOwner; i<formLineItemObject.length; i++){
                    formLineItemObject[i].formLineItem.Show_on_Screen__c = showOnScreen;
                }
                cmp.set("v.formWrapperObject",formLineItemObject);
            }
        }
        if(form.Name == 'PRxO® Generics Solution Agreement'){
            if(selectedOptionVal == 'No'){
                cmp.set("v.nextButtonLabel", 'Finish & Submit Form');
            }else {
                cmp.set("v.nextButtonLabel", 'Next');
            }
        }
        if(form.Name == 'New Account Merchandising Request'){
            if(currentLineItemObj.formLineItem.Question_Text__c == 'Do you need merchandising services or labeling for your store?'){
                if(selectedOptionVal == 'I don\'t require merchandising services or labeling.'){
                    cmp.set("v.nextButtonLabel", 'Finish & Submit Form');
                }else{
                    cmp.set("v.nextButtonLabel", 'Next');
                }
            }
            if(currentLineItemObj.formLineItem.Question_Text__c == 'I\'m an existing store and I need labeling.' && form.Status__c != 'Complete'){
                formLineItemObject[5].formLineItem.Show_on_Screen__c = false;
                cmp.set("v.formWrapperObject",formLineItemObject);                        
            }else{
                formLineItemObject[5].formLineItem.Show_on_Screen__c = true;
                cmp.set("v.formWrapperObject",formLineItemObject);   
            }
        }
        if(form.Name == 'Retail Price Request'){
            if(selectedOptionVal == 'I do not require retail pricing support from AmerisourceBergen.'||selectedOptionVal == 'Acquisition Cost'||selectedOptionVal == 'Wholesale Cost'){
                cmp.set("v.nextButtonLabel", 'Finish & Submit Form');
            }else{
                cmp.set("v.nextButtonLabel", 'Next');
            }
        }
        
        if(form.Name == 'New Account Information' && form.Status__c != 'Complete'){
            if(currentLineItemObj.formLineItem.Question_Text__c == 'Is your business going through a change of ownership?'){
                if(selectedOptionVal == 'Yes'){
                    formLineItemObject[selectedOptionValue+1].formLineItem.IsRequired__c = true;
                    formLineItemObject[selectedOptionValue+1].formLineItem.Show_on_Screen__c = true;
                }else{
                    formLineItemObject[selectedOptionValue+1].formLineItem.IsRequired__c = false;
                    formLineItemObject[selectedOptionValue+1].formLineItem.Show_on_Screen__c = false;
                }
            }
           /* if(currentLineItemObj.formLineItem.Question_Text__c == 'Have you been in business for more than 12 months?'){
                if(selectedOptionVal == 'Yes'){
                    formLineItemObject[selectedOptionValue+2].formLineItem.IsRequired__c = true;
                    formLineItemObject[selectedOptionValue+2].formLineItem.Show_on_Screen__c = true;
                    formLineItemObject[selectedOptionValue+1].formLineItem.IsRequired__c = false;
                    formLineItemObject[selectedOptionValue+1].formLineItem.Show_on_Screen__c = false;
                }else if(selectedOptionVal == 'No'){
                    formLineItemObject[selectedOptionValue+2].formLineItem.IsRequired__c = false;
                    formLineItemObject[selectedOptionValue+2].formLineItem.Show_on_Screen__c = false;
                    formLineItemObject[selectedOptionValue+2].formLineItem.Response__c = null;
                    formLineItemObject[selectedOptionValue+3].formLineItem.IsRequired__c = false;
                    formLineItemObject[selectedOptionValue+3].formLineItem.Show_on_Screen__c = false;
                    formLineItemObject[selectedOptionValue+1].formLineItem.IsRequired__c = true;
                    formLineItemObject[selectedOptionValue+1].formLineItem.Show_on_Screen__c = true;
                }
            }
            if(currentLineItemObj.formLineItem.Question_Text__c == 'If Yes, has your business changed PSAO recently?'){
                if(selectedOptionVal == 'Yes'){
                    formLineItemObject[selectedOptionValue+1].formLineItem.IsRequired__c = true;
                    formLineItemObject[selectedOptionValue+1].formLineItem.Show_on_Screen__c = true;
                }else{
                    formLineItemObject[selectedOptionValue+1].formLineItem.IsRequired__c = false;
                    formLineItemObject[selectedOptionValue+1].formLineItem.Show_on_Screen__c = false;
                }
            }*/
            if(currentLineItemObj.formLineItem.Question_Text__c == 'Will you be ordering controlled substances through AmerisourceBergen?'){
                if(selectedOptionVal == 'No'){
                    formLineItemObject[selectedOptionValue+1].formLineItem.IsRequired__c = true;
                    formLineItemObject[selectedOptionValue+1].formLineItem.Show_on_Screen__c = true;
                }else{
                    formLineItemObject[selectedOptionValue+1].formLineItem.IsRequired__c = false;
                    formLineItemObject[selectedOptionValue+1].formLineItem.Show_on_Screen__c = false;
                }
            }
            if(currentLineItemObj.formLineItem.Question_Text__c == 'Would you like to receive your DSCSA regulatory data (Transaction Information, Transaction History, & Transaction Statement) via a DSCSA compliant ASN?'){
                if(selectedOptionVal == 'Yes'){
                    formLineItemObject[selectedOptionValue+1].formLineItem.IsRequired__c = true;
                    formLineItemObject[selectedOptionValue+1].formLineItem.Show_on_Screen__c = true;
                    formLineItemObject[selectedOptionValue+2].formLineItem.Show_on_Screen__c = true;
                    formLineItemObject[selectedOptionValue+3].formLineItem.Show_on_Screen__c = true;
                }else{
                    formLineItemObject[selectedOptionValue+1].formLineItem.IsRequired__c = false;
                    formLineItemObject[selectedOptionValue+1].formLineItem.Show_on_Screen__c = false;
                    formLineItemObject[selectedOptionValue+2].formLineItem.Show_on_Screen__c = false;
                    formLineItemObject[selectedOptionValue+3].formLineItem.Show_on_Screen__c = false;
                }
            }
            
        }
        if(form.Name == 'Price Stickers Information'){
            if(selectedOptionValue == 2){
                if(selectedOptionVal == 'Sticker option from an existing account'){
                    formLineItemObject[selectedOptionValue+1].formLineItem.IsRequired__c = true;
                    formLineItemObject[selectedOptionValue+1].formLineItem.Show_on_Screen__c = true;
                }else{
                    formLineItemObject[selectedOptionValue+1].formLineItem.IsRequired__c = false;
                    formLineItemObject[selectedOptionValue+1].formLineItem.Show_on_Screen__c = false;
                }
            }
        }
        if(form.Name == 'Request Extended Dating for Opening Order' && form.Status__c != 'Complete'){
            if(selectedOptionVal == 'Other - please specify - may require additional approvals'){
                formLineItemObject[selectedOptionValue+1].disabled = false;
                formLineItemObject[selectedOptionValue+1].formLineItem.IsProtectedData__c = false;
                formLineItemObject[selectedOptionValue+1].formLineItem.Show_on_Screen__c = true;
                formLineItemObject[selectedOptionValue+1].formLineItem.IsRequired__c = true;
            }else{
                formLineItemObject[selectedOptionValue+1].formLineItem.Show_on_Screen__c = false;
                formLineItemObject[selectedOptionValue+1].formLineItem.IsRequired__c = false;
            }
        }
        if((form.Name == 'Payment Term and Method Agreement (above $25k)' || form.Name == 'Payment Term and Method Agreement (up to $25k)') && form.Status__c != 'Complete'){
            if(currentLineItemObj.formLineItem.Question_Text__c == 'What payment increment would you prefer?'){
                if(selectedOptionVal == 'Other'){
                    formLineItemObject[selectedOptionValue+1].formLineItem.Show_on_Screen__c = true;
                    formLineItemObject[selectedOptionValue+1].formLineItem.IsRequired__c = true;
                }else{
                    formLineItemObject[selectedOptionValue+1].formLineItem.Show_on_Screen__c = false;
                    formLineItemObject[selectedOptionValue+1].formLineItem.IsRequired__c = false;
                }
            }
        }
        if(form.Name == 'AmerisourceBergen Credit Application' && form.Status__c != 'Complete'){
            if(currentLineItemObj.formLineItem.Question_Text__c == 'Will you have another party (example: a parent company, subsidiary, or management company of Applicant) place orders or coordinate payment to AmerisouceBergen on behalf of Applicant?'){
                if(selectedOptionVal == 'Yes'){
                    formLineItemObject[selectedOptionValue+1].formLineItem.Show_on_Screen__c = true;
                    formLineItemObject[selectedOptionValue+1].formLineItem.IsRequired__c = true;
                }else{
                    formLineItemObject[selectedOptionValue+1].formLineItem.Show_on_Screen__c = false;
                    formLineItemObject[selectedOptionValue+1].formLineItem.IsRequired__c = false;
                }
            }            
        }
        if(form.Name == 'Health System Credit Application' && form.Status__c != 'Complete'){
            if(currentLineItemObj.formLineItem.Question_Text__c == 'Will you have another party (example: a parent company, subsidiary, or management company of Applicant) place orders or coordinate payment to AmerisourceBergen on behalf of Applicant?'){
            	if(selectedOptionVal == 'Yes'){
                    formLineItemObject[selectedOptionValue+1].formLineItem.Show_on_Screen__c = true;
                    formLineItemObject[selectedOptionValue+1].formLineItem.IsRequired__c = true;
                }else{
                    formLineItemObject[selectedOptionValue+1].formLineItem.Show_on_Screen__c = false;
                    formLineItemObject[selectedOptionValue+1].formLineItem.IsRequired__c = false;
                }	   
            }
        }
        cmp.set("v.formWrapperObject",formLineItemObject);  
        if(form.Name == 'Additional Account Request' && form.Status__c != 'Complete'){
            helper.handleDependencyForAdditionalAccountRequest(cmp,formLineItemObject,form,selectedOptionValue,selectedOptionVal,currentLineItemObj);
            cmp.set("v.formWrapperObject",formLineItemObject); 
        }
        if(form.Name == 'CSRA 590 Retail Pharmacy Questionnaire' && form.Status__c != 'Complete'){
            helper.CSRA590RetailDependency(cmp,formLineItemObject,form,selectedOptionValue,selectedOptionVal,currentLineItemObj);
            cmp.set("v.formWrapperObject",formLineItemObject); 
        }
        if(form.Name == 'CSRA 590 Practitioner Questionnaire' && form.Status__c != 'Complete'){
            helper.CSRA590PractitionerDependency(cmp,formLineItemObject,form,selectedOptionValue,selectedOptionVal,currentLineItemObj);
            cmp.set("v.formWrapperObject",formLineItemObject);
        }
        if(form.Name == 'CSRA 590 Distributor Questionnaire' && form.Status__c != 'Complete'){
            helper.CSRA590DistributorDependency(cmp,formLineItemObject,form,selectedOptionValue,selectedOptionVal,currentLineItemObj);
            cmp.set("v.formWrapperObject",formLineItemObject); 
        }
        if(form.Name == 'CSRA 590 Hospital Questionnaire' && form.Status__c != 'Complete'){
            helper.CSRA590HospitalDependency(cmp,formLineItemObject,form,selectedOptionValue,selectedOptionVal,currentLineItemObj);
            cmp.set("v.formWrapperObject",formLineItemObject); 
        }
        if(form.Name == 'CSRA 600 Corporate Retail Pharmacy Chain Questionnaire' && form.Status__c != 'Complete'){
            helper.CSRA600RetailDependency(cmp,formLineItemObject,form,selectedOptionValue,selectedOptionVal,currentLineItemObj);
            cmp.set("v.formWrapperObject",formLineItemObject); 
        }
 		if(form.Name == 'Corporate Questionnaire' && form.Status__c != 'Complete'){
            helper.newPortfolioDependency(cmp, formLineItemObject, form, selectedOptionValue, selectedOptionVal, currentLineItemObj);
            cmp.set("v.formWrapperObject",formLineItemObject);
        }     
        if(form.Name == 'Health System Location Onboarding Form' && form.Status__c != 'Complete'){
            helper.hsLocationOnbDependency(cmp, formLineItemObject, form, selectedOptionValue, selectedOptionVal, currentLineItemObj);
            cmp.set("v.formWrapperObject",formLineItemObject); 
        }
        if(currentLineItemObj.formLineItem.HasDependent__c == true){
            var action = cmp.get('c.getDependentPicklistMetadata');
            action.setParams({
                "FormName" : form.Name,
                "ContQuestionText" : currentLineItemObj.formLineItem.Question_Text__c,
                "ContFieldValue" : currentLineItemObj.formLineItem.Response__c,
            });
            action.setCallback(this, function(res){
                var state = res.getState(); // get the response state
                if(state == 'SUCCESS') {
                    var responseValue = res.getReturnValue();
                    if(responseValue != null){
                        var dependentPicklistValues = responseValue.Dependent_Picklist_Value__c;
                        if(form.Name == 'New Account Information' && currentLineItemObj.formLineItem.Response__c == responseValue.Controlling_Picklist_Value__c && form.Status__c != 'Complete'){
                            formLineItemObject[selectedOptionValue+1].PicklistOption = dependentPicklistValues;
                            cmp.set("v.formWrapperObject",formLineItemObject);
                        }
                        if(form.Name == 'Retail Price Request'){
                            var displayOrder = responseValue.Dependent_Question_Text__c.split(",");
                            var i;
                            for(i = 0; i<formLineItemObject.length; i++){
                                var order = formLineItemObject[i].formLineItem.Order__c.toString();
                                var j;
                                for(j=0; j<displayOrder.length; j++){
                                    if(order == displayOrder[j] && responseValue.Dependent_Picklist_Value__c == 'show'){
                                        if(order != '45' && formLineItemObject[i].formLineItem.Response_Type__c != 'Informational Text'){
                                            formLineItemObject[i].formLineItem.IsRequired__c = true;
                                        }
                                        formLineItemObject[i].formLineItem.Show_on_Screen__c = true;
                                    }else if(order == displayOrder[j] && responseValue.Dependent_Picklist_Value__c == 'hide'){
                                        formLineItemObject[i].formLineItem.Response__c = '';
                                        formLineItemObject[i].formLineItem.IsRequired__c = false;
                                        formLineItemObject[i].formLineItem.Show_on_Screen__c = false;
                                        formLineItemObject[i].MultiSelectResponse = [];
                                        if(order == '18'){
                                            formLineItemObject[i].formLineItem.Response__c = null;
                                        }
                                    }
                                }
                            }
                            cmp.set("v.formWrapperObject",formLineItemObject);
                        }
                        //Just calling metadata, might require afterwords hence not deleting.
                        if(form.Name == 'CSRA 590 Practitioner Questionnaire'){
                            for(i = 0; i<formLineItemObject.length; i++){
                                if(responseValue.Dependent_Picklist_Value__c == 'hide'){
                                    if(formLineItemObject[i].formLineItem.Order__c == responseValue.Dependent_Display_Order__c || formLineItemObject[i].formLineItem.Order__c == responseValue.Controlling_Display_Order__c){
                                        formLineItemObject[i].disabled = true;
                                        formLineItemObject[i].formLineItem.IsRequired__c = false;
                                        formLineItemObject[i].formLineItem.Show_on_Screen__c = false;
                                        formLineItemObject[i].formLineItem.Response__c = '';
                                    }
                                }else{
                                    if(formLineItemObject[i].formLineItem.Order__c == responseValue.Dependent_Display_Order__c){
                                        formLineItemObject[i].disabled = false;
                                        formLineItemObject[i].formLineItem.IsRequired__c = true;
                                        formLineItemObject[i].formLineItem.Show_on_Screen__c = true;
                                    }
                                    if(formLineItemObject[i].formLineItem.Order__c == responseValue.Controlling_Display_Order__c){
                                        formLineItemObject[i].disabled = true;
                                        formLineItemObject[i].formLineItem.IsRequired__c = false;
                                        formLineItemObject[i].formLineItem.Show_on_Screen__c = false;
                                        formLineItemObject[i].formLineItem.Response__c = '';
                                    }
                                }
                            }
                            cmp.set("v.formWrapperObject",formLineItemObject);
                        }
                    }
                }
            });
            $A.enqueueAction(action);
        }
    },
    checkAndFetchDependency: function(cmp,event){
        var selectedOptionValue = event.getSource().get("v.name");
        //var selectedOptionVal = event.getParam("value");
        var selectedOptionVal = event.getSource().get("v.value");
        var form = cmp.get("v.onboardingForm");
        var formLineItemObject = cmp.get("v.formWrapperObject");
        var currentLineItemObj = formLineItemObject[selectedOptionValue];
        var preResponseValue = cmp.get("v.preSelectValue");
        var curPageNumber = cmp.get("v.pageNumber");
        var totalCSRAPercent = cmp.get("v.totalPercent");        
        var count = 0;       
        if(form.Name == 'Health System Location Onboarding Form' && form.Status__c != 'Complete'){
            if(currentLineItemObj.formLineItem.Question_Text__c == 'What is your \'Business Activity\' classification on your DEA License?'){
                if(selectedOptionVal == 'Other'){
                    formLineItemObject[selectedOptionValue+1].formLineItem.Show_on_Screen__c = true;
                    formLineItemObject[selectedOptionValue+1].formLineItem.IsRequired__c = true;
                }else{
                    formLineItemObject[selectedOptionValue+1].formLineItem.Show_on_Screen__c = false;
                    formLineItemObject[selectedOptionValue+1].formLineItem.IsRequired__c = false;
                }
            }else if(currentLineItemObj.formLineItem.Question_Text__c == 'How many email contact would you like to use for ASD order confirmations?'){
                var res = currentLineItemObj.formLineItem.Response__c;
                var i;
                for(i = 1; i<=res; i++){
                    formLineItemObject[selectedOptionValue+i].formLineItem.Show_on_Screen__c = true;
                }
                for(i = 5; i > res ;i--){
                    formLineItemObject[selectedOptionValue+i].formLineItem.Show_on_Screen__c = false;
                }
            }else if(currentLineItemObj.formLineItem.Question_Text__c == 'Select number of Delivery Points'){
                var res = currentLineItemObj.formLineItem.Response__c;
                var i;
                for(i = 1; i<=res; i++){
                    formLineItemObject[selectedOptionValue+i].formLineItem.Show_on_Screen__c = true;
                }
                for(i = 3; i > res ;i--){
                    formLineItemObject[selectedOptionValue+i].formLineItem.Show_on_Screen__c = false;
                }
            }
            cmp.set("v.formWrapperObject",formLineItemObject);
        }
        if(form.Name == 'Additional Account Request' && form.Status__c != 'Complete'){            
            if(currentLineItemObj.formLineItem.Question_Text__c == 'Reason for Additional account'){
                if(currentLineItemObj.formLineItem.Response__c == 'Other'){
                    formLineItemObject[selectedOptionValue+1].formLineItem.Show_on_Screen__c = true;
                    formLineItemObject[selectedOptionValue+1].formLineItem.IsRequired__c = true;
                }else{
                    formLineItemObject[selectedOptionValue+1].formLineItem.Show_on_Screen__c = false;
                    formLineItemObject[selectedOptionValue+1].formLineItem.IsRequired__c = false;
                }
            }
            if(currentLineItemObj.formLineItem.Question_Text__c == 'Additional Account Type'){
                if(currentLineItemObj.formLineItem.Response__c == 'Other'){
                    formLineItemObject[selectedOptionValue+1].formLineItem.Show_on_Screen__c = true;
                    formLineItemObject[selectedOptionValue+1].formLineItem.IsRequired__c = true;
                }else{
                    formLineItemObject[selectedOptionValue+1].formLineItem.Show_on_Screen__c = false;
                    formLineItemObject[selectedOptionValue+1].formLineItem.IsRequired__c = false;
                }
            }
            cmp.set("v.formWrapperObject",formLineItemObject);
        }        
        if(form.Name == 'CSRA 590 Retail Pharmacy Questionnaire' && form.Status__c != 'Complete'){
            totalCSRAPercent = 0;
            for(var i=0; i<formLineItemObject.length; i++){
                if(formLineItemObject[i].formLineItem.Response_Type__c == 'Percentage' && formLineItemObject[i].formLineItem.Response__c != null && 
                   formLineItemObject[i].formLineItem.Display_Page_Number__c == curPageNumber && formLineItemObject[i].formLineItem.Show_on_Screen__c == true){  
                    if(formLineItemObject[i].formLineItem.HasDependent__c == true){
                        totalCSRAPercent += Number(formLineItemObject[i].formLineItem.Response__c);
                        count++;
                    }
                }
            }
            cmp.set("v.totalPercent", totalCSRAPercent);
        }
        if(form.Name == 'CSRA 590 Retail Pharmacy Questionnaire' && form.Status__c != 'Complete'){        
            if(currentLineItemObj.formLineItem.Question_Text__c == 'Select the number of owners'){
                var response = currentLineItemObj.formLineItem.Response__c;
                if(preResponseValue == 0){
                    preResponseValue = count;
                }
                if((preResponseValue !=null && preResponseValue !="" && response > preResponseValue) && totalCSRAPercent >= 100){
                    var toastEvent = $A.get("e.force:showToast");
                    toastEvent.setParams({
                        title : 'Error',
                        message: 'In order to add an additional owner, the Percent of Ownership for other owners must be less than 100%.',
                        type: 'error',
                    });
                    toastEvent.fire();
                    if(preResponseValue == 0){
                        preResponseValue = count;
                    }
                    currentLineItemObj.formLineItem.Response__c = preResponseValue;
                    cmp.set("v.preSelectValue", currentLineItemObj.formLineItem.Response__c);
                    cmp.set("v.formWrapperObject",formLineItemObject);
                    return false;                    
                }                
                cmp.set("v.preSelectValue", currentLineItemObj.formLineItem.Response__c);
                var res = currentLineItemObj.formLineItem.Response__c;
                var i;
                var count = 0;
                for(i = 1; i<=res;i++){
                    formLineItemObject[selectedOptionValue+i+count].formLineItem.Show_on_Screen__c = true;
                    formLineItemObject[selectedOptionValue+i+count++].formLineItem.IsRequired__c = true;
                    formLineItemObject[selectedOptionValue+i+count].formLineItem.Show_on_Screen__c = true;
                    formLineItemObject[selectedOptionValue+i+count++].formLineItem.IsRequired__c = true;
                    formLineItemObject[selectedOptionValue+i+count++].formLineItem.Show_on_Screen__c = true;
                    formLineItemObject[selectedOptionValue+i+count++].formLineItem.Show_on_Screen__c = true;
                    formLineItemObject[selectedOptionValue+i+count].formLineItem.Show_on_Screen__c = true;
                    formLineItemObject[selectedOptionValue+i+count].formLineItem.IsRequired__c = true;
                }
                res = parseInt(res)+1;
                for( i = res; i<=4 ; i++){
                    formLineItemObject[selectedOptionValue+i+count].formLineItem.Show_on_Screen__c = false;
                    formLineItemObject[selectedOptionValue+i+count].formLineItem.Response__c = '';
                    formLineItemObject[selectedOptionValue+i+count++].formLineItem.IsRequired__c = false;
                    formLineItemObject[selectedOptionValue+i+count].formLineItem.Show_on_Screen__c = false;
                    formLineItemObject[selectedOptionValue+i+count].formLineItem.Response__c = '';
                    formLineItemObject[selectedOptionValue+i+count++].formLineItem.IsRequired__c = false;
                    formLineItemObject[selectedOptionValue+i+count].formLineItem.Show_on_Screen__c = false;
                    formLineItemObject[selectedOptionValue+i+count].formLineItem.Response__c = '';
                    formLineItemObject[selectedOptionValue+i+count++].formLineItem.IsRequired__c = false;
                    formLineItemObject[selectedOptionValue+i+count].formLineItem.Show_on_Screen__c = false;
                    formLineItemObject[selectedOptionValue+i+count++].formLineItem.IsRequired__c = false;
                    formLineItemObject[selectedOptionValue+i+count].formLineItem.Show_on_Screen__c = false;
                    formLineItemObject[selectedOptionValue+i+count].formLineItem.Response__c = '';
                }                
            }
            cmp.set("v.formWrapperObject",formLineItemObject);
        }
        if(form.Name == 'CSRA 590 Practitioner Questionnaire' && form.Status__c != 'Complete'){   
            var selectedContactLicList = cmp.get("v.selectedContactList");
            if(currentLineItemObj.formLineItem.Question_Text__c == 'Licensed practitioner'){     
                var licLi = cmp.get("v.licenseList");
                if(selectedOptionVal == 'Yes'){
                    if(selectedContactLicList.length == 0 && selectedContactLicList.toString().search(formLineItemObject[selectedOptionValue+1].formLineItem.Mapped_Object_Controlling_Field_Value__c) == -1){                        
                        formLineItemObject[selectedOptionValue+1].formLineItem.IsRequired__c = true;
                        formLineItemObject[selectedOptionValue+1].formLineItem.Show_on_Screen__c = true;
                    }else{
                        formLineItemObject[selectedOptionValue+1].formLineItem.IsRequired__c = false;
                        formLineItemObject[selectedOptionValue+1].formLineItem.Show_on_Screen__c = false;
                    }
                }else{
                    formLineItemObject[selectedOptionValue+1].formLineItem.IsRequired__c = false;
                    formLineItemObject[selectedOptionValue+1].formLineItem.Show_on_Screen__c = false;
                }
                cmp.set("v.formWrapperObject",formLineItemObject);
            }            
            if(currentLineItemObj.formLineItem.Question_Text__c == 'Select number of owners'){
                var res = currentLineItemObj.formLineItem.Response__c;
                var i;
                var count = 0;
                var licList = cmp.get("v.licenseList");
                for(i = 1; i<=res; i++){
                    formLineItemObject[selectedOptionValue+i+count].formLineItem.Show_on_Screen__c = true;
                    formLineItemObject[selectedOptionValue+i+count++].formLineItem.IsRequired__c = true;
                    formLineItemObject[selectedOptionValue+i+count].formLineItem.Show_on_Screen__c = true;
                    formLineItemObject[selectedOptionValue+i+count++].formLineItem.IsRequired__c = true;
                    //license lineitem
                    if(licList.toString().search(formLineItemObject[selectedOptionValue+i+count].formLineItem.Mapped_Object_Controlling_Field_Value__c) == -1){
                        formLineItemObject[selectedOptionValue+i+count].formLineItem.Show_on_Screen__c = true;
                    	formLineItemObject[selectedOptionValue+i+count++].formLineItem.IsRequired__c = true;
                    }else{
                        count++;
                    }                    
                    formLineItemObject[selectedOptionValue+i+count].formLineItem.Show_on_Screen__c = true;
                    formLineItemObject[selectedOptionValue+i+count++].formLineItem.IsRequired__c = true; 
                    formLineItemObject[selectedOptionValue+i+count].formLineItem.Show_on_Screen__c = true;
                    formLineItemObject[selectedOptionValue+i+count++].formLineItem.IsRequired__c = true;
                    formLineItemObject[selectedOptionValue+i+count].formLineItem.Show_on_Screen__c = true;
                    formLineItemObject[selectedOptionValue+i+count++].formLineItem.IsRequired__c = true;
                    formLineItemObject[selectedOptionValue+i+count].formLineItem.Show_on_Screen__c = true;                
                }
                res = parseInt(res)+1;
                for( i = res; i<=10 ; i++){
                    formLineItemObject[selectedOptionValue+i+count].formLineItem.Show_on_Screen__c = false;
                    formLineItemObject[selectedOptionValue+i+count].formLineItem.Response__c = '';
                    formLineItemObject[selectedOptionValue+i+count++].formLineItem.IsRequired__c = false;
                    formLineItemObject[selectedOptionValue+i+count].formLineItem.Show_on_Screen__c = false;
                    formLineItemObject[selectedOptionValue+i+count].formLineItem.Response__c = '';
                    formLineItemObject[selectedOptionValue+i+count++].formLineItem.IsRequired__c = false;
                    formLineItemObject[selectedOptionValue+i+count].formLineItem.Show_on_Screen__c = false;
                    formLineItemObject[selectedOptionValue+i+count].formLineItem.Response__c = '';
                    formLineItemObject[selectedOptionValue+i+count++].formLineItem.IsRequired__c = false;
                    formLineItemObject[selectedOptionValue+i+count].formLineItem.Show_on_Screen__c = false;
                    formLineItemObject[selectedOptionValue+i+count].formLineItem.Response__c = '';
                    formLineItemObject[selectedOptionValue+i+count++].formLineItem.IsRequired__c = false;
                    formLineItemObject[selectedOptionValue+i+count].formLineItem.Show_on_Screen__c = false;
                    formLineItemObject[selectedOptionValue+i+count].formLineItem.Response__c = '';
                    formLineItemObject[selectedOptionValue+i+count++].formLineItem.IsRequired__c = false;
                    formLineItemObject[selectedOptionValue+i+count].formLineItem.Show_on_Screen__c = false;
                    formLineItemObject[selectedOptionValue+i+count].formLineItem.Response__c = '';
                    formLineItemObject[selectedOptionValue+i+count++].formLineItem.IsRequired__c = false;
                    formLineItemObject[selectedOptionValue+i+count].formLineItem.Show_on_Screen__c = false;
                }
                cmp.set("v.formWrapperObject",formLineItemObject);
            }
        }
        if(form.Name == 'AmerisourceBergen Credit Application' && form.Status__c != 'Complete'){
            if(currentLineItemObj.formLineItem.Question_Text__c == 'Select the number of person(s) owning 10% or more of the business.'){
                var res = currentLineItemObj.formLineItem.Response__c;
                var i;
                var count=1;
                var titlePresent = cmp.get("v.defaultContactTitle");
                for(i = 1; i<=res; i++){               
                    formLineItemObject[selectedOptionValue+i+count].formLineItem.Show_on_Screen__c = true;
                    formLineItemObject[selectedOptionValue+i+count++].formLineItem.IsRequired__c = true;
                    formLineItemObject[selectedOptionValue+i+count++].formLineItem.Show_on_Screen__c = true;
                    formLineItemObject[selectedOptionValue+i+count].formLineItem.Show_on_Screen__c = true;
                    formLineItemObject[selectedOptionValue+i+count++].formLineItem.IsRequired__c = true;
                    formLineItemObject[selectedOptionValue+i+count].formLineItem.Show_on_Screen__c = true;
                    formLineItemObject[selectedOptionValue+i+count++].formLineItem.IsRequired__c = true;
                    formLineItemObject[selectedOptionValue+i+count].formLineItem.Show_on_Screen__c = true;
                    formLineItemObject[selectedOptionValue+i+count++].formLineItem.IsRequired__c = true;
                    count++;
                    formLineItemObject[selectedOptionValue+i+count].formLineItem.Show_on_Screen__c = true;
                    formLineItemObject[selectedOptionValue+i+count++].formLineItem.IsRequired__c = true;
                    if(titlePresent == false){
                        formLineItemObject[selectedOptionValue+i+count].formLineItem.Show_on_Screen__c = true;
                    	formLineItemObject[selectedOptionValue+i+count++].formLineItem.IsRequired__c = true;
                    }else{
                        count++;
                    }
                    formLineItemObject[selectedOptionValue+i+count].formLineItem.Show_on_Screen__c = true;
                    formLineItemObject[selectedOptionValue+i+count++].formLineItem.IsRequired__c = true;
                    formLineItemObject[selectedOptionValue+i+count].formLineItem.Show_on_Screen__c = true;
                    formLineItemObject[selectedOptionValue+i+count++].formLineItem.IsRequired__c = true;
                    formLineItemObject[selectedOptionValue+i+count].formLineItem.Show_on_Screen__c = true;
                    formLineItemObject[selectedOptionValue+i+count++].formLineItem.IsRequired__c = true;
                    formLineItemObject[selectedOptionValue+i+count].formLineItem.Show_on_Screen__c = true;
                    formLineItemObject[selectedOptionValue+i+count++].formLineItem.IsRequired__c = true;
                    formLineItemObject[selectedOptionValue+i+count].formLineItem.Show_on_Screen__c = true;
                }
                //count = count + 1;
                res = parseInt(res)+1;
                for( i = res; i<=10 ; i++){                    
                    formLineItemObject[selectedOptionValue+i+count].formLineItem.Show_on_Screen__c = false;
                    formLineItemObject[selectedOptionValue+i+count++].formLineItem.IsRequired__c = false;
                    formLineItemObject[selectedOptionValue+i+count++].formLineItem.Show_on_Screen__c = false;
                    formLineItemObject[selectedOptionValue+i+count].formLineItem.Show_on_Screen__c = false;
                    formLineItemObject[selectedOptionValue+i+count++].formLineItem.IsRequired__c = false;
                    formLineItemObject[selectedOptionValue+i+count].formLineItem.Show_on_Screen__c = false;
                    formLineItemObject[selectedOptionValue+i+count++].formLineItem.IsRequired__c = false;
                    formLineItemObject[selectedOptionValue+i+count++].formLineItem.Show_on_Screen__c = false;
                    formLineItemObject[selectedOptionValue+i+count].formLineItem.Show_on_Screen__c = false;
                    formLineItemObject[selectedOptionValue+i+count++].formLineItem.IsRequired__c = false;
                    formLineItemObject[selectedOptionValue+i+count++].formLineItem.Show_on_Screen__c = false;
                    formLineItemObject[selectedOptionValue+i+count].formLineItem.Show_on_Screen__c = false;
                    formLineItemObject[selectedOptionValue+i+count++].formLineItem.IsRequired__c = false;
                    formLineItemObject[selectedOptionValue+i+count].formLineItem.Show_on_Screen__c = false;
                    formLineItemObject[selectedOptionValue+i+count++].formLineItem.IsRequired__c = false;
                    formLineItemObject[selectedOptionValue+i+count].formLineItem.Show_on_Screen__c = false;
                    formLineItemObject[selectedOptionValue+i+count++].formLineItem.IsRequired__c = false;
                    formLineItemObject[selectedOptionValue+i+count].formLineItem.Show_on_Screen__c = false;
                    formLineItemObject[selectedOptionValue+i+count++].formLineItem.IsRequired__c = false;
                    formLineItemObject[selectedOptionValue+i+count].formLineItem.Show_on_Screen__c = false;                    
                }                
            }
            if(currentLineItemObj.formLineItem.Question_Text__c == 'Registered Pharmacist'){
                if(selectedOptionVal == 'Yes'){
                    formLineItemObject[selectedOptionValue+1].formLineItem.Show_on_Screen__c = true;
                    formLineItemObject[selectedOptionValue+1].formLineItem.IsRequired__c = true;
                }else{
                    formLineItemObject[selectedOptionValue+1].formLineItem.Show_on_Screen__c = false;
                    formLineItemObject[selectedOptionValue+1].formLineItem.IsRequired__c = false;
                }
                
            }
            cmp.set("v.formWrapperObject",formLineItemObject);
        }
        if(currentLineItemObj.formLineItem.Question_Text__c == 'Select number of Secondary GPOs'){
            var res = currentLineItemObj.formLineItem.Response__c;
            var i;
            for(i = 1; i<=res; i++){
                formLineItemObject[selectedOptionValue+i].formLineItem.Show_on_Screen__c = true;
            }
            for(i = 10; i > res ;i--){
                formLineItemObject[selectedOptionValue+i].formLineItem.Show_on_Screen__c = false;
            }
            cmp.set("v.formWrapperObject",formLineItemObject);
        }
        if(currentLineItemObj.formLineItem.HasDependent__c == true){
            var action = cmp.get('c.getDependentPicklistMetadata');
            action.setParams({
                "FormName" : form.Name,
                "ContQuestionText" : currentLineItemObj.formLineItem.Question_Text__c,
                "ContFieldValue" : currentLineItemObj.formLineItem.Response__c,
            });
            action.setCallback(this, function(res){
                var state = res.getState(); // get the response state
                if(state == 'SUCCESS') {
                    var responseValue = res.getReturnValue();
                    if(form.Name == 'New Account Information'){
                        var dependentPicklistValues = responseValue.Dependent_Picklist_Value__c.split(',');
                        formLineItemObject[selectedOptionValue+1].PicklistOption = [];
                        for(var pValIndex= 0; pValIndex < dependentPicklistValues.length; pValIndex++){
                            formLineItemObject[selectedOptionValue+1].PicklistOption.push({
                                label: dependentPicklistValues[pValIndex],
                                value: dependentPicklistValues[pValIndex]
                            });
                        }
                    }
                    cmp.set("v.formWrapperObject",formLineItemObject);
                }
            });
            $A.enqueueAction(action);
        }
        
    },
    handleUploadFinished: function (cmp, event) {
        // This will contain the List of File uploaded data and status
        var selectedOptionValue = event.getSource().get("v.name");
        //var form = cmp.get("v.onboardingForm");
        var formLineItemObject = cmp.get("v.formWrapperObject");
        var currentLineItemObj = formLineItemObject[selectedOptionValue];
        var uploadedFiles = event.getParam("files");
        if(formLineItemObject[selectedOptionValue].FileNames != null && formLineItemObject[selectedOptionValue].FileNames != ''){
            Array.prototype.push.apply(formLineItemObject[selectedOptionValue].FileNames,uploadedFiles);
            formLineItemObject[selectedOptionValue].FileNames ;
        }else{
            formLineItemObject[selectedOptionValue].FileNames = uploadedFiles;
        }
        //cmp.set("v.fileName",uploadedFiles);
        var i=0;
        var fileNameString = '';
        for(i=0;i<uploadedFiles.length;i++){
            if(fileNameString != ''){
                fileNameString = fileNameString + ','+uploadedFiles[i].name+'-'+uploadedFiles[i].documentId;
            }else{
                fileNameString = uploadedFiles[i].name+'-'+uploadedFiles[i].documentId;
            }
        }
        if(formLineItemObject[selectedOptionValue].formLineItem.Response__c != null && formLineItemObject[selectedOptionValue].formLineItem.Response__c != ''){
            formLineItemObject[selectedOptionValue].formLineItem.Response__c = formLineItemObject[selectedOptionValue].formLineItem.Response__c + ',' + fileNameString;
        }else{
            formLineItemObject[selectedOptionValue].formLineItem.Response__c = fileNameString;
        }
        cmp.set("v.formWrapperObject",formLineItemObject);
    },
    
    handleDeletion:function(cmp, event){
        var b;
        var documentIdArray = [];
        var a = event.getSource().get("v.alternativeText");
        var idfile = cmp.find('fileUploadId');
        var indexNb = idfile.get('v.name');
        var indexnumber = cmp.find('fileUploadId').get('v.name');
        var formLineItemObject = cmp.get("v.formWrapperObject");
        var currentLineItemObj = formLineItemObject[indexnumber];
        var action = cmp.get("c.deleteAttachment");
        action.setParams({"attachId" : a});
        action.setCallback(this, function(response) {
            var state = response.getState();
            if (state === "SUCCESS"){
                var file = currentLineItemObj.FileNames;
                for(b=0; b<file.length; b++){
                    documentIdArray.push(file[b].documentId);
                }
                var c = documentIdArray.indexOf(a);
                file.splice(c,1);
                //cmp.set("v.fileName", file);
                var z=0;
                var fileNameString = '';
                for(z=0;z<file.length;z++){
                    if(fileNameString != ''){
                        fileNameString = fileNameString + ','+file[z].name+'-'+file[z].documentId;
                    }else{
                        fileNameString = file[z].name+'-'+file[z].documentId;
                    }
                }
                formLineItemObject[indexnumber].formLineItem.Response__c = fileNameString;
                cmp.set("v.formWrapperObject",formLineItemObject);
                var toastEvent = $A.get("e.force:showToast");
                toastEvent.setParams({
                    title : 'Success',
                    message: 'The attachment is deleted',
                    duration:' 5000',
                    key: 'info_alt',
                    type: 'success',
                    mode: 'dismissible'
                });
                toastEvent.fire();
            }
            else
            {
            }
        });
        $A.enqueueAction(action);    
    },
    handleBack : function (component, event, helper){
        var OnboardingForm = component.get("v.onboardingForm");
        var urlEvent = $A.get("e.force:navigateToURL");
        urlEvent.setParams({
            "url": "/form/"+OnboardingForm.Onboarding_Form_Group__c
        });
        urlEvent.fire();
       // $A.get('e.force:refreshView').fire();
    },
    onCheckGetSameAsValue: function (component, event, helper){
        var isChecked = event.getSource().get("v.value");
        var dependentQuestionindex = event.getSource().get("v.name");
        var formLineItems = component.get("v.formWrapperObject");
        var dependentQuestion = formLineItems[dependentQuestionindex].formLineItem.Question_Text__c;
        var formName = component.get("v.onboardingForm").Name;
        if(isChecked == true){
            var action = component.get("c.getSameAsValue");
            action.setParams({"formName" : formName,"dependentQuestion" : dependentQuestion});
            action.setCallback(this, function(response) {
                var state = response.getState();
                if (state === "SUCCESS"){
                    var responseValue = response.getReturnValue();
                    var i;
                    for(i=0;i<dependentQuestionindex;i++){
                        if(formLineItems[i].formLineItem.Question_Text__c == responseValue[0].controllingQuestion){
                            formLineItems[dependentQuestionindex].formLineItem.Response__c = formLineItems[i].formLineItem.Response__c;
                            formLineItems[dependentQuestionindex].formLineItem.Same_As_Value__c = true;
                            formLineItems[dependentQuestionindex].disabledDeliveryOption = true;
                        }
                    }
                    component.set("v.formWrapperObject", formLineItems);
                    formLineItems[dependentQuestionindex].disabledDeliveryOption = false;
                    component.set("v.formWrapperObject", formLineItems);
                }
                else{
                }
            });
            $A.enqueueAction(action);
        }else{
            formLineItems[dependentQuestionindex].formLineItem.Response__c = null;
            formLineItems[dependentQuestionindex].formLineItem.Same_As_Value__c = false;
            formLineItems[dependentQuestionindex].disabledDeliveryOption = true;
            component.set("v.formWrapperObject", formLineItems);
            formLineItems[dependentQuestionindex].disabledDeliveryOption = false;
            component.set("v.formWrapperObject", formLineItems);
        }
    },
    showSpinner: function (component, event, helper){
        component.set("v.showSpinner", true);
    },
    hideSpinner: function (component, event, helper){
        component.set("v.showSpinner", false);
    },
    handleSameAs : function (component, event, helper){
        var changeValue = event.getSource().get("v.value");
        var questionText = event.getSource().get("v.label");
        var dependentQuestionindex = event.getSource().get("v.name");
        var formName = component.get("v.onboardingForm").Name;
        var form = component.get("v.onboardingForm");
        var formLineItems = component.get("v.formWrapperObject");
        var currentLineItemObj = formLineItems[dependentQuestionindex];
        var objString = currentLineItemObj.MultiSelectResponse.toString();
        if(form.Name == 'CSRA 590 Hospital Questionnaire' || 
           form.Name == 'CSRA 590 Distributor Questionnaire' ||
           form.Name == 'CSRA 590 Retail Pharmacy Questionnaire'){
        	helper.CSRA590Dependencies(component,formLineItems,objString,dependentQuestionindex,changeValue,questionText,event);
            component.set("v.formWrapperObject",formLineItems);
        }
        if(form.Name == 'Pharmacy Data Service (PDS) Agreement - Contracted' && form.Status__c != 'Complete'){
            helper.PDSAgreementForm(component,formLineItems,form,dependentQuestionindex,changeValue,questionText,event);
            component.set("v.formWrapperObject",formLineItems);
        }
        if(form.Name == 'Pharmacy Data Service (PDS) Agreement' && form.Status__c != 'Complete'){
            helper.PDSAgreementForm(component,formLineItems,form,dependentQuestionindex,changeValue,questionText);
            component.set("v.formWrapperObject",formLineItems);
        }
        if(form.Name == 'Pharmacy Data Service (PDS) Agreement - GNP' && form.Status__c != 'Complete'){
            helper.PDSAgreementForm(component,formLineItems,form,dependentQuestionindex,changeValue,questionText);
            component.set("v.formWrapperObject",formLineItems);
        }
        if(questionText == 'Describe your shipping business type'){
            if(objString.search('Pharmacy') != -1){
                formLineItems[dependentQuestionindex+1].formLineItem.IsRequired__c = true;
                formLineItems[dependentQuestionindex+1].formLineItem.Show_on_Screen__c = true;
                component.set("v.formWrapperObject",formLineItems);
            }
            else if(objString.search('Pharmacy') == -1){
                formLineItems[dependentQuestionindex+1].formLineItem.IsRequired__c = false;
                formLineItems[dependentQuestionindex+1].formLineItem.Show_on_Screen__c = false;
                component.set("v.formWrapperObject",formLineItems);
            }
            if(objString.search('Physician') != -1){
                formLineItems[dependentQuestionindex+2].formLineItem.IsRequired__c = true;
                formLineItems[dependentQuestionindex+2].formLineItem.Show_on_Screen__c = true;
                component.set("v.formWrapperObject",formLineItems);
            }
            else if(objString.search('Physician') == -1){
                formLineItems[dependentQuestionindex+2].formLineItem.IsRequired__c = false;
                formLineItems[dependentQuestionindex+2].formLineItem.Show_on_Screen__c = false;
                component.set("v.formWrapperObject",formLineItems);
            }
            if(objString.search('Other') != -1){
                formLineItems[dependentQuestionindex+3].formLineItem.IsRequired__c = true;
                formLineItems[dependentQuestionindex+3].formLineItem.Show_on_Screen__c = true;
                component.set("v.formWrapperObject",formLineItems);
            }
            else if(objString.search('Other') == -1){
                formLineItems[dependentQuestionindex+3].formLineItem.IsRequired__c = false;
                formLineItems[dependentQuestionindex+3].formLineItem.Show_on_Screen__c = false;
                component.set("v.formWrapperObject",formLineItems);
            }
        }
        if(formLineItems[dependentQuestionindex].formLineItem.Is_Same_As__c == true){
            var action = component.get("c.getSameAsMultipleValue");
            action.setParams({"formName" : formName,"dependentQuestionorder" : formLineItems[dependentQuestionindex].formLineItem.Order__c, "value" : formLineItems[dependentQuestionindex].MultiSelectOption[0].label});
            action.setCallback(this, function(response) {
                var state = response.getState();
                if (state === "SUCCESS"){
                    var responseValue = response.getReturnValue();
                    var i,j,k;
                    if(changeValue.length == 1){
                        for(i=0;i<responseValue.length;i++){
                            for(j=0;j<dependentQuestionindex; j++){
                                if(responseValue[i].controllingQuestionNumber == formLineItems[j].formLineItem.Order__c){
                                    for(k=dependentQuestionindex;k<formLineItems.length; k++){
                                        if(formLineItems[k].formLineItem.Response_Type__c == 'Existing Account Address'){
                                            formLineItems[k].formLineItem.Response__c = false;
                                            formLineItems[k].multiSelectedOption = [];
                                        }
                                        if(formLineItems[k].formLineItem.Order__c == responseValue[i].dependentQuestionNumber){
                                            formLineItems[k].formLineItem.Response__c = formLineItems[j].formLineItem.Response__c;
                                            //formLineItems[k].disabled = true;
                                            //formLineItems[k].formLineItem.IsProtectedData__c = true;
                                        	break;
                                        }
                                    }
                                    break;
                                }
                            }
                        }
                    }else{
                        for(i=0;i<responseValue.length;i++){
                            var dependentIndex = responseValue[i].dependentQuestionNumber-1;
                            formLineItems[dependentIndex].formLineItem.IsProtectedData__c = false;
                            formLineItems[dependentIndex].disabled = false;
                            formLineItems[dependentIndex].formLineItem.Response__c = '';
                        }
                    }
                    component.set("v.formWrapperObject", formLineItems);
                }else{
                    var errors = response.getError();
                    if (errors) {
                        if (errors[0] && errors[0].message) {
                            console.log("Error message: " + errors[0].message);
                            var toastEvent = $A.get("e.force:showToast");
                            toastEvent.setParams({
                                title : 'Error',
                                message: errors[0].message,
                                type: 'error',
                            });
                            toastEvent.fire();
                        }
                    }
                }
            });
            $A.enqueueAction(action);
        }else if(formLineItems[dependentQuestionindex].formLineItem.HasDependent__c == true){
            var action = component.get('c.getDependentPicklistMetadata');
            action.setParams({
                "FormName" : formName,
                "ContQuestionText" : currentLineItemObj.formLineItem.Order__c.toString(),
                "ContFieldValue" : formLineItems[dependentQuestionindex].MultiSelectOption[0].label
            });
            action.setCallback(this, function(res){
                var state = res.getState();
                if(state == 'SUCCESS') {
                    var responseValue = res.getReturnValue();
                    if(formName == 'Retail Price Request'){
                        var displayOrder = responseValue.Dependent_Question_Text__c.split(",");
                        var i;
                        for(i = 0; i<formLineItems.length; i++){
                            var order = formLineItems[i].formLineItem.Order__c.toString();
                            var j;
                            for(j=0; j<displayOrder.length; j++){
                                if(order == displayOrder[j] && changeValue.length == 1){
                                    formLineItems[i].formLineItem.IsRequired__c = false;
                                }else if(order == displayOrder[j] && changeValue.length == 0){
                                    formLineItems[i].formLineItem.IsRequired__c = true;
                                }
                            }
                        }
                    }
                    component.set("v.formWrapperObject", formLineItems);
                }
            });
            $A.enqueueAction(action);
        }
    },
    goToFormGroupPage : function (component, event, helper){
        var vfUrl = '/form-group-standard';
        var urlEvent = $A.get("e.force:navigateToURL");
        urlEvent.setParams({
            "url": vfUrl
        });
        urlEvent.fire();
    },
    closeModel: function(component, event, helper) {
        // Set isModalOpen attribute to false  
        component.set("v.isModalOpen", false);
    },
    handleContactSelection : function(component, event, helper) {
        var selectedOptionValue = event.getSource().get("v.name");
        var selectedOption = event.getSource().get("v.value");
        var formLineItemObject = component.get("v.formWrapperObject");
        var curPageNumber = component.get("v.pageNumber");
        var i;
        var formObj = component.get("v.onboardingForm");
        //var conList = cmp.get('v.authContactList');
        if(selectedOption == '' && formLineItemObject[selectedOptionValue + 1].formLineItem.Question_Text__c == 'Title'){
            if(formObj.Name != 'AmerisourceBergen Credit Application'){
            formLineItemObject[selectedOptionValue + 1].formLineItem.IsRequired__c = false;
            formLineItemObject[selectedOptionValue + 1].formLineItem.Show_on_Screen__c = false;
            component.set("v.formWrapperObject",formLineItemObject);
            } 	
            else{
            formLineItemObject[selectedOptionValue + 6].formLineItem.IsRequired__c = false;
            formLineItemObject[selectedOptionValue + 6].formLineItem.Show_on_Screen__c = false;
            component.set("v.formWrapperObject",formLineItemObject);
            }            
        }
        else{
            if(formObj.Name == 'Declaration of Intention (Florida State)' ||
               formObj.Name == 'Contract Pharmacy Addendum' ||
               formObj.Name == 'Price Stickers Information' ||
               formObj.Name == 'PRxO® Generics Solution Agreement' ||
               formObj.Name == 'Request Extended Dating for Opening Order' ||
               formObj.Name == 'CSRA 590 Practitioner Questionnaire' ||
               formObj.Name == 'Declaration of Eligibility for Contract Pricing - GPO' ||
               formObj.Name == 'Declaration of Eligibility for Contract Pricing - 340B' ||
               formObj.Name == 'Contract Pharmacy Agreement'){
                var action = component.get("c.verifyUserTitle");
                action.setParams({"conId" : selectedOption});
                action.setCallback(this, function(response) {
                    var state = response.getState();
                    if (state === "SUCCESS"){
                        var responseValue = response.getReturnValue();
                        if(formLineItemObject[selectedOptionValue + 1].formLineItem.Question_Text__c == 'Title'){
                            if(responseValue == false){
                                formLineItemObject[selectedOptionValue + 1].formLineItem.IsRequired__c = true;
                                formLineItemObject[selectedOptionValue + 1].formLineItem.Show_on_Screen__c = true;
                                formLineItemObject[selectedOptionValue + 1].formLineItem.Response__c = '';
                            }else{
                                formLineItemObject[selectedOptionValue + 1].formLineItem.IsRequired__c = false;
                                formLineItemObject[selectedOptionValue + 1].formLineItem.Show_on_Screen__c = false;
                            }
                        }
                    }
                    component.set("v.formWrapperObject",formLineItemObject);
            });
                $A.enqueueAction(action);
            }else if(formObj.Name == 'AmerisourceBergen Credit Application' && curPageNumber == '6'){
                var action = component.get("c.verifyUserTitle");
                action.setParams({"conId" : selectedOption});
                action.setCallback(this, function(response) {
                    var state = response.getState();
                    if (state === "SUCCESS"){
                        var responseValue = response.getReturnValue();
                        if(responseValue == false){
                            formLineItemObject[selectedOptionValue + 6].formLineItem.IsRequired__c = true;
                            formLineItemObject[selectedOptionValue + 6].formLineItem.Show_on_Screen__c = true;
                            formLineItemObject[selectedOptionValue + 6].formLineItem.Response__c = '';
                        }else{
                            formLineItemObject[selectedOptionValue + 6].formLineItem.IsRequired__c = false;
                            formLineItemObject[selectedOptionValue + 6].formLineItem.Show_on_Screen__c = false;
                        }
                    }
                    component.set("v.formWrapperObject",formLineItemObject);
                });
                $A.enqueueAction(action);
            }
        }
        var selectedOptionLabel = event.getSource().get("v.label");
        var formLineItemList = [];
        if((formObj.Name == 'New Account Information' || 
            formObj.Name == 'Letter of Authorization' || 
            formObj.Name == 'CSRA 590 Retail Pharmacy Questionnaire' || 
            formObj.Name == 'CSRA 590 Practitioner Questionnaire' || 
            formObj.Name == 'CSRA 590 Hospital Questionnaire' ||
            formObj.Name == 'CSRA 600 Retail Pharmacy Chain Questionnaire' ||
            formObj.Name == 'Payment Term and Method Agreement (up to $25k)')){
            var action = component.get("c.verifyContactField");
            for(var j=selectedOptionValue+1;j<formLineItemObject.length;j++){
                if(formLineItemObject[j].formLineItem.Response_Type__c == 'Add a New Contact'){
                    break;
                }
                if(formLineItemObject[j].formLineItem.Response_Mapped_Field__c != null){
                    formLineItemList.push(formLineItemObject[j].formLineItem);
                }
            }
            if(selectedOption != null && selectedOption != ''){
                action.setParams({"conId" : selectedOption,                                   
                                  "accountId" : formObj.Account__c,
                                  "fLIList" : formLineItemList});
                action.setCallback(this, function(response) {
                    var state = response.getState();
                    if (state === "SUCCESS"){
                        var resMap = response.getReturnValue()
                        var responseValue = resMap.FieldList;
                        component.set("v.selectedContactList",responseValue);
                        var currentCon = resMap.Contact;
                        for(var j=selectedOptionValue+1;j<formLineItemObject.length;j++){
                            if(formLineItemObject[j].formLineItem.Response_Type__c == 'Add a New Contact'){
                                break;
                            }
                            var resVal = 0;
                            if(formLineItemObject[j].formLineItem.Mapped_Object__c == 'Contact'){                                
                            	resVal = responseValue.toString().search(formLineItemObject[j].formLineItem.Response_Mapped_Field__c);
                                if(formObj.Name == 'Letter of Authorization' && formObj.Status__c != 'Complete'){
                                        if(formLineItemObject[j].formLineItem.Question_Text__c == 'Address' && formLineItemObject[j].formLineItem.Response_Mapped_Field__c == 'MailingStreet'){
                                            formLineItemObject[j].formLineItem. Response__c = currentCon.MailingStreet ;
                                        }
                                        if(formLineItemObject[j].formLineItem.Question_Text__c == 'City' && formLineItemObject[j].formLineItem.Response_Mapped_Field__c == 'MailingCity'){
                                            formLineItemObject[j].formLineItem.Response__c = currentCon.MailingCity ;
                                        }
                                        if(formLineItemObject[j].formLineItem.Question_Text__c == 'State' && formLineItemObject[j].formLineItem.Response_Mapped_Field__c == 'MailingState'){
                                            formLineItemObject[j].formLineItem.Response__c = currentCon.MailingState ;
                                        }
                                        if(formLineItemObject[j].formLineItem.Question_Text__c == 'ZIP Code' && formLineItemObject[j].formLineItem.Response_Mapped_Field__c == 'MailingPostalCode'){
                                            formLineItemObject[j].formLineItem.Response__c = currentCon.MailingPostalCode ;
                                        }
                                        if(formLineItemObject[j].formLineItem.Question_Text__c == 'Country' && formLineItemObject[j].formLineItem.Response_Mapped_Field__c == 'MailingCountry'){
                                            formLineItemObject[j].formLineItem.Response__c == 'United States' ;
                                        }                                                             
                                }
                            }else if(formLineItemObject[j].formLineItem.Mapped_Object__c == 'License__c'){
                                resVal = responseValue.toString().search(formLineItemObject[j].formLineItem.Mapped_Object_Controlling_Field_Value__c);
                            }else if(formLineItemObject[j].formLineItem.Mapped_Object__c == 'AccountContactRelation'){
                                resVal = responseValue.toString().search(formLineItemObject[j].formLineItem.Response_Mapped_Field__c);
                            }                             
                            if(resVal == -1){
                                formLineItemObject[j].formLineItem.IsRequired__c = true;
                                formLineItemObject[j].formLineItem.Show_on_Screen__c = true;
                                formLineItemObject[j].formLineItem.Response__c = '';
                            }else{
                                if(formLineItemObject[j].formLineItem.Mapped_Object__c == 'Contact' || formLineItemObject[j].formLineItem.Mapped_Object__c == 'AccountContactRelation' || formLineItemObject[j].formLineItem.Mapped_Object__c == 'License__c'){
                                    formLineItemObject[j].formLineItem.IsRequired__c = false;
                                    formLineItemObject[j].formLineItem.Show_on_Screen__c = false;
                                    for(var k=0; k<responseValue.length; k++){
                                        var str = responseValue[k];
                                        if(str.includes('--') && str.split('--')[0] == formLineItemObject[j].formLineItem.Mapped_Object_Controlling_Field_Value__c){
                                            formLineItemObject[j].formLineItem.Response__c = str.split('--')[1];
                                            break;
                                        }
                                    }
                                }                               
                            } 
                            if(formObj.Name == 'CSRA 590 Practitioner Questionnaire' && curPageNumber == '4' && formLineItemObject[j].formLineItem.Question_Text__c == 'Practitioner License Number'){
                                	formLineItemObject[j].formLineItem.IsRequired__c = false;
                                    formLineItemObject[j].formLineItem.Show_on_Screen__c = false;
                            }
                        }
                    }
                    component.set("v.formWrapperObject",formLineItemObject);
                });
                $A.enqueueAction(action);
            }else if(formObj.Name != 'CSRA 590 Retail Pharmacy Questionnaire' && curPageNumber != '8'){
                formLineItemObject[selectedOptionValue + 1].formLineItem.IsRequired__c = false;
                formLineItemObject[selectedOptionValue + 1].formLineItem.Show_on_Screen__c = false;
            }
        }
    },
    showAddNewContact : function(component, event, helper) {
        var itemDesc = event.getSource().get("v.title");
        component.set("v.contactLineItemDesc",itemDesc);
        component.set("v.showContactModal", true);
    },
    handleOnBlur : function(component, event, helper) { 
        helper.onBlurHelper(component,event);
        var OnboardingForm = component.get("v.onboardingForm");
        var formLineItemObject = component.get("v.formWrapperObject");
        var curPageNumber = component.get("v.pageNumber");
        var selectedOption = event.getSource().get("v.value");
        var selectedOptionValue = event.getSource().get("v.name");
        var questionText = event.getSource().get("v.label");
        var totalPercent = 0;  
        var percentCount = 0 ;
        if((OnboardingForm.Name == 'CSRA 590 Retail Pharmacy Questionnaire' ||
            OnboardingForm.Name == 'CSRA 590 Hospital Questionnaire' ||
            OnboardingForm.Name == 'CSRA 590 Distributor Questionnaire' ||
            OnboardingForm.Name == 'CSRA 600 Retail Pharmacy Chain Questionnaire' ||
            OnboardingForm.Name == 'CSRA 590 Practitioner Questionnaire') && OnboardingForm.Status__c != 'Complete'){
            for(var i=0; i<formLineItemObject.length; i++){
                if(formLineItemObject[i].formLineItem.Response_Type__c == 'Percentage' && formLineItemObject[i].formLineItem.Response__c != null && 
                   formLineItemObject[i].formLineItem.Display_Page_Number__c == curPageNumber && formLineItemObject[i].formLineItem.HasDependent__c == true){  
                    totalPercent += Number(formLineItemObject[i].formLineItem.Response__c);
                    if(formLineItemObject[i+1].formLineItem.Response_Type__c != 'Percentage' && formLineItemObject[i+1].formLineItem.Is_Summary__c == true){
                        formLineItemObject[i+1].formLineItem.Response__c = totalPercent+'%';
                        percentCount = totalPercent;
                        totalPercent = 0;
                    }
                }
            }
            component.set("v.totalPercent", percentCount);
            percentCount = 0;
            if(questionText == 'Other'){
                if(formLineItemObject[selectedOptionValue].formLineItem.Response__c == null || formLineItemObject[selectedOptionValue].formLineItem.Response__c == 0){
                    formLineItemObject[selectedOptionValue+2].formLineItem.IsRequired__c = false;
                    formLineItemObject[selectedOptionValue+2].formLineItem.Show_on_Screen__c = false;
                }else{
                    formLineItemObject[selectedOptionValue+2].formLineItem.IsRequired__c = true;
                    formLineItemObject[selectedOptionValue+2].formLineItem.Show_on_Screen__c = true;                
                }
            }
            component.set("v.formWrapperObject",formLineItemObject);                       
        }        
        var spouseName = event.getSource().get("v.value");
        if(OnboardingForm.Name == 'AmerisourceBergen Personal Guaranty' && questionText == 'Spouse name'){
            var currentIndex = event.getSource().get("v.name");
            var isRequired = false;
            var lastIndex = currentIndex + 7;
            if(spouseName != null && spouseName != ''){
                isRequired = true;
            }
            for(var i=currentIndex + 1; i< lastIndex; i++){
                formLineItemObject[i].formLineItem.IsRequired__c = isRequired;
            }
            component.set("v.formWrapperObject",formLineItemObject);
        }
    },
    handleOnFocus : function(component, event, helper) {
        var questionText = event.getSource().get("v.label");
        if(questionText == 'Owner (s) since'){
            var dateString =  event.getSource().get("v.value");
            var newTest = dateString.replace('/','');
            event.getSource().set("v.value", newTest);
        }
    },
    doSave: function(component, event, helper) {
        var formObj = component.get("v.onboardingForm");
        if (component.find("fileId").get("v.files").length > 0) {
            helper.uploadHelper(component, event);
        } else {
            var toastEvent = $A.get("e.force:showToast");
            toastEvent.setParams({
                title : 'Error',
                message: "Please Select a Valid File",
                type: 'error',
            });
            toastEvent.fire();
        }
    },
 
    doSave1: function(component, event, helper) {      
        if (component.find("fileId1").get("v.files").length > 0) {
            helper.uploadHelper1(component, event);
        } else {
			var toastEvent = $A.get("e.force:showToast");
            toastEvent.setParams({
                title : 'Error',
                message: "Please Select a Valid File",
                type: 'error',
            });
            toastEvent.fire();
        }
    },
    
     handleFilesChange: function(component, event, helper) {
        if (event.getSource().get("v.files").length > 0) {
            helper.uploadHelper(component, event);
        } else {
            
			var toastEvent = $A.get("e.force:showToast");
            toastEvent.setParams({
                title : 'Error',
                message: "Please Select a Valid File",
                type: 'error',
            });
            toastEvent.fire();
        }
    },
    
    handleRowAction: function (component, event, helper) {
        var action = event.getParam('action');
        var row = event.getParam('row');
        switch (action.name) {
            case 'delete_details':
                
                var strConfirmtion = '';
                if (confirm("Are you sure you want to delete?")) {
                    strConfirmtion = "OK";
                } else {
                    strConfirmtion = "Cancel";
                }
                if (strConfirmtion == 'OK'){
                    helper.deleteRow(component,row);
                }
                break;
            default:
                break;
        }
    },
})