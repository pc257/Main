({
    inithelper : function(cmp, lineItemsToDisplay, formObj){
        // Set the attribute value. 
        // You could also fire an event here instead.
        //cmp.set("v.setMeOnInit", "controller init magic!");   
        var onboardingLineItemId = '';
        cmp.set('v.mycolumns', [
            { label: 'Name',fieldName:'FileLeafRef',type: 'text'},
            {label: 'Delete',fieldName: 'FileRef',type: 'button', initialWidth: 0, typeAttributes: { label: '', name: 'delete_details', title: '',iconName: "action:close"}}
            
        ]);
        var conNameList = [];
        var contactList = [];
        var accConRelNameList = [];
        var accConRelList = [];
        var conName = '';
        var conTitleCheck = '';
        var conPercentageCheck = '';
        var licList = [];
        var runningCon;
        var action = cmp.get("c.getContacts");
        action.setParams({"accountId" : formObj.Account__c, "onbFormId" : formObj.Id});
        action.setCallback(this, function(response) {
            var state = response.getState();
            if (state === "SUCCESS"){                
                var responseValue = response.getReturnValue();
                if(responseValue != null){
                    if(responseValue.runningUserContact.Name != '' && responseValue.runningUserContact.Name != undefined){
                        conName = responseValue.runningUserContact.Id;
                        if(responseValue.runningUserContact.Title != null && responseValue.runningUserContact.Title != '' && responseValue.runningUserContact.Title != undefined){
                            cmp.set('v.defaultContactTitle',true);
                        }
                        conTitleCheck = responseValue.TitleCheck;
                        conPercentageCheck = responseValue.percentageOfOwnershipCheck;
                        runningCon = responseValue.runningUserContact;
                        licList = responseValue.currentLicenseType;
                        cmp.set('v.licenseList', licList);
                        cmp.set("v.selectedContactList",responseValue);
                        cmp.set('v.recordId',responseValue.AccountId);
                        cmp.set('v.accName',responseValue.AccountName);
                        cmp.set('v.accNumber',responseValue.AccountNumber);
                    }
                    var conList = responseValue.ContactList;
                    //cmp.set('v.accName',conList[0]);
                    //cmp.set('v.authContactList',conList);
                    var conCount = 0;
                    
                    for(conCount = 0; conCount < conList.length; conCount++){
                        contactList.push({
                            label: conList[conCount].Contact.Name,
                            value: conList[conCount].Contact.Id
                        });
                        conNameList.push(conList[conCount].Contact.Name);
                    }
                    
                    var accConList = responseValue.accConRelList;
                    var accConCount = 0;     
                    for(accConCount = 0; accConCount < accConList.length; accConCount++){
                        accConRelList.push({
                            label: accConList[accConCount].Account.SAP_Account_Number_Name__c,
                            value: accConList[accConCount].AccountId
                        });
                        accConRelNameList.push(accConList[accConCount].Account.SAP_Account_Number_Name__c);
                    }
                }
            }
            var formLineItem = cmp.get("v.onboardingFormLineItems");
            var i, jspickListMap;
            var formWrapperArray = [];
            var sectionArray = [];
            var pageNumberArray = [];
            var pageSectionArray = [];
            var isReadOnly = cmp.get("v.hasReadAccess");
            var noOfOwner = -1;
            var count = 0;
            var index=1;
            var pageNumberArrayObj = [];
            var pgNumberMap = new Map(); 
            for(i=0; i < formLineItem.length; i++){
                var str = '';
                str = lineItemsToDisplay.toString();
                if(formLineItem[i].Response_Type__c == 'Sharepoint File Upload' ){
                    formLineItem[i].mydata = [];
                }
                if(formObj.Name == 'New Account Information' && formObj.Status__c != 'Complete'){
                    if(formLineItem[i].Mapped_Object__c == 'Onboarding__c' && formLineItem[i].Response_Mapped_Field__c == 'Receive_DSCSA_report_via_a_ASN__c' && formLineItem[i].Question_Text__c == 'Would you like to receive your DSCSA regulatory data (Transaction Information, Transaction History, & Transaction Statement) via a DSCSA compliant ASN?'){
                        if(formLineItem[i].Response__c == 'Yes'){
                            formLineItem[i+1].IsRequired__c = true;
                            formLineItem[i+1].Show_on_Screen__c = true;
                            formLineItem[i+2].Show_on_Screen__c = true;
                            formLineItem[i+3].Show_on_Screen__c = true;
                        }else{
                            formLineItem[i+1].IsRequired__c = false;
                            formLineItem[i+1].Show_on_Screen__c = false;
                            formLineItem[i+2].Show_on_Screen__c = false;
                            formLineItem[i+3].Show_on_Screen__c = false;
                        }
                    }
                }
                if(formObj.Name == 'Letter of Authorization' && formObj.Status__c != 'Complete'){
                    if(formLineItem[i].Mapped_Object__c == 'Contact'){
                        if(formLineItem[i].Question_Text__c == 'Address' && formLineItem[i].Response_Mapped_Field__c == 'MailingStreet'){
                            formLineItem[i].Response__c = runningCon.MailingStreet ;
                        }
                        if(formLineItem[i].Question_Text__c == 'City' && formLineItem[i].Response_Mapped_Field__c == 'MailingCity'){
                            formLineItem[i].Response__c = runningCon.MailingCity ;
                        }
                        if(formLineItem[i].Question_Text__c == 'State' && formLineItem[i].Response_Mapped_Field__c == 'MailingState'){
                            formLineItem[i].Response__c = runningCon.MailingState ;
                        }
                        if(formLineItem[i].Question_Text__c == 'ZIP Code' && formLineItem[i].Response_Mapped_Field__c == 'MailingPostalCode'){
                            formLineItem[i].Response__c = runningCon.MailingPostalCode ;
                        }
                        if(formLineItem[i].Question_Text__c == 'Country' && formLineItem[i].Response_Mapped_Field__c == 'MailingCountry'){
                            formLineItem[i].Response__c == 'United States' ;
                        }                         
                    }
                }
                if(formLineItem[i].Question_Text__c == 'Select the number of person(s) owning 10% or more of the business.'){
                    noOfOwner =  formLineItem[i].Response__c;
                }
                if(formLineItem[i].Display_Page_Number__c != null && (lineItemsToDisplay.length == 0 || (lineItemsToDisplay.length > 0 && str.search(formLineItem[i].Order__c) != -1))){
                    var formWrapper = {};
                    formWrapper.formLineItem = formLineItem[i];
                    formWrapper.PicklistOption = [];
                    formWrapper.MultiSelectOption = [];
                    formWrapper.MultiSelectResponse = [];
                    formWrapper.FileNames = [];
                    formWrapper.numberPattern = '';
                    formWrapper.booleanResponse = false;
                    formWrapper.disabledDeliveryOption = false;
                    //alert('Onhold---'+formObj.IsOnHold__c);
                    if(formObj.Status__c == 'Complete' || formObj.IsOnHold__c == true || isReadOnly == true || formObj.Status__c == 'Executed'){
                        formWrapper.disabled = true;
                    }else{
                        formWrapper.disabled = false;
                    }
                    var a = sectionArray.indexOf(formLineItem[i].Display_Page_Section__c);
                    var b = pageNumberArray.indexOf(formLineItem[i].Display_Page_Number__c);
                    
                    //if(formLineItem[i].Show_on_Screen__c == true){
                    if(b==-1 && formLineItem[i].Display_Page_Number__c != null){
                        sectionArray.push(formLineItem[i].Display_Page_Section__c);
                        pageNumberArray.push(formLineItem[i].Display_Page_Number__c);
                        pgNumberMap.set(formLineItem[i].Display_Page_Number__c, index);
                        pageNumberArrayObj.push({
                            label: formLineItem[i].Display_Page_Number__c,
                            value: index
                        });
                        index++;
                        if(a==-1 && formLineItem[i].Display_Page_Section__c != null){
                            sectionArray.push(formLineItem[i].Display_Page_Section__c);
                        }
                        var pageSection = {};
                        pageSection.pageNumber = formLineItem[i].Display_Page_Number__c;
                        pageSection.sectionName = formLineItem[i].Display_Page_Section__c;
                        pageSectionArray.push(pageSection);
                    }
                    //}
                    if(formLineItem[i].Response_Type__c == 'Account List'){
                        formWrapper.MultiSelectResponse = accConRelList;
                    }
                    
                    if(formLineItem[i].Response_Type__c == 'Contact List'){
                        formWrapper.PicklistOption = conNameList;
                        formWrapper.MultiSelectResponse = contactList;
                        if(formObj.Status__c != 'Complete' && 
                           (formObj.Name == 'CSRA 590 Practitioner Questionnaire' || 
                            formObj.Name == 'CSRA 600 Retail Pharmacy Chain Questionnaire' ||
                            (formObj.Name == 'CSRA 590 Retail Pharmacy Questionnaire' && formLineItem[i].Display_Page_Number__c != 14) ||
                            (formObj.Name == 'CSRA 590 Hospital Questionnaire' && formLineItem[i].Display_Page_Number__c != 12) ||
                            formObj.Name == 'Letter of Authorization')){
                            for(var j=i+1;j<formLineItem.length;j++){
                                if(formLineItem[j].Response_Type__c == 'Add a New Contact'){
                                    break;
                                }else if(formLineItem[j].Mapped_Object__c == 'License__c'){
                                    if(licList.toString().search(formLineItem[j].Mapped_Object_Controlling_Field_Value__c) == -1){
                                        formLineItem[j].IsRequired__c = true;
                                        formLineItem[j].Show_on_Screen__c = true;
                                        formLineItem[j].Response__c = '';
                                    }else{
                                        formLineItem[j].IsRequired__c = false;
                                        formLineItem[j].Show_on_Screen__c = false;
                                        for(var k=0; k<licList.length; k++){
                                            var str = licList[k];
                                            if((str.includes('--') && 
                                                str.split('--')[0] == formLineItem[j].Mapped_Object_Controlling_Field_Value__c) &&
                                               (formLineItem[j].Response__c == null || formLineItem[j].Response__c__c == '')){                                                 			
                                                formLineItem[j].Response__c = str.split('--')[1];
                                                break;
                                            }
                                        }
                                    }
                                }
                            }
                        }
                        if(formLineItem[i].Question_Text__c != 'Additional Owner\'s Name (if applicable)' && formLineItem[i].Question_Text__c != 'Additional Guarantor'){
                            if(formLineItem[i].Response__c == null){
                                formLineItem[i].Response__c = conName;
                            }
                        }
                        if(conTitleCheck == false && formObj.Status__c != 'Complete' && formLineItem[i+1] != null && formLineItem[i+1].Question_Text__c == 'Title'){
                            //formLineItem[i].Response__c = conName;
                            formLineItem[i+1].Show_on_Screen__c = true;
                            formLineItem[i+1].IsRequired__c = true;
                        }
                        if(noOfOwner > -1 && noOfOwner > count && conTitleCheck == false && formObj.Status__c != 'Complete' && formLineItem[i+6] != null && formLineItem[i+6].Question_Text__c == 'Title'){
                            //formLineItem[i].Response__c = conName;
                            count++;
                            formLineItem[i+6].Show_on_Screen__c = true;
                            formLineItem[i+6].IsRequired__c = true;
                        }
                        if(formLineItem[i].Question_Text__c == 'Owner\'s Name'){
                            if(conPercentageCheck == false && formObj.Status__c != 'Complete' && formLineItem[i+1] != null && formLineItem[i+1].Question_Text__c == 'Percent of Ownership'){
                                formLineItem[i+1].Show_on_Screen__c = true;
                                formLineItem[i+1].IsRequired__c = true;
                            }
                        }
                        if(formObj.Status__c == 'Complete' && formLineItem[i+1].Response__c != null && formLineItem[i+1].Question_Text__c == 'Title'){
                            formLineItem[i+1].Show_on_Screen__c = true;
                            formLineItem[i+1].Response__c = formLineItem[i+1].Response__c;
                            //formLineItem[i+1].IsRequired__c = true;
                        }
                        if(formObj.Name == 'New Account Information'){
                            for(var j=i+1;j<formLineItem.length;j++){
                                if(formLineItem[j].Response_Type__c == 'Add a New Contact'){
                                    break;
                                }
                                var fieldKey = formLineItem[j].Response_Mapped_Field__c;
                                if(runningCon[fieldKey] == null){
                                    formLineItem[j].Show_on_Screen__c = true;
                                    formLineItem[j].IsRequired__c = true;
                                }
                            }
                        }
                    }
                    if(formLineItem[i].Response_Type__c == 'Single Checkbox'){
                        if(formLineItem[i].Response__c == 'true'){
                            formWrapper.booleanResponse = true;
                            //formLineItem[i].Response__c = true;
                        }else if(formLineItem[i].Response__c == 'false'){
                            formWrapper.booleanResponse = false;
                            //formLineItem[i].Response__c = false;
                        }
                    } 
                    if(formLineItem[i].Response_Type__c == 'Number'){
                        var Numpattern;
                        if(formLineItem[i].Response_Maxlength__c != null){
                            Numpattern = '[0-9]{'+formLineItem[i].Response_Maxlength__c+'}';
                        }else{
                            Numpattern = '[0-9]{'+255+'}';
                        }
                        formWrapper.numberPattern = Numpattern;
                    }
                    if(formLineItem[i].Response_Type__c == 'Picklist'){
                        if(formLineItem[i].Response_Validation__c != null){
                            var pickListString = formLineItem[i].Response_Validation__c;
                            var pickListItems = pickListString.split(",");
                            var pickListOptions = [];
                            var pickLbl = '';
                            var pickVal = '';
                            for(var pI = 0; pI < pickListItems.length; pI++){
                                if(pickListItems[pI].indexOf("#;") != -1){
                                    var picItem = pickListItems[pI].split("#;");
                                    pickLbl = picItem[0];
                                    pickVal = picItem[1];
                                }else{
                                    pickLbl = pickListItems[pI];
                                    pickVal = pickListItems[pI];
                                }
                                pickListOptions.push({
                                    label: pickLbl,
                                    value: pickVal
                                });
                            }
                            formWrapper.PicklistOption = pickListOptions;
                        }
                        if((formLineItem[i].Response_Validation__c == null || formLineItem[i].Response_Validation__c == '') && formLineItem[i].Response__c != null){
                            formWrapper.PicklistOption = [];
                            formWrapper.PicklistOption.push({
                                label: formLineItem[i].Response__c,
                                value: formLineItem[i].Response__c
                            });
                            //formLineItem[i].Response__c.split(',');
                        }
                    }
                    if(formLineItem[i].Response__c != null && formLineItem[i].Response_Type__c == 'File Upload'){
                        var formLineItemHelper = formLineItem[i];
                        var x=0;
                        var fileNameDocumentArray = formLineItemHelper.Response__c.split(',');
                        var fileUploadObject = [];
                        for(x=0;x<fileNameDocumentArray.length;x++){
                            var fileSplit = fileNameDocumentArray[x].split('-');
                            fileUploadObject.push({
                                name: fileSplit[0],
                                documentId: fileSplit[1]
                            });
                        }
                        formWrapper.FileNames = fileUploadObject;
                    }
                    if((formLineItem[i].Response_Type__c == 'Multi-Select Picklist' || formLineItem[i].Response_Type__c == 'Radio Button') && formLineItem[i].Response_Validation__c != null){
                        var strDelimeter = ",";
                        if(formLineItem[i].Response_Type__c == 'Multi-Select Picklist'){
                            strDelimeter = ";";
                        }
                        var pickListString = formLineItem[i].Response_Validation__c;
                        var pickListItems = pickListString.split(strDelimeter);
                        var pickListOptions = [];
                        var pickLbl = '';
                        var pickVal = '';
                        for(var pI = 0; pI < pickListItems.length; pI++){
                            if(pickListItems[pI].indexOf("#;") != -1){
                                var picItem = pickListItems[pI].split("#;");
                                pickLbl = picItem[0];
                                pickVal = picItem[1];
                            }else{
                                pickLbl = pickListItems[pI];
                                pickVal = pickListItems[pI];
                            }
                            pickListOptions.push({
                                label: pickLbl,
                                value: pickVal
                            });
                        }
                        formWrapper.MultiSelectOption = pickListOptions;
                        var form = cmp.get("v.onboardingForm");
                        if(formLineItem[i].Response__c == null && (form.Name == 'Payment Term and Method Agreement (up to $25k)' || form.Name == 'Payment Term and Method Agreement')){
                            if(formLineItem[i].Question_Text__c == 'Are you requesting a new payment term or changing your current payment term?'){
                                formLineItem[i].Response__c = 'I\'m requesting a new payment term';
                            }
                        }
                        if(formLineItem[i].Response__c == null && form.Name == 'Payment Term and Method Agreement'){
                            if(formLineItem[i].Question_Text__c == 'Are you requesting a new payment method or changes to your current payment method?'){
                                formLineItem[i].Response__c = 'I\'m requesting a new payment method';
                            }
                        }
                        if(formLineItem[i].Response__c == null && form.Name == 'AmerisourceBergen Personal Guaranty'){
                            if(formLineItem[i].Question_Text__c == 'Ownership type'){
                                formLineItem[i].Response__c = 'Sole proprietorship';
                            }
                        }
                        if(formLineItem[i].Response__c != null && formLineItem[i].Response_Type__c == 'Multi-Select Picklist'){
                            var responseString = formLineItem[i].Response__c;
                            //var responseOptions = responseString.split(",");
                            var responseOptions = responseString.split(";");//For ASD Conga form changed ',' with ';'
                            var responseObject = [];
                            //responseOptions = responseString.split(",");
                            for(var k=0; k<responseOptions.length; k++){
                                responseObject.push({
                                    label: responseOptions[k],
                                    value: responseOptions[k]
                                });
                            }
                            formWrapper.MultiSelectResponse = responseOptions;
                        }
                        if(formLineItem[i].Response__c != null && formLineItem[i].Response_Type__c == 'Radio Button'){
                            var form = cmp.get("v.onboardingForm");
                            if(form.Name == 'PRxO® Generics Solution Agreement'){
                                if(formLineItem[i].Response__c == 'No'){
                                    cmp.set("v.nextButtonLabel", 'Finish & Submit Form');
                                }else {
                                    cmp.set("v.nextButtonLabel", 'Next');
                                }
                            }
                            if(form.Name == 'New Account Merchandising Request'){
                                if(formLineItem[i].Response__c == 'I don\'t require merchandising services or labeling'){
                                    cmp.set("v.nextButtonLabel", 'Finish & Submit Form');
                                }else{
                                    cmp.set("v.nextButtonLabel", 'Next');
                                }
                            }
                        }
                    }
                    formWrapperArray.push(formWrapper);
                }
            }
            var onbForm = cmp.get('v.onboardingForm');
            cmp.set("v.formWrapperObject",formWrapperArray);
            cmp.set("v.pageSectionObject",pageSectionArray);
            cmp.set("v.sectionName", sectionArray[0]);
            cmp.set("v.sectionNameSet", sectionArray);
            var curPageNumber;
            var pgIndex;
            /*if(pgNumberMap.size > 0){
                if(pgNumberMap.get() != undefined){
                    
                }
            }*/
            if(onbForm.Last_Visited_Page__c != null){
                curPageNumber = onbForm.Last_Visited_Page__c;
                pgIndex = pgNumberMap.get(onbForm.Last_Visited_Page__c);
                //cmp.set("v.pageNumber", onbForm.Last_Visited_Page__c);
            }else{
                curPageNumber = pageNumberArray[0];
                pgIndex = pgNumberMap.get(pageNumberArray[0]);
                //curPageNumber = pageNumberArrayObj[0].value;-----By Tejas
                //cmp.set("v.pageNumber",pageNumberArray[0]);
            }
            cmp.set("v.pageNumber", curPageNumber);
            cmp.set("v.pgNumberIndex", pgIndex);
            cmp.set("v.pgNumberIndexMap",pgNumberMap);
            for(i=0; i < formLineItem.length; i++){
                if(formLineItem[i].Display_Page_Number__c == curPageNumber && formLineItem[i].Response_Type__c == 'Sharepoint File Upload' && onboardingLineItemId == ''){
                    onboardingLineItemId = formLineItem[i].Id;
                }
            }
            //if(curPageNumber != 1){
            if(pgIndex != 1){
                cmp.set("v.backButtonLabel",'Back');
            }
            //pgIndex
            if(pageNumberArray.length == 1 || pgIndex == pageNumberArray.length){
                //if(pageNumberArray.length == 1 || curPageNumber == pageNumberArray.length){
                cmp.set("v.nextButtonLabel",'Finish & Submit Form');
            }
            cmp.set("v.pageNumberSet", pageNumberArray);
            //cmp.set("v.pageNumberSet", pageNumberArrayObj);-----By Tejas
            this.getSummaryQuestion(cmp);
            var spinnerComp = cmp.find("mySpinner");
            $A.util.addClass(spinnerComp, "slds-hide");
            if(onboardingLineItemId != ''){
                this.fetchData(cmp, onboardingLineItemId);
            }
        });
        $A.enqueueAction(action);
    },
    createFileObject : function(cmp,event,formLineItemHelper) {
        var x=0;
        var fileNameDocumentArray = formLineItemHelper.Response__c.split(',');
        var fileUploadObject = [];
        for(x=0;x<fileNameDocumentArray.length;x++){
            var fileSplit = fileNameDocumentArray[x].split('-');
            fileUploadObject.push({
                name: fileSplit[0],
                documentId: fileSplit[1]
            });
        }
        cmp.set("v.fileName",fileUploadObject);
    },
    navigateToFormPage : function(cmp,OnboardingForm,successMessage){
        var toastEvent = $A.get("e.force:showToast");
        toastEvent.setParams({
            title : 'Success',
            message: successMessage,
            messageTemplate: 'Record {0} created! See it {1}!',
            type: 'success',
        });
        toastEvent.fire();
        var urlEvent = $A.get("e.force:navigateToURL");
        urlEvent.setParams({
            "url": "/form/"+OnboardingForm.Onboarding_Form_Group__c
        });
        urlEvent.fire();
    },
    handleDependencyForAdditionalAccountRequest: function(cmp,formLineItemObject,form,selectedOptionValue,selectedOptionVal,currentLineItemObj){        
        if(currentLineItemObj.formLineItem.Question_Text__c == 'Would you like to receive your DSCSA regulatory data (Transaction information, Transaction history, and Transation statement) via a DSCSA complianr ASN?'){            
            if(selectedOptionVal == 'Yes'){
                formLineItemObject[selectedOptionValue+1].formLineItem.IsRequired__c = true;
                formLineItemObject[selectedOptionValue+1].formLineItem.Show_on_Screen__c = true;
                formLineItemObject[selectedOptionValue+2].formLineItem.IsRequired__c = true;
                formLineItemObject[selectedOptionValue+2].formLineItem.Show_on_Screen__c = true;
                formLineItemObject[selectedOptionValue+3].formLineItem.IsRequired__c = true;
                formLineItemObject[selectedOptionValue+3].formLineItem.Show_on_Screen__c = true;
            }else{
                formLineItemObject[selectedOptionValue+1].formLineItem.IsRequired__c = false;
                formLineItemObject[selectedOptionValue+1].formLineItem.Show_on_Screen__c = false;
                formLineItemObject[selectedOptionValue+2].formLineItem.IsRequired__c = false;
                formLineItemObject[selectedOptionValue+2].formLineItem.Show_on_Screen__c = false;
                formLineItemObject[selectedOptionValue+3].formLineItem.IsRequired__c = false;
                formLineItemObject[selectedOptionValue+3].formLineItem.Show_on_Screen__c = false;
            }
        }          
    },
    CSRA600RetailDependency: function(cmp,formLineItemObject,form,selectedOptionValue,selectedOptionVal,currentLineItemObj){ 
        if(currentLineItemObj.formLineItem.Question_Text__c == 'Is there a common DBA for each pharmacy location?'){
            if(selectedOptionVal == 'Yes'){
                formLineItemObject[selectedOptionValue+1].formLineItem.Show_on_Screen__c = true;
                formLineItemObject[selectedOptionValue+1].formLineItem.IsRequired__c = true;
            }else{
                formLineItemObject[selectedOptionValue+1].formLineItem.Show_on_Screen__c = false;
                formLineItemObject[selectedOptionValue+1].formLineItem.IsRequired__c = false;
            }
        }else if(currentLineItemObj.formLineItem.Question_Text__c == 'Does the Corporation have a Compliance and/or Regulatory Affairs Department?'){
            if(selectedOptionVal == 'Yes'){
                formLineItemObject[selectedOptionValue+1].formLineItem.Show_on_Screen__c = true;
                formLineItemObject[selectedOptionValue+1].formLineItem.IsRequired__c = false;
                formLineItemObject[selectedOptionValue+2].formLineItem.Show_on_Screen__c = true;
                formLineItemObject[selectedOptionValue+2].formLineItem.IsRequired__c = true;
                formLineItemObject[selectedOptionValue+3].formLineItem.Show_on_Screen__c = true;
                formLineItemObject[selectedOptionValue+3].formLineItem.IsRequired__c = true;
                formLineItemObject[selectedOptionValue+4].formLineItem.Show_on_Screen__c = true;
                formLineItemObject[selectedOptionValue+4].formLineItem.IsRequired__c = true;
                formLineItemObject[selectedOptionValue+5].formLineItem.Show_on_Screen__c = true;
                formLineItemObject[selectedOptionValue+5].formLineItem.IsRequired__c = true;
                formLineItemObject[selectedOptionValue+6].formLineItem.Show_on_Screen__c = true;
                formLineItemObject[selectedOptionValue+6].formLineItem.IsRequired__c = true;
            }else{
                formLineItemObject[selectedOptionValue+1].formLineItem.Show_on_Screen__c = false;
                formLineItemObject[selectedOptionValue+1].formLineItem.IsRequired__c = false;
                formLineItemObject[selectedOptionValue+2].formLineItem.Show_on_Screen__c = false;
                formLineItemObject[selectedOptionValue+2].formLineItem.IsRequired__c = false;
                formLineItemObject[selectedOptionValue+3].formLineItem.Show_on_Screen__c = false;
                formLineItemObject[selectedOptionValue+3].formLineItem.IsRequired__c = false;
                formLineItemObject[selectedOptionValue+4].formLineItem.Show_on_Screen__c = false;
                formLineItemObject[selectedOptionValue+4].formLineItem.IsRequired__c = false;
                formLineItemObject[selectedOptionValue+5].formLineItem.Show_on_Screen__c = false;
                formLineItemObject[selectedOptionValue+5].formLineItem.IsRequired__c = false;
                formLineItemObject[selectedOptionValue+6].formLineItem.Show_on_Screen__c = false;
                formLineItemObject[selectedOptionValue+6].formLineItem.IsRequired__c = false;
            }
        }else if(currentLineItemObj.formLineItem.Question_Text__c == 'Are any of your facilities registered with DEA as wholesale distributors?'){
            if(selectedOptionVal == 'Yes'){
                formLineItemObject[selectedOptionValue+1].formLineItem.Show_on_Screen__c = true;
                formLineItemObject[selectedOptionValue+1].formLineItem.IsRequired__c = false;
                formLineItemObject[selectedOptionValue+2].formLineItem.Show_on_Screen__c = true;
                formLineItemObject[selectedOptionValue+2].formLineItem.IsRequired__c = true;
                formLineItemObject[selectedOptionValue+3].formLineItem.Show_on_Screen__c = true;
                formLineItemObject[selectedOptionValue+3].formLineItem.IsRequired__c = true;
            }else{
                formLineItemObject[selectedOptionValue+1].formLineItem.Show_on_Screen__c = false;
                formLineItemObject[selectedOptionValue+1].formLineItem.IsRequired__c = false;
                formLineItemObject[selectedOptionValue+2].formLineItem.Show_on_Screen__c = false;
                formLineItemObject[selectedOptionValue+2].formLineItem.IsRequired__c = false;
                formLineItemObject[selectedOptionValue+3].formLineItem.Show_on_Screen__c = false;
                formLineItemObject[selectedOptionValue+3].formLineItem.IsRequired__c = false;
            }
        }else if(currentLineItemObj.formLineItem.Question_Text__c == 'If you hold one or more DEA wholesale ditributor registrations, do you have a system in place to detect and report Suspicious Order, i.e. Suspicious Order Monitoring (SOM) program?'){
            if(selectedOptionVal == 'Yes'){
                formLineItemObject[selectedOptionValue+1].formLineItem.Show_on_Screen__c = true;
                formLineItemObject[selectedOptionValue+1].formLineItem.IsRequired__c = true;
                formLineItemObject[selectedOptionValue+2].formLineItem.Show_on_Screen__c = true;
                formLineItemObject[selectedOptionValue+2].formLineItem.IsRequired__c = false;
                formLineItemObject[selectedOptionValue+3].formLineItem.Show_on_Screen__c = true;
                formLineItemObject[selectedOptionValue+3].formLineItem.IsRequired__c = true;
                formLineItemObject[selectedOptionValue+4].formLineItem.Show_on_Screen__c = true;
                formLineItemObject[selectedOptionValue+4].formLineItem.IsRequired__c = true;
                formLineItemObject[selectedOptionValue+5].formLineItem.Show_on_Screen__c = true;
                formLineItemObject[selectedOptionValue+5].formLineItem.IsRequired__c = true;
                formLineItemObject[selectedOptionValue+6].formLineItem.Show_on_Screen__c = true;
                formLineItemObject[selectedOptionValue+6].formLineItem.IsRequired__c = true;
                formLineItemObject[selectedOptionValue+7].formLineItem.Show_on_Screen__c = true;
                formLineItemObject[selectedOptionValue+7].formLineItem.IsRequired__c = true;
            }else{
                formLineItemObject[selectedOptionValue+1].formLineItem.Show_on_Screen__c = false;
                formLineItemObject[selectedOptionValue+1].formLineItem.IsRequired__c = false;
                formLineItemObject[selectedOptionValue+2].formLineItem.Show_on_Screen__c = false;
                formLineItemObject[selectedOptionValue+2].formLineItem.IsRequired__c = false;
                formLineItemObject[selectedOptionValue+3].formLineItem.Show_on_Screen__c = false;
                formLineItemObject[selectedOptionValue+3].formLineItem.IsRequired__c = false;
                formLineItemObject[selectedOptionValue+4].formLineItem.Show_on_Screen__c = false;
                formLineItemObject[selectedOptionValue+4].formLineItem.IsRequired__c = false;
                formLineItemObject[selectedOptionValue+5].formLineItem.Show_on_Screen__c = false;
                formLineItemObject[selectedOptionValue+5].formLineItem.IsRequired__c = false;
                formLineItemObject[selectedOptionValue+6].formLineItem.Show_on_Screen__c = false;
                formLineItemObject[selectedOptionValue+6].formLineItem.IsRequired__c = false;
                formLineItemObject[selectedOptionValue+7].formLineItem.Show_on_Screen__c = false;
                formLineItemObject[selectedOptionValue+7].formLineItem.IsRequired__c = false;
            }
        }else if(currentLineItemObj.formLineItem.Question_Text__c == 'Are there specific written policies and/or guidance documents that you would be willing to share with us?'){
            if(selectedOptionVal == 'Yes'){
                formLineItemObject[selectedOptionValue+1].formLineItem.Show_on_Screen__c = true;
                formLineItemObject[selectedOptionValue+1].formLineItem.IsRequired__c = true;
                formLineItemObject[selectedOptionValue+2].formLineItem.Show_on_Screen__c = true;
                formLineItemObject[selectedOptionValue+2].formLineItem.IsRequired__c = true;
            }else{
                formLineItemObject[selectedOptionValue+1].formLineItem.Show_on_Screen__c = false;
                formLineItemObject[selectedOptionValue+1].formLineItem.IsRequired__c = false;
                formLineItemObject[selectedOptionValue+2].formLineItem.Show_on_Screen__c = false;
                formLineItemObject[selectedOptionValue+2].formLineItem.IsRequired__c = false;
            }
        }
    },
    CSRA590DistributorDependency : function(cmp,formLineItemObject,form,selectedOptionValue,selectedOptionVal,currentLineItemObj){
        if(currentLineItemObj.formLineItem.Question_Text__c == 'Has the distributor ever operated under another name?'){            
            if(selectedOptionVal == 'Yes'){
                formLineItemObject[selectedOptionValue+1].formLineItem.IsRequired__c = true;
                formLineItemObject[selectedOptionValue+1].formLineItem.Show_on_Screen__c = true;
            }else{
                formLineItemObject[selectedOptionValue+1].formLineItem.IsRequired__c = false;
                formLineItemObject[selectedOptionValue+1].formLineItem.Show_on_Screen__c = false;
            }
        }else if(currentLineItemObj.formLineItem.Question_Text__c == 'Will ABC or an ABC subsidiary be this customer\'s primary wholesaler?'){            
            if(selectedOptionVal == 'No'){
                formLineItemObject[selectedOptionValue+1].formLineItem.IsRequired__c = true;
                formLineItemObject[selectedOptionValue+1].formLineItem.Show_on_Screen__c = true;
                formLineItemObject[selectedOptionValue+2].formLineItem.Show_on_Screen__c = true;
            }else{
                formLineItemObject[selectedOptionValue+1].formLineItem.IsRequired__c = false;
                formLineItemObject[selectedOptionValue+1].formLineItem.Show_on_Screen__c = false;
                formLineItemObject[selectedOptionValue+2].formLineItem.Show_on_Screen__c = false;
            }
        }else if(currentLineItemObj.formLineItem.Question_Text__c == 'Do you have a PVA or equivalent with any other wholesaler?'){            
            if(selectedOptionVal == 'Yes'){
                formLineItemObject[selectedOptionValue+1].formLineItem.IsRequired__c = true;
                formLineItemObject[selectedOptionValue+1].formLineItem.Show_on_Screen__c = true;
            }else{
                formLineItemObject[selectedOptionValue+1].formLineItem.IsRequired__c = false;
                formLineItemObject[selectedOptionValue+1].formLineItem.Show_on_Screen__c = false;
            }
        }else if(currentLineItemObj.formLineItem.Question_Text__c == 'Select the reason for CSRA review:'){            
            if(selectedOptionVal == 'New customer - Established business changing supplier(s) to ABC or ABC subsidiary'){
                formLineItemObject[selectedOptionValue+1].formLineItem.IsRequired__c = true;
                formLineItemObject[selectedOptionValue+1].formLineItem.Show_on_Screen__c = true;
                formLineItemObject[selectedOptionValue+2].formLineItem.IsRequired__c = false;
                formLineItemObject[selectedOptionValue+2].formLineItem.Show_on_Screen__c = false;
                formLineItemObject[selectedOptionValue+3].formLineItem.IsRequired__c = false;
                formLineItemObject[selectedOptionValue+3].formLineItem.Show_on_Screen__c = false;
                formLineItemObject[selectedOptionValue+4].formLineItem.IsRequired__c = false;
                formLineItemObject[selectedOptionValue+4].formLineItem.Show_on_Screen__c = false;
            }else if(selectedOptionVal == 'New customer - Established business adding ABC or ABC subsidiary as supplier(s)'){
                formLineItemObject[selectedOptionValue+1].formLineItem.IsRequired__c = false;
                formLineItemObject[selectedOptionValue+1].formLineItem.Show_on_Screen__c = false;
                formLineItemObject[selectedOptionValue+2].formLineItem.IsRequired__c = true;
                formLineItemObject[selectedOptionValue+2].formLineItem.Show_on_Screen__c = true;
                formLineItemObject[selectedOptionValue+3].formLineItem.IsRequired__c = false;
                formLineItemObject[selectedOptionValue+3].formLineItem.Show_on_Screen__c = false;
                formLineItemObject[selectedOptionValue+4].formLineItem.IsRequired__c = false;
                formLineItemObject[selectedOptionValue+4].formLineItem.Show_on_Screen__c = false;
            }else if(selectedOptionVal == 'Existing ABC Customer - Change in ownership'){
                formLineItemObject[selectedOptionValue+1].formLineItem.IsRequired__c = false;
                formLineItemObject[selectedOptionValue+1].formLineItem.Show_on_Screen__c = false;
                formLineItemObject[selectedOptionValue+2].formLineItem.IsRequired__c = false;
                formLineItemObject[selectedOptionValue+2].formLineItem.Show_on_Screen__c = false;
                formLineItemObject[selectedOptionValue+3].formLineItem.IsRequired__c = true;
                formLineItemObject[selectedOptionValue+3].formLineItem.Show_on_Screen__c = true;
                formLineItemObject[selectedOptionValue+4].formLineItem.IsRequired__c = false;
                formLineItemObject[selectedOptionValue+4].formLineItem.Show_on_Screen__c = false;
            }else if(selectedOptionVal == 'Existing ABC Customer - Updated CSRA 590 form'){
                formLineItemObject[selectedOptionValue+1].formLineItem.IsRequired__c = false;
                formLineItemObject[selectedOptionValue+1].formLineItem.Show_on_Screen__c = false;
                formLineItemObject[selectedOptionValue+2].formLineItem.IsRequired__c = false;
                formLineItemObject[selectedOptionValue+2].formLineItem.Show_on_Screen__c = false;
                formLineItemObject[selectedOptionValue+3].formLineItem.IsRequired__c = false;
                formLineItemObject[selectedOptionValue+3].formLineItem.Show_on_Screen__c = false;
                formLineItemObject[selectedOptionValue+4].formLineItem.IsRequired__c = true;
                formLineItemObject[selectedOptionValue+4].formLineItem.Show_on_Screen__c = true;
            }else if(selectedOptionVal == 'New customer - Start-up business'){
                formLineItemObject[selectedOptionValue+1].formLineItem.IsRequired__c = false;
                formLineItemObject[selectedOptionValue+1].formLineItem.Show_on_Screen__c = false;
                formLineItemObject[selectedOptionValue+2].formLineItem.IsRequired__c = false;
                formLineItemObject[selectedOptionValue+2].formLineItem.Show_on_Screen__c = false;
                formLineItemObject[selectedOptionValue+3].formLineItem.IsRequired__c = false;
                formLineItemObject[selectedOptionValue+3].formLineItem.Show_on_Screen__c = false;
                formLineItemObject[selectedOptionValue+4].formLineItem.IsRequired__c = false;
                formLineItemObject[selectedOptionValue+4].formLineItem.Show_on_Screen__c = false;
            }    
        }else if(currentLineItemObj.formLineItem.Question_Text__c == 'Does this distributor export?'){            
            if(selectedOptionVal == 'Yes'){
                formLineItemObject[selectedOptionValue+1].formLineItem.IsRequired__c = true;
                formLineItemObject[selectedOptionValue+1].formLineItem.Show_on_Screen__c = true;
            }else{
                formLineItemObject[selectedOptionValue+1].formLineItem.IsRequired__c = false;
                formLineItemObject[selectedOptionValue+1].formLineItem.Show_on_Screen__c = false;
            }
        }else if(currentLineItemObj.formLineItem.Question_Text__c == 'Are any of the owners a licensed pharmacist or prescribing physician?'){            
            if(selectedOptionVal == 'Yes'){
                formLineItemObject[selectedOptionValue+1].formLineItem.IsRequired__c = true;
                formLineItemObject[selectedOptionValue+1].formLineItem.Show_on_Screen__c = true;
            }else{
                formLineItemObject[selectedOptionValue+1].formLineItem.IsRequired__c = false;
                formLineItemObject[selectedOptionValue+1].formLineItem.Show_on_Screen__c = false;
            }
        }else if(currentLineItemObj.formLineItem.Question_Text__c == 'Are any of the owners associated with or own another distributor?'){            
            if(selectedOptionVal == 'Yes'){
                formLineItemObject[selectedOptionValue+1].formLineItem.IsRequired__c = true;
                formLineItemObject[selectedOptionValue+1].formLineItem.Show_on_Screen__c = true;
            }else{
                formLineItemObject[selectedOptionValue+1].formLineItem.IsRequired__c = false;
                formLineItemObject[selectedOptionValue+1].formLineItem.Show_on_Screen__c = false;
            }
        }else if(currentLineItemObj.formLineItem.Question_Text__c == 'Has the distributor had a DEA registration or state license/registration (including any state where the distributor does business) suspended, revoked or disciplined within the last 10 years?'){            
            if(selectedOptionVal == 'Yes'){
                formLineItemObject[selectedOptionValue+1].formLineItem.IsRequired__c = true;
                formLineItemObject[selectedOptionValue+1].formLineItem.Show_on_Screen__c = true;
            }else{
                formLineItemObject[selectedOptionValue+1].formLineItem.IsRequired__c = false;
                formLineItemObject[selectedOptionValue+1].formLineItem.Show_on_Screen__c = false;
            }
        }else if(currentLineItemObj.formLineItem.Question_Text__c == 'Is this distributor currently part of an active investigation at the federal, state or local level?'){            
            if(selectedOptionVal == 'Yes'){
                formLineItemObject[selectedOptionValue+1].formLineItem.IsRequired__c = true;
                formLineItemObject[selectedOptionValue+1].formLineItem.Show_on_Screen__c = true;
            }else{
                formLineItemObject[selectedOptionValue+1].formLineItem.IsRequired__c = false;
                formLineItemObject[selectedOptionValue+1].formLineItem.Show_on_Screen__c = false;
            }
        }else if(currentLineItemObj.formLineItem.Question_Text__c == 'Has a supplier ever suspended or ceased controlled substance sales to the distributor?'){            
            if(selectedOptionVal == 'Yes'){
                formLineItemObject[selectedOptionValue+1].formLineItem.IsRequired__c = true;
                formLineItemObject[selectedOptionValue+1].formLineItem.Show_on_Screen__c = true;
            }else{
                formLineItemObject[selectedOptionValue+1].formLineItem.IsRequired__c = false;
                formLineItemObject[selectedOptionValue+1].formLineItem.Show_on_Screen__c = false;
            }
        }else if(currentLineItemObj.formLineItem.Question_Text__c == 'Has the owner, family member, or any employee of the distributor had a DEA registration or state license/registration suspended, revoked or disciplined within the last 10 years?'){
            
            if(selectedOptionVal == 'Yes'){
                formLineItemObject[selectedOptionValue+1].formLineItem.IsRequired__c = true;
                formLineItemObject[selectedOptionValue+1].formLineItem.Show_on_Screen__c = true;
            }else{
                formLineItemObject[selectedOptionValue+1].formLineItem.IsRequired__c = false;
                formLineItemObject[selectedOptionValue+1].formLineItem.Show_on_Screen__c = false;
            }
        }else if(currentLineItemObj.formLineItem.Question_Text__c == 'Are other businesses or business activities located at the same location (retail pharmacy, etc.)?'){            
            if(selectedOptionVal == 'Yes'){
                formLineItemObject[selectedOptionValue+1].formLineItem.IsRequired__c = true;
                formLineItemObject[selectedOptionValue+1].formLineItem.Show_on_Screen__c = true;
            }else{
                formLineItemObject[selectedOptionValue+1].formLineItem.IsRequired__c = false;
                formLineItemObject[selectedOptionValue+1].formLineItem.Show_on_Screen__c = false;
            }
        }else if(currentLineItemObj.formLineItem.Question_Text__c == 'Does the distributor service pain management clinics/physicians?'){            
            if(selectedOptionVal == 'Yes'){
                formLineItemObject[selectedOptionValue+1].formLineItem.IsRequired__c = true;
                formLineItemObject[selectedOptionValue+1].formLineItem.Show_on_Screen__c = true;
            }else{
                formLineItemObject[selectedOptionValue+1].formLineItem.IsRequired__c = false;
                formLineItemObject[selectedOptionValue+1].formLineItem.Show_on_Screen__c = false;
            }
        }
    }, 
    //Radio Button Options Dependencies for Health System Location Onboarding Form
    hsLocationOnbDependency: function(cmp, formLineItemObject, form, selectedOptionValue, selectedOptionVal, currentLineItemObj){
        if(currentLineItemObj.formLineItem.Question_Text__c == 'Does your current provider deliver to a single location or multiple locations within your facility?'){
            if(selectedOptionVal == 'Multiple locations'){
                formLineItemObject[selectedOptionValue+1].formLineItem.IsRequired__c = true;
                formLineItemObject[selectedOptionValue+1].formLineItem.Show_on_Screen__c = true;
            }else{
                formLineItemObject[selectedOptionValue+1].formLineItem.IsRequired__c = false;                
                formLineItemObject[selectedOptionValue+1].formLineItem.Show_on_Screen__c = false;
            } 
        }else if(currentLineItemObj.formLineItem.Question_Text__c == 'Are there specific dock doors and/or parking spaces that the delivery driver should use?'){
            if(selectedOptionVal == 'Yes'){
                formLineItemObject[selectedOptionValue+1].formLineItem.IsRequired__c = true;
                formLineItemObject[selectedOptionValue+1].formLineItem.Show_on_Screen__c = true;
            }else{
                formLineItemObject[selectedOptionValue+1].formLineItem.IsRequired__c = false;                
                formLineItemObject[selectedOptionValue+1].formLineItem.Show_on_Screen__c = false;
            }
        }else if(currentLineItemObj.formLineItem.Question_Text__c == 'Are there specific requirements related to security clearance for couriers?'){
            if(selectedOptionVal == 'Yes'){
                formLineItemObject[selectedOptionValue+1].formLineItem.IsRequired__c = true;
                formLineItemObject[selectedOptionValue+1].formLineItem.Show_on_Screen__c = true;
            }else{
                formLineItemObject[selectedOptionValue+1].formLineItem.IsRequired__c = false;                
                formLineItemObject[selectedOptionValue+1].formLineItem.Show_on_Screen__c = false;
            }
        }else if(currentLineItemObj.formLineItem.Question_Text__c == 'Are the shelves in your account currently labeled?'){
            if(selectedOptionVal == 'No'){
                //formLineItemObject[selectedOptionValue+1].formLineItem.IsRequired__c = true;
                formLineItemObject[selectedOptionValue+1].formLineItem.Show_on_Screen__c = true;
                //formLineItemObject[selectedOptionValue+2].formLineItem.IsRequired__c = false;
                formLineItemObject[selectedOptionValue+2].formLineItem.Show_on_Screen__c = false;
                formLineItemObject[selectedOptionValue+2].formLineItem.Response__c = '';
                //formLineItemObject[selectedOptionValue+3].formLineItem.IsRequired__c = false;
                formLineItemObject[selectedOptionValue+3].formLineItem.Show_on_Screen__c = false;
                formLineItemObject[selectedOptionValue+3].formLineItem.Response__c = '';
                //formLineItemObject[selectedOptionValue+4].formLineItem.IsRequired__c = false;
                formLineItemObject[selectedOptionValue+4].formLineItem.Show_on_Screen__c = false;
                formLineItemObject[selectedOptionValue+4].formLineItem.Response__c = '';
                //formLineItemObject[selectedOptionValue+5].formLineItem.IsRequired__c = false;
                formLineItemObject[selectedOptionValue+5].formLineItem.Show_on_Screen__c = false;
                formLineItemObject[selectedOptionValue+5].formLineItem.Response__c = '';
                //formLineItemObject[selectedOptionValue+6].formLineItem.IsRequired__c = false;
                formLineItemObject[selectedOptionValue+6].formLineItem.Show_on_Screen__c = false;
                formLineItemObject[selectedOptionValue+7].formLineItem.Show_on_Screen__c = false;
            }else if(selectedOptionVal == 'Yes'){
                //formLineItemObject[selectedOptionValue+1].formLineItem.IsRequired__c = false;
                formLineItemObject[selectedOptionValue+1].formLineItem.Show_on_Screen__c = false;
                formLineItemObject[selectedOptionValue+1].formLineItem.Response__c = '';
                //formLineItemObject[selectedOptionValue+2].formLineItem.IsRequired__c = true;
                formLineItemObject[selectedOptionValue+2].formLineItem.Show_on_Screen__c = true;
                //formLineItemObject[selectedOptionValue+3].formLineItem.IsRequired__c = true;
                formLineItemObject[selectedOptionValue+3].formLineItem.Show_on_Screen__c = true;
                //formLineItemObject[selectedOptionValue+4].formLineItem.IsRequired__c = true;
                formLineItemObject[selectedOptionValue+4].formLineItem.Show_on_Screen__c = true;
                //formLineItemObject[selectedOptionValue+5].formLineItem.IsRequired__c = true;
                formLineItemObject[selectedOptionValue+5].formLineItem.Show_on_Screen__c = true;
                //formLineItemObject[selectedOptionValue+6].formLineItem.IsRequired__c = true;
                formLineItemObject[selectedOptionValue+6].formLineItem.Show_on_Screen__c = true;
                formLineItemObject[selectedOptionValue+7].formLineItem.Show_on_Screen__c = true;
            }
        }else if(currentLineItemObj.formLineItem.Question_Text__c == 'Are you interested in utilizing AmerisourceBergen labeling?'){
            if(selectedOptionVal == 'No'){
                //formLineItemObject[selectedOptionValue+1].formLineItem.IsRequired__c = false;
                formLineItemObject[selectedOptionValue+1].formLineItem.Show_on_Screen__c = false;
                formLineItemObject[selectedOptionValue+1].formLineItem.Response__c = '';
                //formLineItemObject[selectedOptionValue+2].formLineItem.IsRequired__c = false;
                formLineItemObject[selectedOptionValue+2].formLineItem.Show_on_Screen__c = false;
                formLineItemObject[selectedOptionValue+2].formLineItem.Response__c = '';
                //formLineItemObject[selectedOptionValue+3].formLineItem.IsRequired__c = false;
                formLineItemObject[selectedOptionValue+3].formLineItem.Show_on_Screen__c = false;
                formLineItemObject[selectedOptionValue+3].formLineItem.Response__c = '';
                //formLineItemObject[selectedOptionValue+4].formLineItem.IsRequired__c = false;
                formLineItemObject[selectedOptionValue+4].formLineItem.Show_on_Screen__c = false;
                formLineItemObject[selectedOptionValue+4].formLineItem.Response__c = '';
                //formLineItemObject[selectedOptionValue+5].formLineItem.IsRequired__c = false;
                formLineItemObject[selectedOptionValue+5].formLineItem.Show_on_Screen__c = false;
                formLineItemObject[selectedOptionValue+6].formLineItem.Show_on_Screen__c = false;
            }else if(selectedOptionVal == 'Yes'){
                //formLineItemObject[selectedOptionValue+1].formLineItem.IsRequired__c = true;
                formLineItemObject[selectedOptionValue+1].formLineItem.Show_on_Screen__c = true;
                //formLineItemObject[selectedOptionValue+2].formLineItem.IsRequired__c = true;
                formLineItemObject[selectedOptionValue+2].formLineItem.Show_on_Screen__c = true;
                //formLineItemObject[selectedOptionValue+3].formLineItem.IsRequired__c = true;
                formLineItemObject[selectedOptionValue+3].formLineItem.Show_on_Screen__c = true;
                //formLineItemObject[selectedOptionValue+4].formLineItem.IsRequired__c = true;
                formLineItemObject[selectedOptionValue+4].formLineItem.Show_on_Screen__c = true;
                //formLineItemObject[selectedOptionValue+5].formLineItem.IsRequired__c = true;
                formLineItemObject[selectedOptionValue+5].formLineItem.Show_on_Screen__c = true;
                formLineItemObject[selectedOptionValue+6].formLineItem.Show_on_Screen__c = true;
            }
        }else if(currentLineItemObj.formLineItem.Question_Text__c == 'Are Handheld Devices used for ordering?'){
            if(selectedOptionVal == 'No'){
                formLineItemObject[selectedOptionValue+1].formLineItem.Show_on_Screen__c = false;
                formLineItemObject[selectedOptionValue+1].formLineItem.Response__c = '';
                formLineItemObject[selectedOptionValue+2].formLineItem.Show_on_Screen__c = false;
                formLineItemObject[selectedOptionValue+2].formLineItem.Response__c = '';
                formLineItemObject[selectedOptionValue+3].formLineItem.IsRequired__c = false;
                formLineItemObject[selectedOptionValue+3].formLineItem.Show_on_Screen__c = false;
                formLineItemObject[selectedOptionValue+3].formLineItem.Response__c = '';
            }else if(selectedOptionVal == 'Yes'){
                formLineItemObject[selectedOptionValue+1].formLineItem.Show_on_Screen__c = true;
                formLineItemObject[selectedOptionValue+2].formLineItem.Show_on_Screen__c = true;
                formLineItemObject[selectedOptionValue+3].formLineItem.IsRequired__c = true;
                formLineItemObject[selectedOptionValue+3].formLineItem.Show_on_Screen__c = true;
            }
        }else if(currentLineItemObj.formLineItem.Question_Text__c == 'Please indicate which of the following Vendor/Product combinations are being used for EDI across the portfolio:'){
            if(selectedOptionVal == 'Other'){                
                formLineItemObject[selectedOptionValue+1].formLineItem.IsRequired__c = true;
                formLineItemObject[selectedOptionValue+1].formLineItem.Show_on_Screen__c = true;
                
            }else{                
                formLineItemObject[selectedOptionValue+1].formLineItem.IsRequired__c = false;
                formLineItemObject[selectedOptionValue+1].formLineItem.Show_on_Screen__c = false;
                formLineItemObject[selectedOptionValue+1].formLineItem.Response__c = '';
            }
        }else if(currentLineItemObj.formLineItem.Question_Text__c == 'Does your location use CSOS?'){
            if(selectedOptionVal == 'Yes'){
                formLineItemObject[selectedOptionValue+1].formLineItem.Show_on_Screen__c = true;
                formLineItemObject[selectedOptionValue+2].formLineItem.Show_on_Screen__c = true;
                formLineItemObject[selectedOptionValue+3].formLineItem.Show_on_Screen__c = true;
            }else{
                formLineItemObject[selectedOptionValue+1].formLineItem.Show_on_Screen__c = false;
                formLineItemObject[selectedOptionValue+1].formLineItem.Response__c = '';
                formLineItemObject[selectedOptionValue+2].formLineItem.Show_on_Screen__c = false;
                formLineItemObject[selectedOptionValue+2].formLineItem.Response__c = '';
                formLineItemObject[selectedOptionValue+3].formLineItem.Show_on_Screen__c = false;
                formLineItemObject[selectedOptionValue+3].formLineItem.Response__c = '';
            }
        }else if(currentLineItemObj.formLineItem.Question_Text__c == 'Would you like to receive your DSCSA regulatory data (Transaction Information, Transaction History, & Transaction Statement) via 3rd Party vendor?'){
            if(selectedOptionVal == 'Yes'){
                formLineItemObject[selectedOptionValue+1].formLineItem.Show_on_Screen__c = true;
                formLineItemObject[selectedOptionValue+2].formLineItem.Show_on_Screen__c = true;
                formLineItemObject[selectedOptionValue+3].formLineItem.Show_on_Screen__c = true;
                formLineItemObject[selectedOptionValue+4].formLineItem.Show_on_Screen__c = true;
            }else{
                formLineItemObject[selectedOptionValue+1].formLineItem.Show_on_Screen__c = false;
                formLineItemObject[selectedOptionValue+1].formLineItem.Response__c = '';
                formLineItemObject[selectedOptionValue+2].formLineItem.Show_on_Screen__c = false;
                formLineItemObject[selectedOptionValue+2].formLineItem.Response__c = '';
                formLineItemObject[selectedOptionValue+3].formLineItem.Show_on_Screen__c = false;
                formLineItemObject[selectedOptionValue+3].formLineItem.Response__c = '';
                formLineItemObject[selectedOptionValue+4].formLineItem.Show_on_Screen__c = false;
                formLineItemObject[selectedOptionValue+4].formLineItem.Response__c = '';
            }
        }
    },
    //Radio Button Options Dependencies for New Portfolio Form
    newPortfolioDependency: function(cmp, formLineItemObject, form, selectedOptionValue, selectedOptionVal, currentLineItemObj){
        if(currentLineItemObj.formLineItem.Question_Text__c == 'Are all of the locations within your portfolio tax exempt?'){
            if(selectedOptionVal == 'Yes'){
                formLineItemObject[selectedOptionValue+1].formLineItem.IsRequired__c = true;
                formLineItemObject[selectedOptionValue+1].formLineItem.Show_on_Screen__c = true;
            }else{
                formLineItemObject[selectedOptionValue+1].formLineItem.IsRequired__c = false;                
                formLineItemObject[selectedOptionValue+1].formLineItem.Show_on_Screen__c = false;
            } 
        }else if(currentLineItemObj.formLineItem.Question_Text__c == 'Will all locations in the portfolio use the same ordering workflow?'){
            if(selectedOptionVal == 'Yes'){
                formLineItemObject[selectedOptionValue+1].formLineItem.IsRequired__c = true;                
                formLineItemObject[selectedOptionValue+1].formLineItem.Show_on_Screen__c = true;
            }else{
                formLineItemObject[selectedOptionValue+1].formLineItem.IsRequired__c = false;                
                formLineItemObject[selectedOptionValue+1].formLineItem.Show_on_Screen__c = false;
            } 
        }else if(currentLineItemObj.formLineItem.Question_Text__c == 'Does your organization use a standard formulary/ordering templates for all the accounts in your portfolio?'){
            if(selectedOptionVal == 'Yes'){
                formLineItemObject[selectedOptionValue+1].formLineItem.Show_on_Screen__c = true;
            }else{
                formLineItemObject[selectedOptionValue+1].formLineItem.Show_on_Screen__c = false;
            } 
        }else if(currentLineItemObj.formLineItem.Question_Text__c == 'Do you use Electronic Interdepartmental Billing today with your current Wholesaler?'){
            if(selectedOptionVal == 'Yes - all accounts use same Dept #'){
                formLineItemObject[selectedOptionValue+1].formLineItem.IsRequired__c = true;                
                formLineItemObject[selectedOptionValue+1].formLineItem.Show_on_Screen__c = true;
            }else{
                formLineItemObject[selectedOptionValue+1].formLineItem.IsRequired__c = false;                
                formLineItemObject[selectedOptionValue+1].formLineItem.Show_on_Screen__c = false;
            } 
            if(selectedOptionVal == 'Yes - but all locations manage IDB differently'){
                formLineItemObject[selectedOptionValue+1].formLineItem.IsRequired__c = true;                
                formLineItemObject[selectedOptionValue+2].formLineItem.Show_on_Screen__c = true;
            }else{
                formLineItemObject[selectedOptionValue+1].formLineItem.IsRequired__c = false;                
                formLineItemObject[selectedOptionValue+2].formLineItem.Show_on_Screen__c = false;
            } 
        }else if(currentLineItemObj.formLineItem.Question_Text__c == 'Would you like to leverage the Interdepartmental Billing program through ABC?'){
            if(selectedOptionVal == 'Yes for all locations' || selectedOptionVal == 'Yes for some locations'){
                formLineItemObject[selectedOptionValue+1].formLineItem.IsRequired__c = true;
                formLineItemObject[selectedOptionValue+1].formLineItem.Show_on_Screen__c = true;
                formLineItemObject[selectedOptionValue+2].formLineItem.Show_on_Screen__c = true;
            }else{
                formLineItemObject[selectedOptionValue+1].formLineItem.IsRequired__c = false;
                formLineItemObject[selectedOptionValue+1].formLineItem.Show_on_Screen__c = false;
                formLineItemObject[selectedOptionValue+2].formLineItem.Show_on_Screen__c = false;            
            } 
        }else if(currentLineItemObj.formLineItem.Question_Text__c == 'Do you have a centralized AP Contact for your organization?'){
            if(selectedOptionVal == 'Yes'){
                formLineItemObject[selectedOptionValue+1].formLineItem.IsRequired__c = true;
                formLineItemObject[selectedOptionValue+1].formLineItem.Show_on_Screen__c = true;
                formLineItemObject[selectedOptionValue+2].formLineItem.Show_on_Screen__c = true;
            }else{
                formLineItemObject[selectedOptionValue+1].formLineItem.IsRequired__c = false;
                formLineItemObject[selectedOptionValue+1].formLineItem.Show_on_Screen__c = false;
                formLineItemObject[selectedOptionValue+2].formLineItem.Show_on_Screen__c = false;            
            } 
        }else if(currentLineItemObj.formLineItem.Question_Text__c == 'Do you require ABC to complete any Vendor Registration documents?'){
            if(selectedOptionVal == 'Yes'){
                formLineItemObject[selectedOptionValue+1].formLineItem.Show_on_Screen__c = true;
            }else{
                formLineItemObject[selectedOptionValue+1].formLineItem.Show_on_Screen__c = false;
            } 
        }else if(currentLineItemObj.formLineItem.Question_Text__c == 'Should all invoices across your organization utilize the same format?'){
            if(selectedOptionVal == 'Yes'){
                formLineItemObject[selectedOptionValue+1].formLineItem.Show_on_Screen__c = true;
                formLineItemObject[selectedOptionValue+2].formLineItem.Show_on_Screen__c = true;
                formLineItemObject[selectedOptionValue+3].formLineItem.IsRequired__c = true;
                formLineItemObject[selectedOptionValue+3].formLineItem.Show_on_Screen__c = true;
            }else{
                formLineItemObject[selectedOptionValue+1].formLineItem.Show_on_Screen__c = false;
                formLineItemObject[selectedOptionValue+2].formLineItem.Show_on_Screen__c = false;                
                formLineItemObject[selectedOptionValue+3].formLineItem.IsRequired__c = false;
                formLineItemObject[selectedOptionValue+3].formLineItem.Show_on_Screen__c = false;
            } 
        }else if(currentLineItemObj.formLineItem.Question_Text__c == 'Does your organization utilize General Ledger (GL) Codes?'){
            if(selectedOptionVal == 'Yes'){
                formLineItemObject[selectedOptionValue+1].formLineItem.IsRequired__c = true;
                formLineItemObject[selectedOptionValue+1].formLineItem.Show_on_Screen__c = true;
            }else{
                formLineItemObject[selectedOptionValue+1].formLineItem.IsRequired__c = false;
                formLineItemObject[selectedOptionValue+1].formLineItem.Show_on_Screen__c = false;
            } 
        }else if(currentLineItemObj.formLineItem.Question_Text__c == 'Do all of your locations use the same Physical Inventory Process?'){
            if(selectedOptionVal == 'Yes'){
                formLineItemObject[selectedOptionValue+1].formLineItem.IsRequired__c = true;
                formLineItemObject[selectedOptionValue+1].formLineItem.Show_on_Screen__c = true;
                formLineItemObject[selectedOptionValue+2].formLineItem.IsRequired__c = true;
                formLineItemObject[selectedOptionValue+2].formLineItem.Show_on_Screen__c = true;
                formLineItemObject[selectedOptionValue+3].formLineItem.Show_on_Screen__c = true;
            }else{
                formLineItemObject[selectedOptionValue+1].formLineItem.IsRequired__c = false;
                formLineItemObject[selectedOptionValue+1].formLineItem.Show_on_Screen__c = false;
                formLineItemObject[selectedOptionValue+2].formLineItem.IsRequired__c = false;
                formLineItemObject[selectedOptionValue+2].formLineItem.Show_on_Screen__c = false;                
                formLineItemObject[selectedOptionValue+3].formLineItem.Show_on_Screen__c = false;
            }
            if(selectedOptionVal == 'No'){
                formLineItemObject[selectedOptionValue+4].formLineItem.IsRequired__c = true;
                formLineItemObject[selectedOptionValue+4].formLineItem.Show_on_Screen__c = true;
            }else{
                formLineItemObject[selectedOptionValue+4].formLineItem.IsRequired__c = false;
                formLineItemObject[selectedOptionValue+4].formLineItem.Show_on_Screen__c = false;
            }
        }else if(currentLineItemObj.formLineItem.Question_Text__c == 'Do all locations within the portfolio follow the same process for receiving?'){
            if(selectedOptionVal == 'Yes'){
                formLineItemObject[selectedOptionValue+1].formLineItem.IsRequired__c = true;
                formLineItemObject[selectedOptionValue+1].formLineItem.Show_on_Screen__c = true;
                formLineItemObject[selectedOptionValue+2].formLineItem.IsRequired__c = true;
                formLineItemObject[selectedOptionValue+2].formLineItem.Show_on_Screen__c = true;
                formLineItemObject[selectedOptionValue+3].formLineItem.IsRequired__c = true;
                formLineItemObject[selectedOptionValue+3].formLineItem.Show_on_Screen__c = true;
                formLineItemObject[selectedOptionValue+4].formLineItem.IsRequired__c = true;
                formLineItemObject[selectedOptionValue+4].formLineItem.Show_on_Screen__c = true;
            }else{
                formLineItemObject[selectedOptionValue+1].formLineItem.IsRequired__c = false;
                formLineItemObject[selectedOptionValue+1].formLineItem.Show_on_Screen__c = false;
                formLineItemObject[selectedOptionValue+2].formLineItem.IsRequired__c = false;
                formLineItemObject[selectedOptionValue+2].formLineItem.Show_on_Screen__c = false;                
                formLineItemObject[selectedOptionValue+3].formLineItem.IsRequired__c = false;
                formLineItemObject[selectedOptionValue+3].formLineItem.Show_on_Screen__c = false;
                formLineItemObject[selectedOptionValue+4].formLineItem.IsRequired__c = false;
                formLineItemObject[selectedOptionValue+4].formLineItem.Show_on_Screen__c = false;
            }
        }else if(currentLineItemObj.formLineItem.Question_Text__c == 'Do you require any additional reports beyond what is outlined in the link above?'){
            if(selectedOptionVal == 'Yes'){
                formLineItemObject[selectedOptionValue+1].formLineItem.IsRequired__c = true;
                formLineItemObject[selectedOptionValue+1].formLineItem.Show_on_Screen__c = true;
                formLineItemObject[selectedOptionValue+2].formLineItem.IsRequired__c = true;
                formLineItemObject[selectedOptionValue+2].formLineItem.Show_on_Screen__c = true;
                formLineItemObject[selectedOptionValue+3].formLineItem.IsRequired__c = true;
                formLineItemObject[selectedOptionValue+3].formLineItem.Show_on_Screen__c = true;
            }else{
                formLineItemObject[selectedOptionValue+1].formLineItem.IsRequired__c = false;
                formLineItemObject[selectedOptionValue+1].formLineItem.Show_on_Screen__c = false;
                formLineItemObject[selectedOptionValue+2].formLineItem.IsRequired__c = false;
                formLineItemObject[selectedOptionValue+2].formLineItem.Show_on_Screen__c = false;                
                formLineItemObject[selectedOptionValue+3].formLineItem.IsRequired__c = false;
                formLineItemObject[selectedOptionValue+3].formLineItem.Show_on_Screen__c = false;
            }
        }else if(currentLineItemObj.formLineItem.Question_Text__c == 'Are your locations managed by a centralized IT Team(s)?'){
            if(selectedOptionVal == 'Yes'){
                formLineItemObject[selectedOptionValue+1].formLineItem.IsRequired__c = true;
                formLineItemObject[selectedOptionValue+1].formLineItem.Show_on_Screen__c = true;
                formLineItemObject[selectedOptionValue+2].formLineItem.IsRequired__c = true;
                formLineItemObject[selectedOptionValue+2].formLineItem.Show_on_Screen__c = true;
            }else{
                formLineItemObject[selectedOptionValue+1].formLineItem.IsRequired__c = false;
                formLineItemObject[selectedOptionValue+1].formLineItem.Show_on_Screen__c = false;
                formLineItemObject[selectedOptionValue+2].formLineItem.IsRequired__c = false;
                formLineItemObject[selectedOptionValue+2].formLineItem.Show_on_Screen__c = false;                
            }
        }else if(currentLineItemObj.formLineItem.Question_Text__c == 'Does your Corporate Security Team require any IT Security Assessment to be completed for new Vendors?'){
            if(selectedOptionVal == 'No'){
                formLineItemObject[selectedOptionValue+1].formLineItem.Show_on_Screen__c = true;
            }else{
                formLineItemObject[selectedOptionValue+1].formLineItem.Show_on_Screen__c = false;
            }
        }else if(currentLineItemObj.formLineItem.Question_Text__c == 'Please indicate which of the following Vendor / Product combinations are being used for EDI across the portfolio:'){
            if(selectedOptionVal == 'Other'){
                formLineItemObject[selectedOptionValue+1].formLineItem.IsRequired__c = true;
                formLineItemObject[selectedOptionValue+1].formLineItem.Show_on_Screen__c = true;
                formLineItemObject[selectedOptionValue+2].formLineItem.IsRequired__c = true;
                formLineItemObject[selectedOptionValue+2].formLineItem.Show_on_Screen__c = true;
                formLineItemObject[selectedOptionValue+3].formLineItem.IsRequired__c = true;
                formLineItemObject[selectedOptionValue+3].formLineItem.Show_on_Screen__c = true;
                formLineItemObject[selectedOptionValue+4].formLineItem.IsRequired__c = true;
                formLineItemObject[selectedOptionValue+4].formLineItem.Show_on_Screen__c = true;
            }else{
                formLineItemObject[selectedOptionValue+1].formLineItem.IsRequired__c = false;
                formLineItemObject[selectedOptionValue+1].formLineItem.Show_on_Screen__c = false;
                formLineItemObject[selectedOptionValue+2].formLineItem.IsRequired__c = false;
                formLineItemObject[selectedOptionValue+2].formLineItem.Show_on_Screen__c = false;                
                formLineItemObject[selectedOptionValue+3].formLineItem.IsRequired__c = false;
                formLineItemObject[selectedOptionValue+3].formLineItem.Show_on_Screen__c = false;
                formLineItemObject[selectedOptionValue+4].formLineItem.IsRequired__c = false;
                formLineItemObject[selectedOptionValue+4].formLineItem.Show_on_Screen__c = false;
            }
        }else if(currentLineItemObj.formLineItem.Question_Text__c == 'Do you utilize a third party system for your DSCSA Reporting?'){
            if(selectedOptionVal == 'Yes'){
                formLineItemObject[selectedOptionValue+1].formLineItem.IsRequired__c = true;
                formLineItemObject[selectedOptionValue+1].formLineItem.Show_on_Screen__c = true;
                formLineItemObject[selectedOptionValue+2].formLineItem.IsRequired__c = true;
                formLineItemObject[selectedOptionValue+2].formLineItem.Show_on_Screen__c = true;
                formLineItemObject[selectedOptionValue+3].formLineItem.IsRequired__c = true;
                formLineItemObject[selectedOptionValue+3].formLineItem.Show_on_Screen__c = true;
                formLineItemObject[selectedOptionValue+4].formLineItem.Show_on_Screen__c = true;
            }else{
                formLineItemObject[selectedOptionValue+1].formLineItem.IsRequired__c = false;
                formLineItemObject[selectedOptionValue+1].formLineItem.Show_on_Screen__c = false;
                formLineItemObject[selectedOptionValue+2].formLineItem.IsRequired__c = false;
                formLineItemObject[selectedOptionValue+2].formLineItem.Show_on_Screen__c = false;                
                formLineItemObject[selectedOptionValue+3].formLineItem.IsRequired__c = false;
                formLineItemObject[selectedOptionValue+3].formLineItem.Show_on_Screen__c = false;
                formLineItemObject[selectedOptionValue+4].formLineItem.Show_on_Screen__c = false;
            }
        }else if(currentLineItemObj.formLineItem.Question_Text__c == 'Do you require ABC to provide a W9?'){
            if(selectedOptionVal == 'Yes'){
                formLineItemObject[selectedOptionValue+1].formLineItem.Show_on_Screen__c = true;
                formLineItemObject[selectedOptionValue+2].formLineItem.Show_on_Screen__c = true;                
            }else{
                formLineItemObject[selectedOptionValue+1].formLineItem.Show_on_Screen__c = false;
                formLineItemObject[selectedOptionValue+2].formLineItem.Show_on_Screen__c = false;                
            }
        }
    },
    CSRA590HospitalDependency : function(cmp,formLineItemObject,form,selectedOptionValue,selectedOptionVal,currentLineItemObj){
        if(currentLineItemObj.formLineItem.Question_Text__c == 'Will ABC or an ABC subsidiary be this customer\'s primary wholesaler?'){            
            if(selectedOptionVal == 'No'){
                formLineItemObject[selectedOptionValue+1].formLineItem.IsRequired__c = true;
                formLineItemObject[selectedOptionValue+1].formLineItem.Show_on_Screen__c = true;
                formLineItemObject[selectedOptionValue+2].formLineItem.IsRequired__c = true;
                formLineItemObject[selectedOptionValue+2].formLineItem.Show_on_Screen__c = true;
            }else{
                formLineItemObject[selectedOptionValue+1].formLineItem.IsRequired__c = false;
                formLineItemObject[selectedOptionValue+1].formLineItem.Show_on_Screen__c = false;
                formLineItemObject[selectedOptionValue+2].formLineItem.IsRequired__c = false;
                formLineItemObject[selectedOptionValue+2].formLineItem.Show_on_Screen__c = false;
            }
        }else if(currentLineItemObj.formLineItem.Question_Text__c == 'Is there a PVA or equivalent with any other wholesaler?'){            
            if(selectedOptionVal == 'Yes'){
                formLineItemObject[selectedOptionValue+1].formLineItem.IsRequired__c = true;
                formLineItemObject[selectedOptionValue+1].formLineItem.Show_on_Screen__c = true;
            }else{
                formLineItemObject[selectedOptionValue+1].formLineItem.IsRequired__c = false;
                formLineItemObject[selectedOptionValue+1].formLineItem.Show_on_Screen__c = false; 
            }
        }else if(currentLineItemObj.formLineItem.Question_Text__c == 'Select the reason for CSRA review:'){            
            if(selectedOptionVal == 'New customer - Established business changing supplier(s) to ABC or ABC subsidiary'){
                formLineItemObject[selectedOptionValue+1].formLineItem.IsRequired__c = true;
                formLineItemObject[selectedOptionValue+1].formLineItem.Show_on_Screen__c = true;
                formLineItemObject[selectedOptionValue+2].formLineItem.IsRequired__c = false;
                formLineItemObject[selectedOptionValue+2].formLineItem.Show_on_Screen__c = false;
                formLineItemObject[selectedOptionValue+3].formLineItem.IsRequired__c = false;
                formLineItemObject[selectedOptionValue+3].formLineItem.Show_on_Screen__c = false;
                formLineItemObject[selectedOptionValue+4].formLineItem.IsRequired__c = false;
                formLineItemObject[selectedOptionValue+4].formLineItem.Show_on_Screen__c = false;
                formLineItemObject[selectedOptionValue+5].formLineItem.IsRequired__c = false;
                formLineItemObject[selectedOptionValue+5].formLineItem.Show_on_Screen__c = false;
            }else if(selectedOptionVal == 'New customer - Established business adding ABC or ABC subsidiary as supplier(s)'){
                formLineItemObject[selectedOptionValue+1].formLineItem.IsRequired__c = false;
                formLineItemObject[selectedOptionValue+1].formLineItem.Show_on_Screen__c = false;
                formLineItemObject[selectedOptionValue+2].formLineItem.IsRequired__c = true;
                formLineItemObject[selectedOptionValue+2].formLineItem.Show_on_Screen__c = true;
                formLineItemObject[selectedOptionValue+3].formLineItem.IsRequired__c = false;
                formLineItemObject[selectedOptionValue+3].formLineItem.Show_on_Screen__c = false;
                formLineItemObject[selectedOptionValue+4].formLineItem.IsRequired__c = false;
                formLineItemObject[selectedOptionValue+4].formLineItem.Show_on_Screen__c = false;
                formLineItemObject[selectedOptionValue+5].formLineItem.IsRequired__c = false;
                formLineItemObject[selectedOptionValue+5].formLineItem.Show_on_Screen__c = false;
            }else if(selectedOptionVal == 'New customer - Start-up business'){
                formLineItemObject[selectedOptionValue+1].formLineItem.IsRequired__c = false;
                formLineItemObject[selectedOptionValue+1].formLineItem.Show_on_Screen__c = false;
                formLineItemObject[selectedOptionValue+2].formLineItem.IsRequired__c = false;
                formLineItemObject[selectedOptionValue+2].formLineItem.Show_on_Screen__c = false;
                formLineItemObject[selectedOptionValue+3].formLineItem.IsRequired__c = false;
                formLineItemObject[selectedOptionValue+3].formLineItem.Show_on_Screen__c = false;
                formLineItemObject[selectedOptionValue+4].formLineItem.IsRequired__c = false;
                formLineItemObject[selectedOptionValue+4].formLineItem.Show_on_Screen__c = false;
                formLineItemObject[selectedOptionValue+5].formLineItem.IsRequired__c = false;
                formLineItemObject[selectedOptionValue+5].formLineItem.Show_on_Screen__c = false;
            }else if(selectedOptionVal == 'Existing ABC Customer - Change in ownership'){
                formLineItemObject[selectedOptionValue+1].formLineItem.IsRequired__c = false;
                formLineItemObject[selectedOptionValue+1].formLineItem.Show_on_Screen__c = false;
                formLineItemObject[selectedOptionValue+2].formLineItem.IsRequired__c = false;
                formLineItemObject[selectedOptionValue+2].formLineItem.Show_on_Screen__c = false;
                formLineItemObject[selectedOptionValue+3].formLineItem.IsRequired__c = true;
                formLineItemObject[selectedOptionValue+3].formLineItem.Show_on_Screen__c = true;
                formLineItemObject[selectedOptionValue+4].formLineItem.IsRequired__c = false;
                formLineItemObject[selectedOptionValue+4].formLineItem.Show_on_Screen__c = false;
                formLineItemObject[selectedOptionValue+5].formLineItem.IsRequired__c = false;
                formLineItemObject[selectedOptionValue+5].formLineItem.Show_on_Screen__c = false;
            }else if(selectedOptionVal == 'Existing ABC Customer - Additional account'){
                formLineItemObject[selectedOptionValue+1].formLineItem.IsRequired__c = false;
                formLineItemObject[selectedOptionValue+1].formLineItem.Show_on_Screen__c = false;
                formLineItemObject[selectedOptionValue+2].formLineItem.IsRequired__c = false;
                formLineItemObject[selectedOptionValue+2].formLineItem.Show_on_Screen__c = false;
                formLineItemObject[selectedOptionValue+3].formLineItem.IsRequired__c = false;
                formLineItemObject[selectedOptionValue+3].formLineItem.Show_on_Screen__c = false;
                formLineItemObject[selectedOptionValue+4].formLineItem.IsRequired__c = true;
                formLineItemObject[selectedOptionValue+4].formLineItem.Show_on_Screen__c = true;
                formLineItemObject[selectedOptionValue+5].formLineItem.IsRequired__c = false;
                formLineItemObject[selectedOptionValue+5].formLineItem.Show_on_Screen__c = false;
            }else if(selectedOptionVal == 'Existing ABC Customer - Updated CSRA 590 form'){
                formLineItemObject[selectedOptionValue+1].formLineItem.IsRequired__c = false;
                formLineItemObject[selectedOptionValue+1].formLineItem.Show_on_Screen__c = false;
                formLineItemObject[selectedOptionValue+2].formLineItem.IsRequired__c = false;
                formLineItemObject[selectedOptionValue+2].formLineItem.Show_on_Screen__c = false;
                formLineItemObject[selectedOptionValue+3].formLineItem.IsRequired__c = false;
                formLineItemObject[selectedOptionValue+3].formLineItem.Show_on_Screen__c = false;
                formLineItemObject[selectedOptionValue+4].formLineItem.IsRequired__c = false;
                formLineItemObject[selectedOptionValue+4].formLineItem.Show_on_Screen__c = false;
                formLineItemObject[selectedOptionValue+5].formLineItem.IsRequired__c = true;
                formLineItemObject[selectedOptionValue+5].formLineItem.Show_on_Screen__c = true;
            }
        }else if(currentLineItemObj.formLineItem.Question_Text__c == 'Please check all that apply to your business activity'){            
            if(selectedOptionVal == 'Other'){
                formLineItemObject[selectedOptionValue+1].formLineItem.IsRequired__c = true;
                formLineItemObject[selectedOptionValue+1].formLineItem.Show_on_Screen__c = true;
            }else{
                formLineItemObject[selectedOptionValue+1].formLineItem.IsRequired__c = false;
                formLineItemObject[selectedOptionValue+1].formLineItem.Show_on_Screen__c = false; 
            }
        }else if(currentLineItemObj.formLineItem.Question_Text__c == 'Has a supplier ever suspended, reduced, or ceased controlled substance to the pharmacy?'){            
            if(selectedOptionVal == 'Yes'){
                formLineItemObject[selectedOptionValue+1].formLineItem.IsRequired__c = true;
                formLineItemObject[selectedOptionValue+1].formLineItem.Show_on_Screen__c = true;
            }else{
                formLineItemObject[selectedOptionValue+1].formLineItem.IsRequired__c = false;
                formLineItemObject[selectedOptionValue+1].formLineItem.Show_on_Screen__c = false; 
            }
        }else if(currentLineItemObj.formLineItem.Question_Text__c == 'Is this hospital pharmacy currently part of an active investigation at the Federal, State or Local Level?'){            
            if(selectedOptionVal == 'Yes'){
                formLineItemObject[selectedOptionValue+1].formLineItem.IsRequired__c = true;
                formLineItemObject[selectedOptionValue+1].formLineItem.Show_on_Screen__c = true;
            }else{
                formLineItemObject[selectedOptionValue+1].formLineItem.IsRequired__c = false;
                formLineItemObject[selectedOptionValue+1].formLineItem.Show_on_Screen__c = false; 
            }
        }else if(currentLineItemObj.formLineItem.Question_Text__c == 'Has the hospital pharmacy had a DEA registration or state license/registration suspended, revoked or disciplined within the last 10 years?'){            
            if(selectedOptionVal == 'Yes'){
                formLineItemObject[selectedOptionValue+1].formLineItem.IsRequired__c = true;
                formLineItemObject[selectedOptionValue+1].formLineItem.Show_on_Screen__c = true;
            }else{
                formLineItemObject[selectedOptionValue+1].formLineItem.IsRequired__c = false;
                formLineItemObject[selectedOptionValue+1].formLineItem.Show_on_Screen__c = false; 
            }
        }else if(currentLineItemObj.formLineItem.Question_Text__c == 'Has any employee of the hospital pharmacy had a state license/registration suspended, revoked or disciplined within the last 10 years?'){            
            if(selectedOptionVal == 'Yes'){
                formLineItemObject[selectedOptionValue+1].formLineItem.IsRequired__c = true;
                formLineItemObject[selectedOptionValue+1].formLineItem.Show_on_Screen__c = true;
            }else{
                formLineItemObject[selectedOptionValue+1].formLineItem.IsRequired__c = false;
                formLineItemObject[selectedOptionValue+1].formLineItem.Show_on_Screen__c = false; 
            }
        }else if(currentLineItemObj.formLineItem.Question_Text__c == 'Are you aware of any disciplinary actions/sanctions taken at any time against any of the above practitioners?'){            
            if(selectedOptionVal == 'Yes'){
                formLineItemObject[selectedOptionValue+1].formLineItem.IsRequired__c = true;
                formLineItemObject[selectedOptionValue+1].formLineItem.Show_on_Screen__c = true;
            }else{
                formLineItemObject[selectedOptionValue+1].formLineItem.IsRequired__c = false;
                formLineItemObject[selectedOptionValue+1].formLineItem.Show_on_Screen__c = false; 
            }
        }                
    },
    CSRA590PractitionerDependency: function(cmp,formLineItemObject,form,selectedOptionValue,selectedOptionVal,currentLineItemObj){
        if(currentLineItemObj.formLineItem.Question_Text__c == 'For mid-level practitioners, do you have a supervising physician?'){
            if(selectedOptionVal == 'Yes'){
                formLineItemObject[selectedOptionValue+1].formLineItem.IsRequired__c = true;
                formLineItemObject[selectedOptionValue+1].formLineItem.Show_on_Screen__c = true;
                formLineItemObject[selectedOptionValue+2].formLineItem.IsRequired__c = true;
                formLineItemObject[selectedOptionValue+2].formLineItem.Show_on_Screen__c = true;
            }else{
                formLineItemObject[selectedOptionValue+1].formLineItem.IsRequired__c = false;
                formLineItemObject[selectedOptionValue+1].formLineItem.Show_on_Screen__c = false;
                formLineItemObject[selectedOptionValue+2].formLineItem.IsRequired__c = false;
                formLineItemObject[selectedOptionValue+2].formLineItem.Show_on_Screen__c = false;
            }
        }else if(currentLineItemObj.formLineItem.Question_Text__c == 'Will ABC or an ABC subsidiary be this customer\'s primary wholesaler?'){
            if(selectedOptionVal == 'No'){
                formLineItemObject[selectedOptionValue+1].formLineItem.IsRequired__c = true;
                formLineItemObject[selectedOptionValue+1].formLineItem.Show_on_Screen__c = true;
                formLineItemObject[selectedOptionValue+2].formLineItem.IsRequired__c = true;
                formLineItemObject[selectedOptionValue+2].formLineItem.Show_on_Screen__c = true;
            }else{
                formLineItemObject[selectedOptionValue+1].formLineItem.IsRequired__c = false;
                formLineItemObject[selectedOptionValue+1].formLineItem.Show_on_Screen__c = false;
                formLineItemObject[selectedOptionValue+1].formLineItem.Response__c = '';
                formLineItemObject[selectedOptionValue+2].formLineItem.IsRequired__c = false;
                formLineItemObject[selectedOptionValue+2].formLineItem.Show_on_Screen__c = false;
                formLineItemObject[selectedOptionValue+2].formLineItem.Response__c = '';
            }
        }else if(currentLineItemObj.formLineItem.Question_Text__c == 'Select the reason for CSRA review:'){
            if(selectedOptionVal == 'New customer - Established business changing supplier(s) to ABC or ABC subsidiary'){
                formLineItemObject[selectedOptionValue+1].formLineItem.IsRequired__c = true;
                formLineItemObject[selectedOptionValue+1].formLineItem.Show_on_Screen__c = true;
                formLineItemObject[selectedOptionValue+2].formLineItem.IsRequired__c = false;
                formLineItemObject[selectedOptionValue+2].formLineItem.Show_on_Screen__c = false;
                formLineItemObject[selectedOptionValue+3].formLineItem.IsRequired__c = false;
                formLineItemObject[selectedOptionValue+3].formLineItem.Show_on_Screen__c = false;
                formLineItemObject[selectedOptionValue+4].formLineItem.IsRequired__c = false;
                formLineItemObject[selectedOptionValue+4].formLineItem.Show_on_Screen__c = false;
                formLineItemObject[selectedOptionValue+5].formLineItem.IsRequired__c = false;
                formLineItemObject[selectedOptionValue+5].formLineItem.Show_on_Screen__c = false;
            }else if(selectedOptionVal == 'New customer - Established business adding ABC or ABC subsidiary as supplier(s)'){
                formLineItemObject[selectedOptionValue+1].formLineItem.IsRequired__c = false;
                formLineItemObject[selectedOptionValue+1].formLineItem.Show_on_Screen__c = false;
                formLineItemObject[selectedOptionValue+2].formLineItem.IsRequired__c = false;
                formLineItemObject[selectedOptionValue+2].formLineItem.Show_on_Screen__c = false;
                formLineItemObject[selectedOptionValue+3].formLineItem.IsRequired__c = true;
                formLineItemObject[selectedOptionValue+3].formLineItem.Show_on_Screen__c = true;
                formLineItemObject[selectedOptionValue+4].formLineItem.IsRequired__c = false;
                formLineItemObject[selectedOptionValue+4].formLineItem.Show_on_Screen__c = false;
                formLineItemObject[selectedOptionValue+5].formLineItem.IsRequired__c = false;
                formLineItemObject[selectedOptionValue+5].formLineItem.Show_on_Screen__c = false;
            }else if(selectedOptionVal == 'New customer - Start-up business'){
                formLineItemObject[selectedOptionValue+1].formLineItem.IsRequired__c = false;
                formLineItemObject[selectedOptionValue+1].formLineItem.Show_on_Screen__c = false;
                formLineItemObject[selectedOptionValue+2].formLineItem.IsRequired__c = false;
                formLineItemObject[selectedOptionValue+2].formLineItem.Show_on_Screen__c = false;
                formLineItemObject[selectedOptionValue+3].formLineItem.IsRequired__c = false;
                formLineItemObject[selectedOptionValue+3].formLineItem.Show_on_Screen__c = false;
                formLineItemObject[selectedOptionValue+4].formLineItem.IsRequired__c = false;
                formLineItemObject[selectedOptionValue+4].formLineItem.Show_on_Screen__c = false;
                formLineItemObject[selectedOptionValue+5].formLineItem.IsRequired__c = false;
                formLineItemObject[selectedOptionValue+5].formLineItem.Show_on_Screen__c = false;
            }else if(selectedOptionVal == 'Existing ABC Customer - Change in practitioner'){
                formLineItemObject[selectedOptionValue+1].formLineItem.IsRequired__c = false;
                formLineItemObject[selectedOptionValue+1].formLineItem.Show_on_Screen__c = false;
                formLineItemObject[selectedOptionValue+2].formLineItem.IsRequired__c = true;
                formLineItemObject[selectedOptionValue+2].formLineItem.Show_on_Screen__c = true;
                formLineItemObject[selectedOptionValue+3].formLineItem.IsRequired__c = false;
                formLineItemObject[selectedOptionValue+3].formLineItem.Show_on_Screen__c = false;
                formLineItemObject[selectedOptionValue+4].formLineItem.IsRequired__c = false;
                formLineItemObject[selectedOptionValue+4].formLineItem.Show_on_Screen__c = false;
                formLineItemObject[selectedOptionValue+5].formLineItem.IsRequired__c = false;
                formLineItemObject[selectedOptionValue+5].formLineItem.Show_on_Screen__c = false;
            }else if(selectedOptionVal == 'Existing ABC Customer - Change in Ownership'){
                formLineItemObject[selectedOptionValue+1].formLineItem.IsRequired__c = false;
                formLineItemObject[selectedOptionValue+1].formLineItem.Show_on_Screen__c = false;
                formLineItemObject[selectedOptionValue+2].formLineItem.IsRequired__c = false;
                formLineItemObject[selectedOptionValue+2].formLineItem.Show_on_Screen__c = false;
                formLineItemObject[selectedOptionValue+3].formLineItem.IsRequired__c = false;
                formLineItemObject[selectedOptionValue+3].formLineItem.Show_on_Screen__c = false;
                formLineItemObject[selectedOptionValue+4].formLineItem.IsRequired__c = true;
                formLineItemObject[selectedOptionValue+4].formLineItem.Show_on_Screen__c = true;
                formLineItemObject[selectedOptionValue+5].formLineItem.IsRequired__c = false;
                formLineItemObject[selectedOptionValue+5].formLineItem.Show_on_Screen__c = false;
            }else if(selectedOptionVal == 'Existing ABC Customer - Updated CSRA 590 form'){
                formLineItemObject[selectedOptionValue+1].formLineItem.IsRequired__c = false;
                formLineItemObject[selectedOptionValue+1].formLineItem.Show_on_Screen__c = false;
                formLineItemObject[selectedOptionValue+2].formLineItem.IsRequired__c = false;
                formLineItemObject[selectedOptionValue+2].formLineItem.Show_on_Screen__c = false;
                formLineItemObject[selectedOptionValue+3].formLineItem.IsRequired__c = false;
                formLineItemObject[selectedOptionValue+3].formLineItem.Show_on_Screen__c = false;
                formLineItemObject[selectedOptionValue+4].formLineItem.IsRequired__c = false;
                formLineItemObject[selectedOptionValue+4].formLineItem.Show_on_Screen__c = false;
                formLineItemObject[selectedOptionValue+5].formLineItem.IsRequired__c = true;
                formLineItemObject[selectedOptionValue+5].formLineItem.Show_on_Screen__c = true;
            }     
        }else if(currentLineItemObj.formLineItem.Question_Text__c == 'Has the practitioner been sanctioned or disciplined within the last 10 years in any state(s) where they are or have been licensed?'){
            if(selectedOptionVal == 'Yes'){
                formLineItemObject[selectedOptionValue+1].formLineItem.IsRequired__c = true;
                formLineItemObject[selectedOptionValue+1].formLineItem.Show_on_Screen__c = true;
            }else{
                formLineItemObject[selectedOptionValue+1].formLineItem.IsRequired__c = false;
                formLineItemObject[selectedOptionValue+1].formLineItem.Show_on_Screen__c = false;
            }
        }else if(currentLineItemObj.formLineItem.Question_Text__c == 'Has the practice had a DEA registration or State license or registration suspended, revoked, or disciplined within the last 10 years?'){
            if(selectedOptionVal == 'Yes'){
                formLineItemObject[selectedOptionValue+1].formLineItem.IsRequired__c = true;
                formLineItemObject[selectedOptionValue+1].formLineItem.Show_on_Screen__c = true;
            }else{
                formLineItemObject[selectedOptionValue+1].formLineItem.IsRequired__c = false;
                formLineItemObject[selectedOptionValue+1].formLineItem.Show_on_Screen__c = false;
            }
        }else if(currentLineItemObj.formLineItem.Question_Text__c == 'Has a supplier ever suspended or ceased controlled substance sales to the entity?'){
            if(selectedOptionVal == 'Yes'){
                formLineItemObject[selectedOptionValue+1].formLineItem.IsRequired__c = true;
                formLineItemObject[selectedOptionValue+1].formLineItem.Show_on_Screen__c = true;
            }else{
                formLineItemObject[selectedOptionValue+1].formLineItem.IsRequired__c = false;
                formLineItemObject[selectedOptionValue+1].formLineItem.Show_on_Screen__c = false;
            }
        }else if(currentLineItemObj.formLineItem.Question_Text__c == 'Has the owner or any employee of the practice had a DEA registration or State license or registration suspended, revoked, or disciplined within the last 10 years?'){
            if(selectedOptionVal == 'Yes'){
                formLineItemObject[selectedOptionValue+1].formLineItem.IsRequired__c = true;
                formLineItemObject[selectedOptionValue+1].formLineItem.Show_on_Screen__c = true;
            }else{
                formLineItemObject[selectedOptionValue+1].formLineItem.IsRequired__c = false;
                formLineItemObject[selectedOptionValue+1].formLineItem.Show_on_Screen__c = false;
            }
        }else if(currentLineItemObj.formLineItem.Question_Text__c == 'Is there a PVA or equivalent with any other wholesaler?'){
            if(selectedOptionVal == 'Yes'){
                formLineItemObject[selectedOptionValue+1].formLineItem.IsRequired__c = true;
                formLineItemObject[selectedOptionValue+1].formLineItem.Show_on_Screen__c = true;
            }else{
                formLineItemObject[selectedOptionValue+1].formLineItem.IsRequired__c = false;
                formLineItemObject[selectedOptionValue+1].formLineItem.Show_on_Screen__c = false;
            }
        }
    },
    CSRA590RetailDependency : function(cmp,formLineItemObject,form,selectedOptionValue,selectedOptionVal,currentLineItemObj){
        if(currentLineItemObj.formLineItem.Question_Text__c == 'Will ABC or an ABC subsidiary be this customer\'s primary wholesaler?'){
            if(selectedOptionVal == 'No'){
                formLineItemObject[selectedOptionValue+1].formLineItem.IsRequired__c = true;
                formLineItemObject[selectedOptionValue+1].formLineItem.Show_on_Screen__c = true;
                formLineItemObject[selectedOptionValue+2].formLineItem.IsRequired__c = true;
                formLineItemObject[selectedOptionValue+2].formLineItem.Show_on_Screen__c = true;
            }else{
                formLineItemObject[selectedOptionValue+1].formLineItem.IsRequired__c = false;
                formLineItemObject[selectedOptionValue+1].formLineItem.Show_on_Screen__c = false;
                formLineItemObject[selectedOptionValue+2].formLineItem.IsRequired__c = false;
                formLineItemObject[selectedOptionValue+2].formLineItem.Show_on_Screen__c = false;
            }
        }else if(currentLineItemObj.formLineItem.Question_Text__c == 'Do you have a Signed Prime Vendor agreement?'){
            if(selectedOptionVal == 'Yes'){
                formLineItemObject[selectedOptionValue+1].formLineItem.IsRequired__c = true;
                formLineItemObject[selectedOptionValue+1].formLineItem.Show_on_Screen__c = true;
            }else{
                formLineItemObject[selectedOptionValue+1].formLineItem.IsRequired__c = false;
                formLineItemObject[selectedOptionValue+1].formLineItem.Show_on_Screen__c = false;
            }
        }else if(currentLineItemObj.formLineItem.Question_Text__c == 'Do you have a PVA or equivalent with any other wholesaler?'){
            if(selectedOptionVal == 'Yes'){
                formLineItemObject[selectedOptionValue+1].formLineItem.IsRequired__c = true;
                formLineItemObject[selectedOptionValue+1].formLineItem.Show_on_Screen__c = true;
            }else{
                formLineItemObject[selectedOptionValue+1].formLineItem.IsRequired__c = false;
                formLineItemObject[selectedOptionValue+1].formLineItem.Show_on_Screen__c = false;
            }
        }else if(currentLineItemObj.formLineItem.Question_Text__c == 'Select the reason for CSRA review:'){
            if(selectedOptionVal == 'New customer - Start-up business'){
                formLineItemObject[selectedOptionValue+1].formLineItem.IsRequired__c = false;
                formLineItemObject[selectedOptionValue+1].formLineItem.Show_on_Screen__c = false;
                formLineItemObject[selectedOptionValue+2].formLineItem.IsRequired__c = false;
                formLineItemObject[selectedOptionValue+2].formLineItem.Show_on_Screen__c = false;
                formLineItemObject[selectedOptionValue+3].formLineItem.IsRequired__c = false;
                formLineItemObject[selectedOptionValue+3].formLineItem.Show_on_Screen__c = false;
                formLineItemObject[selectedOptionValue+4].formLineItem.IsRequired__c = false;
                formLineItemObject[selectedOptionValue+4].formLineItem.Show_on_Screen__c = false;
                formLineItemObject[selectedOptionValue+5].formLineItem.IsRequired__c = false;
                formLineItemObject[selectedOptionValue+5].formLineItem.Show_on_Screen__c = false;;
            }else if(selectedOptionVal == 'New customer - Established business changing supplier(s) to ABC or ABC subsidiary'){
                formLineItemObject[selectedOptionValue+1].formLineItem.IsRequired__c = true;
                formLineItemObject[selectedOptionValue+1].formLineItem.Show_on_Screen__c = true;
                formLineItemObject[selectedOptionValue+2].formLineItem.IsRequired__c = false;
                formLineItemObject[selectedOptionValue+2].formLineItem.Show_on_Screen__c = false;
                formLineItemObject[selectedOptionValue+3].formLineItem.IsRequired__c = false;
                formLineItemObject[selectedOptionValue+3].formLineItem.Show_on_Screen__c = false;
                formLineItemObject[selectedOptionValue+4].formLineItem.IsRequired__c = false;
                formLineItemObject[selectedOptionValue+4].formLineItem.Show_on_Screen__c = false;
                formLineItemObject[selectedOptionValue+5].formLineItem.IsRequired__c = false;
                formLineItemObject[selectedOptionValue+5].formLineItem.Show_on_Screen__c = false;
            }else if(selectedOptionVal == 'New customer - Established business adding ABC or ABC subsidiary as supplier(s)'){
                formLineItemObject[selectedOptionValue+1].formLineItem.IsRequired__c = false;
                formLineItemObject[selectedOptionValue+1].formLineItem.Show_on_Screen__c = false;
                formLineItemObject[selectedOptionValue+2].formLineItem.IsRequired__c = true;
                formLineItemObject[selectedOptionValue+2].formLineItem.Show_on_Screen__c = true;
                formLineItemObject[selectedOptionValue+3].formLineItem.IsRequired__c = false;
                formLineItemObject[selectedOptionValue+3].formLineItem.Show_on_Screen__c = false;
                formLineItemObject[selectedOptionValue+4].formLineItem.IsRequired__c = false;
                formLineItemObject[selectedOptionValue+4].formLineItem.Show_on_Screen__c = false;
                formLineItemObject[selectedOptionValue+5].formLineItem.IsRequired__c = false;
                formLineItemObject[selectedOptionValue+5].formLineItem.Show_on_Screen__c = false;
            }else if(selectedOptionVal == 'Existing ABC Customer - Change in ownership'){
                formLineItemObject[selectedOptionValue+1].formLineItem.IsRequired__c = false;
                formLineItemObject[selectedOptionValue+1].formLineItem.Show_on_Screen__c = false;
                formLineItemObject[selectedOptionValue+2].formLineItem.IsRequired__c = false;
                formLineItemObject[selectedOptionValue+2].formLineItem.Show_on_Screen__c = false;
                formLineItemObject[selectedOptionValue+3].formLineItem.IsRequired__c = true;
                formLineItemObject[selectedOptionValue+3].formLineItem.Show_on_Screen__c = true;
                formLineItemObject[selectedOptionValue+4].formLineItem.IsRequired__c = false;
                formLineItemObject[selectedOptionValue+4].formLineItem.Show_on_Screen__c = false;
                formLineItemObject[selectedOptionValue+5].formLineItem.IsRequired__c = false;
                formLineItemObject[selectedOptionValue+5].formLineItem.Show_on_Screen__c = false;
            }else if(selectedOptionVal == 'Existing ABC Customer - Additional account'){
                formLineItemObject[selectedOptionValue+1].formLineItem.IsRequired__c = false;
                formLineItemObject[selectedOptionValue+1].formLineItem.Show_on_Screen__c = false;
                formLineItemObject[selectedOptionValue+2].formLineItem.IsRequired__c = false;
                formLineItemObject[selectedOptionValue+2].formLineItem.Show_on_Screen__c = false;
                formLineItemObject[selectedOptionValue+3].formLineItem.IsRequired__c = false;
                formLineItemObject[selectedOptionValue+3].formLineItem.Show_on_Screen__c = false;
                formLineItemObject[selectedOptionValue+4].formLineItem.IsRequired__c = true;
                formLineItemObject[selectedOptionValue+4].formLineItem.Show_on_Screen__c = true;
                formLineItemObject[selectedOptionValue+5].formLineItem.IsRequired__c = false;
                formLineItemObject[selectedOptionValue+5].formLineItem.Show_on_Screen__c = false;
            }else if(selectedOptionVal == 'Existing ABC Customer - Updated CSRA 590 form'){
                formLineItemObject[selectedOptionValue+1].formLineItem.IsRequired__c = false;
                formLineItemObject[selectedOptionValue+1].formLineItem.Show_on_Screen__c = false;
                formLineItemObject[selectedOptionValue+2].formLineItem.IsRequired__c = false;
                formLineItemObject[selectedOptionValue+2].formLineItem.Show_on_Screen__c = false;
                formLineItemObject[selectedOptionValue+3].formLineItem.IsRequired__c = false;
                formLineItemObject[selectedOptionValue+3].formLineItem.Show_on_Screen__c = false;
                formLineItemObject[selectedOptionValue+4].formLineItem.IsRequired__c = false;
                formLineItemObject[selectedOptionValue+4].formLineItem.Show_on_Screen__c = false;
                formLineItemObject[selectedOptionValue+5].formLineItem.IsRequired__c = true;
                formLineItemObject[selectedOptionValue+5].formLineItem.Show_on_Screen__c = true;
            }
        }else if(currentLineItemObj.formLineItem.Question_Text__c == 'Are any of the owners associated with or do they own other pharmacies?'){
            if(selectedOptionVal == 'Yes'){
                formLineItemObject[selectedOptionValue+1].formLineItem.IsRequired__c = true;
                formLineItemObject[selectedOptionValue+1].formLineItem.Show_on_Screen__c = true;
            }else{
                formLineItemObject[selectedOptionValue+1].formLineItem.IsRequired__c = false;
                formLineItemObject[selectedOptionValue+1].formLineItem.Show_on_Screen__c = false;
            }
        }else if(currentLineItemObj.formLineItem.Question_Text__c == 'Are any of the owners a licensed pharmacist?'){
            if(selectedOptionVal == 'Yes'){
                formLineItemObject[selectedOptionValue+1].formLineItem.IsRequired__c = true;
                formLineItemObject[selectedOptionValue+1].formLineItem.Show_on_Screen__c = true;
            }else{
                formLineItemObject[selectedOptionValue+1].formLineItem.IsRequired__c = false;
                formLineItemObject[selectedOptionValue+1].formLineItem.Show_on_Screen__c = false;
            }
        }else if(currentLineItemObj.formLineItem.Question_Text__c == 'Are any of the owners a prescribing physician at this pharmacy?'){
            if(selectedOptionVal == 'Yes'){
                formLineItemObject[selectedOptionValue+1].formLineItem.IsRequired__c = true;
                formLineItemObject[selectedOptionValue+1].formLineItem.Show_on_Screen__c = true;
            }else{
                formLineItemObject[selectedOptionValue+1].formLineItem.IsRequired__c = false;
                formLineItemObject[selectedOptionValue+1].formLineItem.Show_on_Screen__c = false;
            }
        }else if(currentLineItemObj.formLineItem.Question_Text__c == 'Has a supplier ever suspended or ceased controlled substance sales to the pharmacy?'){
            if(selectedOptionVal == 'Yes'){
                formLineItemObject[selectedOptionValue+1].formLineItem.IsRequired__c = true;
                formLineItemObject[selectedOptionValue+1].formLineItem.Show_on_Screen__c = true;
            }else{
                formLineItemObject[selectedOptionValue+1].formLineItem.IsRequired__c = false;
                formLineItemObject[selectedOptionValue+1].formLineItem.Show_on_Screen__c = false;
            }
        }else if(currentLineItemObj.formLineItem.Question_Text__c == 'Is this pharmacy currently part of an active investigation at the Federal, State or Local level?'){
            if(selectedOptionVal == 'Yes'){
                formLineItemObject[selectedOptionValue+1].formLineItem.IsRequired__c = true;
                formLineItemObject[selectedOptionValue+1].formLineItem.Show_on_Screen__c = true;
            }else{
                formLineItemObject[selectedOptionValue+1].formLineItem.IsRequired__c = false;
                formLineItemObject[selectedOptionValue+1].formLineItem.Show_on_Screen__c = false;
            }
        }else if(currentLineItemObj.formLineItem.Question_Text__c == 'Has the pharmacy had a DEA registration or state license/registration suspended, revoked or disciplined within the last 10 years?'){
            if(selectedOptionVal == 'Yes'){
                formLineItemObject[selectedOptionValue+1].formLineItem.IsRequired__c = true;
                formLineItemObject[selectedOptionValue+1].formLineItem.Show_on_Screen__c = true;
            }else{
                formLineItemObject[selectedOptionValue+1].formLineItem.IsRequired__c = false;
                formLineItemObject[selectedOptionValue+1].formLineItem.Show_on_Screen__c = false;
            }
        }else if(currentLineItemObj.formLineItem.Question_Text__c == 'Has the PIC been sanctioned and/or disciplined within the last 10 years in any state(s) where they were licensed as a pharmacist?'){
            if(selectedOptionVal == 'Yes'){
                formLineItemObject[selectedOptionValue+1].formLineItem.IsRequired__c = true;
                formLineItemObject[selectedOptionValue+1].formLineItem.Show_on_Screen__c = true;
            }else{
                formLineItemObject[selectedOptionValue+1].formLineItem.IsRequired__c = false;
                formLineItemObject[selectedOptionValue+1].formLineItem.Show_on_Screen__c = false;
            }
        }else if(currentLineItemObj.formLineItem.Question_Text__c == 'Has the owner, family member, or any employee of the pharmacy had a DEA registration or state license/registration suspended, revoked or disciplined within the last 10 years?'){
            if(selectedOptionVal == 'Yes'){
                formLineItemObject[selectedOptionValue+1].formLineItem.IsRequired__c = true;
                formLineItemObject[selectedOptionValue+1].formLineItem.Show_on_Screen__c = true;
            }else{
                formLineItemObject[selectedOptionValue+1].formLineItem.IsRequired__c = false;
                formLineItemObject[selectedOptionValue+1].formLineItem.Show_on_Screen__c = false;
            }
        }else if(currentLineItemObj.formLineItem.Question_Text__c == 'Does the pharmacy fill controlled substance and/or Gabapentin prescriptions for out-of-state patients?'){
            if(selectedOptionVal == 'Yes'){
                formLineItemObject[selectedOptionValue+1].formLineItem.IsRequired__c = true;
                formLineItemObject[selectedOptionValue+1].formLineItem.Show_on_Screen__c = true;
            }else{
                formLineItemObject[selectedOptionValue+1].formLineItem.IsRequired__c = false;
                formLineItemObject[selectedOptionValue+1].formLineItem.Show_on_Screen__c = false;
            }
        }else if(currentLineItemObj.formLineItem.Question_Text__c == 'Are you aware of any disciplinary actions/sanctions taken at any time against any of the above practitioners?'){
            if(selectedOptionVal == 'Yes'){
                formLineItemObject[selectedOptionValue+1].formLineItem.IsRequired__c = true;
                formLineItemObject[selectedOptionValue+1].formLineItem.Show_on_Screen__c = true;
            }else{
                formLineItemObject[selectedOptionValue+1].formLineItem.IsRequired__c = false;
                formLineItemObject[selectedOptionValue+1].formLineItem.Show_on_Screen__c = false;
            }
        }
    },
    getSummaryQuestion : function(cmp){
        var formLineItemObject = cmp.get("v.formWrapperObject");
        var summaryQuestion = -1;
        for(var i=0; i<formLineItemObject.length; i++){
            if(formLineItemObject[i].formLineItem.Is_Summary__c){
                summaryQuestion = i;
                break;
            }
        }
        if(summaryQuestion >= 0 && cmp.get("v.onboardingForm").Status__c != 'Complete'){
            var formName = cmp.get("v.onboardingForm").Name;
            var action = cmp.get('c.getSummaryDetails');
            action.setParams({
                "formName" : formName,
                "summaryQuestionDisplayOrder" : formLineItemObject[summaryQuestion].formLineItem.Order__c
            });
            action.setCallback(this, function(res){
                var state = res.getState();
                if(state == 'SUCCESS') {
                    var responseValue = res.getReturnValue();
                    if(formName == 'Retail Price Request'){
                        formLineItemObject[summaryQuestion].formLineItem.Response_Validation__c = '<ol>';
                        for(var i=0;i<responseValue.length;i++){
                            for(var j=0;j<formLineItemObject.length;j++){
                                if(responseValue[i].Option_Question_Display_Order__c == formLineItemObject[j].formLineItem.Order__c && responseValue[i].Option_Question_Value__c == formLineItemObject[j].formLineItem.Response__c){
                                    formLineItemObject[summaryQuestion].formLineItem.Response_Validation__c = formLineItemObject[summaryQuestion].formLineItem.Response_Validation__c + '<li>' + responseValue[i].Display_Value__c + '</li>' ;
                                    break;
                                }
                            }
                        }
                        formLineItemObject[summaryQuestion].formLineItem.Response_Validation__c = formLineItemObject[summaryQuestion].formLineItem.Response_Validation__c + '</ol>'
                    }
                    cmp.set("v.formWrapperObject", formLineItemObject);
                }
            });
            $A.enqueueAction(action);
        }
    },
    PDSAgreementForm : function(component,formLineItems,form,dependentQuestionindex,changeValue,questionText,event){
        if(questionText == "AmerisourceBergen Drug Corporation (ABDC) exchanges standard electronic data interchange (“EDI”) sets with customer’s POS or other system, including purchase orders and confirmation that an order was received and stock allocated."){
            if(changeValue == 'Yes. I would like this data service.'){
                formLineItems[dependentQuestionindex+1].formLineItem.Show_on_Screen__c = true;
                formLineItems[dependentQuestionindex+1].formLineItem.IsRequired__c = true;
            }else{
                formLineItems[dependentQuestionindex+1].formLineItem.Show_on_Screen__c = false;
                formLineItems[dependentQuestionindex+1].formLineItem.IsRequired__c = false;
            }
        }
        if(questionText == "ABDC provides electronic pricing data for customer’s POS or other systems relating to customer’s invoice cost, contract prices, and published Sugested Wholesale Prices (“SWP”) or other benchmarks for prescription pharmaceuticals."){
            if(changeValue == 'Yes. I would like this data service.'){
                formLineItems[dependentQuestionindex+1].formLineItem.Show_on_Screen__c = true;
                formLineItems[dependentQuestionindex+1].formLineItem.IsRequired__c = true;
                formLineItems[dependentQuestionindex+2].formLineItem.Show_on_Screen__c = true;
                formLineItems[dependentQuestionindex+2].formLineItem.IsRequired__c = true;
            }else{
                formLineItems[dependentQuestionindex+1].formLineItem.Show_on_Screen__c = false;
                formLineItems[dependentQuestionindex+1].formLineItem.IsRequired__c = false;
                formLineItems[dependentQuestionindex+2].formLineItem.Show_on_Screen__c = false;
                formLineItems[dependentQuestionindex+2].formLineItem.IsRequired__c = false;
            }
        }
        if(questionText == 'Yes, I would like this data service.' && dependentQuestionindex == 2){            
            if(event.getSource().get("v.checked") == true){   
                formLineItems[dependentQuestionindex+1].formLineItem.Show_on_Screen__c = true;
                formLineItems[dependentQuestionindex+1].formLineItem.IsRequired__c = true;
                formLineItems[dependentQuestionindex+2].formLineItem.Show_on_Screen__c = true;
                formLineItems[dependentQuestionindex+2].formLineItem.IsRequired__c = true;
            }else{
                formLineItems[dependentQuestionindex+1].formLineItem.Show_on_Screen__c = false;
                formLineItems[dependentQuestionindex+1].formLineItem.IsRequired__c = false;
                formLineItems[dependentQuestionindex+2].formLineItem.Show_on_Screen__c = false;
                formLineItems[dependentQuestionindex+2].formLineItem.IsRequired__c = false;
            }
        }
        if(questionText == "ABDC provides electronic pricing data for customer’s POS or other systems relating to customer’s invoice cost, contract prices, and retail selling prices for non-prescription products."){
            if(changeValue == 'Yes. I would like this data service.'){
                formLineItems[dependentQuestionindex+1].formLineItem.Show_on_Screen__c = true;
                formLineItems[dependentQuestionindex+1].formLineItem.IsRequired__c = true;
                formLineItems[dependentQuestionindex+2].formLineItem.Show_on_Screen__c = true;
                formLineItems[dependentQuestionindex+2].formLineItem.IsRequired__c = true;
            }else{
                formLineItems[dependentQuestionindex+1].formLineItem.Show_on_Screen__c = false;
                formLineItems[dependentQuestionindex+1].formLineItem.IsRequired__c = false;
                formLineItems[dependentQuestionindex+2].formLineItem.Show_on_Screen__c = false;
                formLineItems[dependentQuestionindex+2].formLineItem.IsRequired__c = false;
            }
        }else if(questionText == "ABDC exchanges standard electronic data interchange (“EDI”) sets with customer’s PMS or other system, including purchase orders and confirmation that an order was received and stock allocated."){
            if(changeValue == 'Yes. I would like this data service.'){
                formLineItems[dependentQuestionindex+1].formLineItem.Show_on_Screen__c = true;
                formLineItems[dependentQuestionindex+1].formLineItem.IsRequired__c = true;
            }else{
                formLineItems[dependentQuestionindex+1].formLineItem.Show_on_Screen__c = false;
                formLineItems[dependentQuestionindex+1].formLineItem.IsRequired__c = false;
            }
        }else if(questionText == "ABDC exchanges standard electronic data interchange (“EDI”) sets with customer’s PMS or other system, including purchase orders and confirmation that an order was received and stock allocated."){
            if(changeValue == 'Yes. I would like this data service.'){
                formLineItems[dependentQuestionindex+1].formLineItem.Show_on_Screen__c = true;
                formLineItems[dependentQuestionindex+1].formLineItem.IsRequired__c = true;
            }else{
                formLineItems[dependentQuestionindex+1].formLineItem.Show_on_Screen__c = false;
                formLineItems[dependentQuestionindex+1].formLineItem.IsRequired__c = false;
            }
        }
    },
    
    CSRA590Dependencies: function(component,formLineItems,objString,dependentQuestionindex,changeValue,questionText,event){        
        if(questionText == 'Please check all that apply to your business activity' || questionText == 'Which of the following are included in your due diligence processes?'){
            if(changeValue.includes('Other')){
                formLineItems[dependentQuestionindex+1].formLineItem.Show_on_Screen__c = true;
                formLineItems[dependentQuestionindex+1].formLineItem.IsRequired__c = true;
            }else{
                formLineItems[dependentQuestionindex+1].formLineItem.Show_on_Screen__c = false;
                formLineItems[dependentQuestionindex+1].formLineItem.IsRequired__c = false;
            }
        }
        if(questionText == 'Select if you have a current account with any other ABC subsidiary and indicate applicable account number'){
            if(objString.search('Besse') != -1){
                formLineItems[dependentQuestionindex+1].formLineItem.Show_on_Screen__c = true;
                formLineItems[dependentQuestionindex+1].formLineItem.IsRequired__c = true;
                component.set("v.formWrapperObject", formLineItems);
            }else if(objString.search('Besse') == -1){
                formLineItems[dependentQuestionindex+1].formLineItem.Show_on_Screen__c = false;
                formLineItems[dependentQuestionindex+1].formLineItem.IsRequired__c = false;
                component.set("v.formWrapperObject", formLineItems);
            }
            if(objString.search('Oncology') != -1){
                formLineItems[dependentQuestionindex+2].formLineItem.Show_on_Screen__c = true;
                formLineItems[dependentQuestionindex+2].formLineItem.IsRequired__c = true;
                component.set("v.formWrapperObject", formLineItems);
            }else if(objString.search('Oncology') == -1){
                formLineItems[dependentQuestionindex+2].formLineItem.Show_on_Screen__c = false;
                formLineItems[dependentQuestionindex+2].formLineItem.IsRequired__c = false;
                component.set("v.formWrapperObject", formLineItems);
            }
            if(objString.search('MWI') != -1){
                formLineItems[dependentQuestionindex+3].formLineItem.Show_on_Screen__c = true;
                formLineItems[dependentQuestionindex+3].formLineItem.IsRequired__c = true;
                component.set("v.formWrapperObject", formLineItems);
            }else if(objString.search('MWI') == -1){
                formLineItems[dependentQuestionindex+3].formLineItem.Show_on_Screen__c = false;
                formLineItems[dependentQuestionindex+3].formLineItem.IsRequired__c = false;
                component.set("v.formWrapperObject", formLineItems);
            }
            if(objString.search('ASD') != -1){
                formLineItems[dependentQuestionindex+4].formLineItem.Show_on_Screen__c = true;
                formLineItems[dependentQuestionindex+4].formLineItem.IsRequired__c = true;
                component.set("v.formWrapperObject", formLineItems);
            }else if(objString.search('ASD') == -1){
                formLineItems[dependentQuestionindex+4].formLineItem.Show_on_Screen__c = false;
                formLineItems[dependentQuestionindex+4].formLineItem.IsRequired__c = false;
                component.set("v.formWrapperObject", formLineItems);
            }
            if(objString.search('ABDC') != -1){
                formLineItems[dependentQuestionindex+5].formLineItem.Show_on_Screen__c = true;
                formLineItems[dependentQuestionindex+5].formLineItem.IsRequired__c = true;
                component.set("v.formWrapperObject", formLineItems);
            }else if(objString.search('ABDC') == -1){
                formLineItems[dependentQuestionindex+5].formLineItem.Show_on_Screen__c = false;
                formLineItems[dependentQuestionindex+5].formLineItem.IsRequired__c = false;
                component.set("v.formWrapperObject", formLineItems);
            }
            if(objString.search('ICS') != -1){
                formLineItems[dependentQuestionindex+6].formLineItem.Show_on_Screen__c = true;
                formLineItems[dependentQuestionindex+6].formLineItem.IsRequired__c = true;
                component.set("v.formWrapperObject", formLineItems);
            }else if(objString.search('ICS') == -1){
                formLineItems[dependentQuestionindex+6].formLineItem.Show_on_Screen__c = false;
                formLineItems[dependentQuestionindex+6].formLineItem.IsRequired__c = false;
                component.set("v.formWrapperObject", formLineItems);
            }            
        }
    },    
    onBlurHelper : function(component, event){
        var questionText = event.getSource().get("v.label");
        var current_year=new Date().getFullYear();
        if(questionText == 'Owner (s) since'){
            var dateString =  event.getSource().get("v.value");
            var month = dateString.substring(0,2);
            var year = dateString.substring(2,7);
            if((month < 1) || (month >12)){
                var errMessage = 'Please enter valid Month in MM format between 01 to 12';
                var toastEvent = $A.get("e.force:showToast");
                toastEvent.setParams({
                    title : 'Error',
                    message: errMessage,
                    type: 'error',
                });
                toastEvent.fire();
                return false;
            }else if((year < 1800) || (year > current_year)){
                var errMessage = 'Please enter valid Year. It should be  >1800 and <= Current Year';
                var toastEvent = $A.get("e.force:showToast");
                toastEvent.setParams({
                    title : 'Error',
                    message: errMessage,
                    type: 'error',
                });
                toastEvent.fire();
                return false;
            }else{
                var setDate = month + '/' +year ;
                event.getSource().set("v.value", setDate);
            }
        }
    },
    MAX_FILE_SIZE: 4000000, //Max file size 4.0 MB 
    CHUNK_SIZE: 4000000,      //Chunk Max size 4.0 MB 
    
    
    
    uploadHelper: function(component, event) {
        // start/show the loading spinner   
        component.set("v.showLoadingSpinner", true);
        // get the selected files using aura:id [return array of files]
        // event.getSource().get("v.files")
        var fileInput = event.getSource().get("v.files");
        var onbFormLineItemId = event.getSource().get("v.name");
        // get the first file using array index[0]  
        var file = fileInput[0];
        var fileExtension = file.name.split(".");
        if(onbFormLineItemId.Response_Validation__c != '' && onbFormLineItemId.Response_Validation__c != undefined &&
           onbFormLineItemId.Response_Validation__c != null){
            if(!onbFormLineItemId.Response_Validation__c.includes(fileExtension[fileExtension.length-1].toLowerCase())){
                var errorMsg = 'Selected file format is not allowed. Please upload '+onbFormLineItemId.Response_Validation__c+' formats only.';
                var toastEvent = $A.get("e.force:showToast");
                toastEvent.setParams({
                    title : 'Error',
                    message: errorMsg,
                    type: 'error',
                });
                toastEvent.fire();
                component.set("v.showLoadingSpinner", false);
                return;
            }
        }
        var self = this;
        // check the selected file size, if select file size greter then MAX_FILE_SIZE,
        // then show a alert msg to user,hide the loading spinner and return from function  
        if (file.size > self.MAX_FILE_SIZE) {
            var toastEvent = $A.get("e.force:showToast");
            toastEvent.setParams({
                title : 'Error',
                message: 'Attachments larger than 4MB are not accepted. Please upload a smaller file.',
                type: 'error',
            });
            toastEvent.fire();
            component.set("v.showLoadingSpinner", false);
            return;
        }
        
        // create a FileReader object 
        var objFileReader = new FileReader();
        // set onload function of FileReader object   
        objFileReader.onload = $A.getCallback(function() {
            var fileContents = objFileReader.result;
            var base64 = 'base64,';
            var dataStart = fileContents.indexOf(base64) + base64.length;
            fileContents = fileContents.substring(dataStart);
            // call the uploadProcess method 
            self.uploadProcess(component, file, fileContents, onbFormLineItemId);
        });
        
        objFileReader.readAsDataURL(file);
    },
    
    uploadProcess: function(component, file, fileContents, onbFormLineItemId) {
        // set a default size or startpostiton as 0 
        var startPosition = 0;
        // calculate the end size or endPostion using Math.min() function which is return the min. value   
        var endPosition = Math.min(fileContents.length, startPosition + this.CHUNK_SIZE);
        // start with the initial chunk, and set the attachId(last parameter)is null in begin
        this.uploadInChunk(component, file, fileContents, startPosition, endPosition, '', onbFormLineItemId);
    },
    
    uploadInChunk: function(component, file, fileContents, startPosition, endPosition, attachId, onbFormLineItemId) {
        // call the apex method 'saveChunk'
        var formObj = component.get("v.onboardingForm");
        var getchunk = fileContents.substring(startPosition, endPosition);
        //var url = new URL(window.location.href);
        //var id = url.href.split("/");
        var action = component.get("c.getOAuthToken");
        action.setParams({
            fileName: file.name,
            fileContent:getchunk,
            fileType: file.type,
            onboardingId :  formObj.Onboarding__c,
            formId : onbFormLineItemId.Id,
            category : onbFormLineItemId.Sharepoint_Folder__c,
            accountId : formObj.Account__c,
            folderName : onbFormLineItemId.Sharepoint_Folder__c
        });
        
        // set call back 
        action.setCallback(this, function(response) {
            // store the response / Attachment Id   
            attachId = response.getReturnValue();
            var state = response.getState();
            if (state === "SUCCESS") {
                // update the start position with end postion
                startPosition = endPosition;
                endPosition = Math.min(fileContents.length, startPosition + this.CHUNK_SIZE);
                // check if the start postion is still less then end postion 
                // then call again 'uploadInChunk' method , 
                // else, diaply $A.get('e.force:refreshView').fire() msg and hide the loading spinner
                if (startPosition < endPosition) {
                    this.uploadInChunk(component, file, fileContents, startPosition, endPosition, attachId, onbFormLineItemId);
                } else {                    
                    var toastEvent = $A.get("e.force:showToast");
                    toastEvent.setParams({
                        title : 'Success',
                        message: 'Your File is uploaded successfully',
                        type: 'success',
                    });
                    toastEvent.fire();
                    var fileWrapper = response.getReturnValue();
                    var fileURI = fileWrapper.uri;
                    var sitePath = fileWrapper.serverURL;
                    sitePath = sitePath.substring(0,sitePath.length);
                    sitePath = sitePath.substring(1,sitePath.length-1);
                    if(onbFormLineItemId.Response__c != '' && onbFormLineItemId.Response__c != null){
                        onbFormLineItemId.Response__c = onbFormLineItemId.Response__c + ','+file.name+'-'+sitePath;
                    }else{
                        onbFormLineItemId.Response__c = file.name+'-'+sitePath;
                    }
                    onbFormLineItemId.Document_name__c = file.name;
                    onbFormLineItemId.File_Path__c = sitePath;
                    onbFormLineItemId.Status__c = 'Submitted';
                    onbFormLineItemId.FileURI__c = fileURI;
                    component.set("v.showLoadingSpinner", false);
                    this.fetchData(component, onbFormLineItemId.Id);
                }
                // handel the response errors        
            } else if (state === "INCOMPLETE") {
            } else if (state === "ERROR") {
                var errors = response.getError();
                if (errors) {
                    if (errors[0] && errors[0].message) {
                        console.log("Error message: " + errors[0].message);
                    }
                } else {
                    console.log("Unknown error");
                }
            }
        }); 
        // enqueue the action
        $A.enqueueAction(action);
    },
    
    fetchData: function (cmp, onbFormLineItemId) {
        var action = cmp.get('c.fetchRecords');
        var formObj = cmp.get("v.onboardingForm");
        var formLineItemObject = cmp.get("v.formWrapperObject");
        action.setParams({ "recordID" : onbFormLineItemId, "isFormId" : true});
        
        action.setCallback(this, $A.getCallback(function (response) {
            var state = response.getState();
            if (state === "SUCCESS") {
                if(response.getReturnValue() != null) {
                    var records = response.getReturnValue(); 
                    cmp.set("v.mydata",records);
                    //var currentPage = cmp.get("v.pageNumber");
                    for(var i=0; i<formLineItemObject.length; i++){
                        formLineItemObject[i].formLineItem.mydata = [];
                        if(formLineItemObject[i].formLineItem.Id == onbFormLineItemId){
                            formLineItemObject[i].formLineItem.mydata = records;
                        }
                    }
                    cmp.set("v.formWrapperObject", formLineItemObject);
                } else {
                    cmp.set("v.noResults", "No records to display");
                    
                }
            } else if (state === "ERROR") {
                var errors = response.getError();
                console.error(errors);
                cmp.set("v.noResults", "No records to display");
                cmp.set("v.mydata","");
                
            }
        }));
        $A.enqueueAction(action);
    },
    
    deleteRow : function(component,row) {
        var fileName = row.FileLeafRef ;
        var action = component.get("c.deleteFile");
        action.setParams({
            fileName: fileName,
            path : row.FileRef
            
        });
        // set call back 
        action.setCallback(this, function(response) {
            // store the response / Attachment Id   
            var state = response.getState();
            if (state === "SUCCESS") {
                // update the start position with end postion
                var response = response.getReturnValue();
                this.fetchData(component, row.LineItemId);
                // handel the response errors        
            } else if (state === "INCOMPLETE") {
            } else if (state === "ERROR") {
                var errors = response.getError();
                if (errors) {
                    if (errors[0] && errors[0].message) {
                        console.log("Error message: " + errors[0].message);
                    }
                } else {
                    console.log("Unknown error");
                }
            }
        }); 
        // enqueue the action
        $A.enqueueAction(action);
    },        
})