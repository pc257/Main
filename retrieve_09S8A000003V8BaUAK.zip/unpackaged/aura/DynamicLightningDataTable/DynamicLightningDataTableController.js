({
	doInit : function(component, event, helper) {
        component.set("v.mycolumn",[
            {label : 'Account Name' , fieldName : 'URL' , type : 'url',
            	typeAttributes: { 
        			label: {
            			fieldName: 'Name'
        			},
        			target: '_self'
                },
    sortable: true},
            {label : 'Account Number' , fieldName : 'AccountNumber' , type : 'text'},
            {label : 'Progress'
             ,cellAttributes:{class : {fieldName : 'Progress__c'}} , "initialWidth": 160
            },
            {
                label : 'Targeted Completion Date' , fieldName : 'TargetCompletionDate' , type : 'date' , sortable : true
            }
        ]);
		helper.getLightningTableData(component);
	},
    updateColumnSorting : function(component, event, helper) {
        var fieldname = event.getParam('fieldname');
        var sortDirection = event.getParam('sortDirection');
        component.set("v.sortedBy",fieldname);
        component.set("v.sorteddirection",sortDirection);
        helper.sortdata(component,fieldname, sortDirection);
    }
})