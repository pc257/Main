({
	getLightningTableData : function(component) {
		var parentIdVal = component.get("v.parentIdVal");
        var objectVal = component.get("v.object");
        var fieldsVal = component.get("v.fields");
        var action = component.get("c.getSobjectRecords");
        action.setParams({
            ObjectName : objectVal,
            fieldstoget : fieldsVal,
            parentIdValue : parentIdVal
        });
        action.setCallback(this,function(response){
           var state = response.getState();
            if(state== 'SUCCESS'){
                var rtnVal = response.getReturnValue();
                for(var i=0 ; i < rtnVal.tableRecords.length ; i++){
                    var row = rtnVal.tableRecords[i];
                    row.URL = '/lightning/r/Account/' + row.Id + '/view';
					row.Progress__c = rtnVal.tableRecords[i].Progress__c;
                    var imageVal = row.Progress__c;
                    if(imageVal.includes("Account_Progress_Images")){
                    	var idx = imageVal.search("Account_Progress_Images");
                    	var imgName = imageVal.substring(idx+24,imageVal.indexOf(".png"));
                    	row.Progress__c = imgName;    
                    }
                    else{
                        row.Progress__c = 'onb';
                    }
                    if(row.Intake_Forms__r){
                        for(var j=0 ; j < row.Intake_Forms__r.length ; j++){
                            var trgtDate = row.Intake_Forms__r[j];
                            row.TargetCompletionDate = trgtDate.Target_Form_Completion_Date__c;
                        }
                    }
                }
                component.set("v.mydata",rtnVal.tableRecords);
            }
        });
        $A.enqueueAction(action);
	},
    sortdata:function(component,fieldname, sortDirection){
        var data = component.get("v.mydata");
        var reverse = sortDirection !== 'asc';
        data.sort(this.sortBy(fieldname, reverse));
        component.set("v.mydata",data);        
    },
     sortBy: function (field, reverse, primer) {
        var key = primer ?
            function(x) {return primer(x[field])} :
            function(x) {return x[field]};
        reverse = !reverse ? 1 : -1;
        return function (a, b) {
            return a = key(a), b = key(b), reverse * ((a > b) - (b > a));
        }
    }
})