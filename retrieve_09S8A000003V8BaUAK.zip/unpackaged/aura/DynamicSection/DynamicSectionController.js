({
	doInit : function(component, event, helper) {
        if(component.get('v.FieldSetName')){
			helper.readFieldSet(component, event, helper);
        }
	},
    
    toggleSection : function(component, event, helper) {
        component.set('v.isexpanded', !component.get('v.isexpanded'));
    }
})