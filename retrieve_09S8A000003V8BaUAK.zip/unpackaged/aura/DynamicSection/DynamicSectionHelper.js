({
    readFieldSet : function(component, event, helper) {
        var action = component.get('c.readFieldSet');
        action.setParams({
            fieldSetName : component.get("v.FieldSetName"), 
            ObjectName : component.get("v.sObjectName")
        });
        action.setCallback(this, function(data){
            var state = data.getState();
            if(state == "SUCCESS"){
                var rows = data.getReturnValue();
                if(rows && rows.length > 0){
                    component.set("v.Fields", rows);
                }
            }
        });
        $A.enqueueAction(action);
    }
})