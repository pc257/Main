({
    doInit: function(component,event,helper) {
        helper.processErrorMessages(component,event,helper)
    },
    onErrorMessagesChange: function(component,event,helper) {
        helper.processErrorMessages(component,event,helper)
    },
});