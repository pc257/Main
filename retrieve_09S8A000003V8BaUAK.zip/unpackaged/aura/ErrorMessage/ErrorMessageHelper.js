({
    processErrorMessages: function(component,event,helper) {
        var errorMessages = component.get("v.errorMessages");

        if(errorMessages){
            var errorMessage = "";
            errorMessages.forEach(function(item){
                console.log("item: " + item);
                if(errorMessage === ""){
                    errorMessage = (item);
                }
                else{
                    errorMessage += ("\n" + item);
                }
            });
            component.set("v.errorMessage", errorMessage);
        }
    },
});