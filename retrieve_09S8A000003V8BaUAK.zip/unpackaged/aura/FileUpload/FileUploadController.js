({
    handleFilesChange : function(component, event)
    {
        var uploadFile = event.getSource().get("v.files")[0];
        console.log(uploadFile);
        component.set("v.hasFiles", true);
        component.set("v.fileName", uploadFile.name);
    },
    
    handleUpload : function (component, event)
    {        
        var action = component.get("c.callSharePoint");
        action.setParams({
            fileName: component.get("v.fileName"),
           
        });
        action.setCallback(this, function(response) {
            if (response.state === "SUCCESS"){
                var serverResponse = response.getReturnValue();
            }    
        });
        $A.enqueueAction(action);
     }
});