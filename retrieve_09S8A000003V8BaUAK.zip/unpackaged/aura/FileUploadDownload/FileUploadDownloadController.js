({
    handleUploadFinished: function (cmp, event) {
        
        // This will contain the List of File uploaded data and status
        var uploadedFiles = event.getParam("files");
        cmp.set("v.fileName",uploadedFiles);
        
        //alert("Files uploaded : " + uploadedFiles.length+'---'+uploadedFiles[0].name);
    },
    
    handleDeletion:function(cmp, event){
        var b;
        var documentIdArray = [];
        var a = event.getSource().get("v.alternativeText");
        var action = cmp.get("c.deleteAttachment");
        action.setParams({"attachId" : a});
        
        action.setCallback(this, function(response) {
            var state = response.getState();
            //console.log('state..!',state);
            if (state === "SUCCESS"){
                var file = cmp.get("v.fileName");
                for(b=0; b<file.length; b++){
                    documentIdArray.push(file[b].documentId);
                }
                var c = documentIdArray.indexOf(a);
                file.splice(c,1);
                cmp.set("v.fileName", file);
                //alert('File Deleted');
                
                var toastEvent = $A.get("e.force:showToast");
                toastEvent.setParams({
                    title : 'Success',
                    message: 'The attachment is deleted',
                    duration:' 5000',
                    key: 'info_alt',
                    type: 'success',
                    mode: 'dismissible'
                });
                toastEvent.fire();
            }
            else
            {
                alert('Something went wrong.');
            }
        });
        $A.enqueueAction(action);    
    }
});