({
    handleUploadFinished: function (cmp, event) {
        var uploadedFiles = event.getParam("files");
        alert("Files uploaded");
    }
})