({    
    doInit : function(component, event, helper) {        
        var action = component.get("c.getOppotunityStage");
        action.setParams({
            recordID : component.get("v.recordId")            
        });
        action.setCallback(this, function(response){
            var state = response.getState();   
            if(state == "SUCCESS"){               
                var responseString = response.getReturnValue(); 
                
                if(responseString == 'Success Opportunity'){
                    var a = component.get('c.getFieldValuesOpp');
                    $A.enqueueAction(a);
                }else if(responseString == 'Success Account'){
                    var a = component.get('c.getFieldValuesAcc');
                    $A.enqueueAction(a);
                }else if(responseString == 'Invalid Stage'){
                    component.set("v.showErrorMessage", true); 
                    component.set("v.ErrorMessage", $A.get("$Label.c.Opportunity_Closure_Error_Message"));                                          
                    helper.toggleSpinner(component);
                }else if(responseString == 'Blank Account'){
                    component.set("v.showErrorMessage", true); 
                    component.set("v.ErrorMessage",   $A.get("$Label.c.Account_Closure_Request_Account_Error"));                                        
                    helper.toggleSpinner(component);
                }else if(responseString == 'Invalid Account Record Type'){
                    component.set("v.showErrorMessage", true); 
                    component.set("v.ErrorMessage",   'This is applicable for only Customer Record Type Account with Type = Enterprise Business Partner Location');                                        
                    helper.toggleSpinner(component);
                }else{
                    component.set("v.showErrorMessage", true); 
                    component.set("v.ErrorMessage",   'Error on server side : Contact System Admin.');                                        
                    helper.toggleSpinner(component);
                }
            }
            else{
                component.set("v.showErrorMessage", true);                                                                                
                helper.toggleSpinner(component);
            }
        });
        $A.enqueueAction(action);        
    },
    
    getFieldValuesAcc : function(component, event, helper) {        
        var action = component.get("c.getAccountDetails");
        action.setParams({
            recordID : component.get("v.recordId")            
        });
        action.setCallback(this, function(response){
            var state = response.getState();  
            if(state == "SUCCESS"){
                var lstAllFieldValues = response.getReturnValue();   
                var list1 = [];
                var list2 = [];
                var count = 0;
                for(var index = 0; index< lstAllFieldValues.length / 2; index++){
                    if(lstAllFieldValues[index].fieldLabel == 'AccountID'){
                        component.set("v.AccountID", lstAllFieldValues[index].fieldValue);
                        continue;
                    }
                    list1.push(lstAllFieldValues[index]);
                    count = count+1;
                }
                for(var index = count; index < lstAllFieldValues.length; index++){
                    if(lstAllFieldValues[index].fieldLabel == 'AccountID'){
                        component.set("v.AccountID", lstAllFieldValues[index].fieldValue);
                        continue;
                    }
                    list2.push(lstAllFieldValues[index]);
                }
                component.set("v.lstWrapper1", list1);    
                component.set("v.lstWrapper2", list2);                   
                helper.getAccountAff(component, event, helper); 
                helper.toggleSpinner(component);
            }
            else{                                                   
                helper.toggleSpinner(component);
            }
        });
        $A.enqueueAction(action);
    },
    
    getFieldValuesOpp : function(component, event, helper) {        
        
        var action = component.get("c.getOppotunityDetails");
        action.setParams({
            recordID : component.get("v.recordId")            
        });
        action.setCallback(this, function(response){
            var state = response.getState();  
            
            if(state == "SUCCESS"){
                
                var lstAllFieldValues = response.getReturnValue();   
                var list1 = [];
                var list2 = [];
                var count = 0;
                for(var index = 0; index< lstAllFieldValues.length / 2; index++){
                    if(lstAllFieldValues[index].fieldLabel == 'Business Unit'){
                        if(!helper.isBlank(lstAllFieldValues[index].fieldValue)){
                            component.set("v.businessUnit", lstAllFieldValues[index].fieldValue);
                        }
                    }
                    if(lstAllFieldValues[index].fieldLabel == 'Closure Request Type'){
                        if(!helper.isBlank(lstAllFieldValues[index].fieldValue)){
                            component.set("v.closureRequestType", lstAllFieldValues[index].fieldValue);
                        }
                    }
                    if(lstAllFieldValues[index].fieldLabel == 'Closure Reason'){
                        if(!helper.isBlank(lstAllFieldValues[index].fieldValue)){
                            component.set("v.ClosureReason", lstAllFieldValues[index].fieldValue);
                        }
                    }
                    if(lstAllFieldValues[index].fieldLabel == 'AccountID'){
                        component.set("v.AccountID", lstAllFieldValues[index].fieldValue);
                        continue;
                    }
                    list1.push(lstAllFieldValues[index]);
                    count = count+1;
                }
                for(var index = count; index < lstAllFieldValues.length; index++){
                    if(lstAllFieldValues[index].fieldLabel == 'Business Unit'){
                        if(!helper.isBlank(lstAllFieldValues[index].fieldValue)){
                            component.set("v.businessUnit", lstAllFieldValues[index].fieldValue);   
                        }
                    }
                    if(lstAllFieldValues[index].fieldLabel == 'Closure Request Type'){
                        if(!helper.isBlank(lstAllFieldValues[index].fieldValue)){
                            component.set("v.closureRequestType", lstAllFieldValues[index].fieldValue);
                        }
                    }
                    if(lstAllFieldValues[index].fieldLabel == 'Closure Reason'){
                        if(!helper.isBlank(lstAllFieldValues[index].fieldValue)){
                            component.set("v.ClosureReason", lstAllFieldValues[index].fieldValue);
                        }
                    }
                    if(lstAllFieldValues[index].fieldLabel == 'AccountID'){
                        component.set("v.AccountID", lstAllFieldValues[index].fieldValue);
                        continue;
                    }
                    list2.push(lstAllFieldValues[index]);
                }
                component.set("v.lstWrapper1", list1);    
                component.set("v.lstWrapper2", list2);                   
                helper.getAccountAff(component, event, helper); 
                helper.toggleSpinner(component);
            }
            else{
                // to stop spinner
                //component.set("v.showErrorMessage", true);                                                                                
                helper.toggleSpinner(component);
            }
        });
        $A.enqueueAction(action);
    },
    
    //Select all affiliations using Select all btn
    selectAllAffiliationsBtn: function(component, event, helper) {
        var checkBtnLabel = component.find("btnID").get("v.label"); 
        var checkAffValue = component.find("checkAff"); 
        var processButton = component.find('disablebuttonid');
        
        if(checkBtnLabel == 'Select All'){
            
            if(!Array.isArray(checkAffValue)){
                checkAffValue.set("v.checked",true);               
            }
            else{           
                for(var index = 0; index < checkAffValue.length; index++){
                    checkAffValue[index].set("v.checked",true);
                }
            }
            processButton.set('v.disabled',false);
            component.find("btnID").set('v.label', 'Deselect All');
        }
        if(checkBtnLabel == 'Deselect All'){
            if(!Array.isArray(checkAffValue)){
                checkAffValue.set("v.checked",false);               
            }
            else{ 
                for(var index = 0; index < checkAffValue.length; index++){
                    checkAffValue[index].set("v.checked",false);
                } 
            }
            processButton.set('v.disabled',true);
            component.find("btnID").set('v.label', 'Select All');
        }
        
    },
    //Select one affiliations
    selectOneAffiliation: function(component, event, helper) {       
        
        var checkAffValue = component.find("checkAff"); 
        var processButton = component.find('disablebuttonid');
        var lstAff = [];
        
        if(!Array.isArray(checkAffValue)){
            if (checkAffValue.get("v.checked") == true) {
                lstAff.push(checkAffValue.get("v.title"));
                component.find("btnID").set('v.label', 'Deselect All');
            }
            else{
                component.find("btnID").set('v.label', 'Select All');
            }
        }
        else{
            for(var index = 0; index < checkAffValue.length; index++){
                if(checkAffValue[index].get("v.checked") == true){
                    lstAff.push(checkAffValue[index].get("v.title"));
                }
            }
        }
        if(lstAff != ''){
            processButton.set('v.disabled',false);
        }
        else{
            processButton.set('v.disabled',true);                       
        }
        
    },
    
    //Select all affiliations    
    /*selectAllAffiliations: function(component, event, helper) {       
        var checkvalue = component.find("selectAll").get("v.checked");        
        var checkAffValue = component.find("checkAff"); 
        var processButton = component.find('disablebuttonid');
        
        if(checkvalue == true){
            for(var i=0; i<checkAffValue.length; i++){
                checkAffValue[i].set("v.checked",true);
            } 
            processButton.set('v.disabled',false);
        }
        else{ 
            for(var i=0; i<checkAffValue.length; i++){
                checkAffValue[i].set("v.checked",false);
            }           
            processButton.set('v.disabled',true);
        }
    },
    
    //Select one affiliations
    selectOneAffiliation: function(component, event, helper) {       
        var checkvalue = component.find("selectAll");        
        var checkAffValue = component.find("checkAff"); 
        var processButton = component.find('disablebuttonid');
        var lstAff = [];
        for(var i=0; i<checkAffValue.length; i++){
            if(checkAffValue[i].get("v.checked") == true){
                lstAff.push(checkAffValue[i].get("v.title"));
            }
        }
        if(lstAff != ''){
            processButton.set('v.disabled',false);
        }
        else{
            processButton.set('v.disabled',true);
            checkvalue.set("v.checked", false);            
        }
        
    },
    
    
    processSelectedAffiliations : function(component, event, helper) {
        var lstAff = [];
        var checkAffValue = component.find("checkAff");
        
        if(!Array.isArray(checkAffValue)){
            if (checkAffValue.get("v.checked") == true) {
                lstAff.push(checkAffValue.get("v.title"));
            }
        }else{
            for (var index = 0; index < checkAffValue.length; index++) {
                if (checkAffValue[index].get("v.checked") == true) {
                    lstAff.push(checkAffValue[index].get("v.title"));
                }
            }
        }
        component.set("v.selectedRecords", lstAff );
        alert('--Selected Affiliation recordId--'+lstAff);                
    },
    */
    
    //Process the selected records and create Case 
    createCaseRecord : function(component, event, helper) {                
        
        helper.toggleSpinner(component); 
        var lstAff = [];
        var checkAffValue = component.find("checkAff");
        
        if(!Array.isArray(checkAffValue)){
            if (checkAffValue.get("v.checked") == true) {
                lstAff.push(checkAffValue.get("v.title"));
            }
        }else{
            for (var index = 0; index < checkAffValue.length; index++) {
                if (checkAffValue[index].get("v.checked") == true) {
                    lstAff.push(checkAffValue[index].get("v.title"));
                }
            }
        }
        component.set("v.selectedRecords", lstAff );
        //alert('--Selected Affiliation recordId--'+lstAff); 
        
        var action = component.get("c.createCase");
        action.setParams({
            lstAffIds : component.get("v.selectedRecords"),  
            accountID : component.get("v.AccountID"),
            closureRequestType : component.get("v.closureRequestType"),
            businessUnit : component.get("v.businessUnit"),
            closureReason : component.get("v.ClosureReason")
        });
        action.setCallback(this, function(response){
            var state = response.getState(); 
            var caseID = response.getReturnValue();
            //alert('----State 4----'+state);
            //alert('----caseID----'+caseID);
            if(state == "SUCCESS"){                                             
                if(caseID.startsWith('500')){
                    var navEvt = $A.get("e.force:navigateToSObject");
                    navEvt.setParams({
                        "recordId": caseID,
                        "slideDevName": "related"
                    });
                    navEvt.fire();
                }
                else{
                    component.set("v.showErrorMessage", true); 
                    component.set("v.ErrorMessage",  caseID);                                        
                    helper.toggleSpinner(component); 
                }
            }
            else{
                component.set("v.showErrorMessage", true); 
                component.set("v.ErrorMessage",  caseID);                                        
                helper.toggleSpinner(component);                
            }
        });
        $A.enqueueAction(action);        
    }    
    
})