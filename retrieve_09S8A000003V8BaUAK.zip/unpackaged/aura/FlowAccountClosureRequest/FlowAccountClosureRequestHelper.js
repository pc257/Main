({
	getAccountAff : function(component, event, helper) {   
        var action = component.get("c.getAccountAffiliations");
        action.setParams({
            accountID : component.get("v.AccountID")            
        });
        action.setCallback(this, function(response){            
            var state = response.getState();            
              if(state == "SUCCESS"){
                var lstAllAff = response.getReturnValue();                                 
                component.set("v.lstAccAffiliations", lstAllAff);                                                                
                var abc1 = component.get("v.lstAccAffiliations");                 
              }
          });
          $A.enqueueAction(action);    
	},
    
    toggleSpinner: function(component){
        var spinner = component.find("loading_spinner");
        $A.util.toggleClass(spinner, "slds-hide");
    },
    
    isBlank : function(val){
    	return(val == undefined || val == null || val == "" || val == '');
	}
})