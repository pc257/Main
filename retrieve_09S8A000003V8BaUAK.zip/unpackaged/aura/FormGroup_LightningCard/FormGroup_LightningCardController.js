({
    handleComponentEvent : function(component, event, helper) {
        var frmname = event.getParam("message");
        console.log('Sending this '+frmname);
        alert(frmname);
		var rq = component.get("c.showForms");
        rq.setParams({ "GroupFrmName" : frmname });
        $A.enqueueAction(rq);
        rq.setCallback(this,function(re) {
            if(re.getState() == "SUCCESS") {
                console.log('Success results from server.');
                var rs = re.getReturnValue();
                console.log(rs);
                component.set("v.Group", rs);
            } else if(re.getErrors().contains("Exception")) {
                console.log("Exception " + re.getErrrors()[0]);
            }
        });
        
        /*
        // set the handler attributes based on event data
        cmp.set("v.messageFromEvent", message);
        var numEventsHandled = parseInt(cmp.get("v.numEvents")) + 1;
        cmp.set("v.numEvents", numEventsHandled);
        */
    }
})