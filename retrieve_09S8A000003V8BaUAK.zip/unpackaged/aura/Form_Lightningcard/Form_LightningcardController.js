({
    doInit : function(component, event, helper) {        
        var browserType = navigator.sayswho= (function(){
            var ua= navigator.userAgent, tem,
                M= ua.match(/(opera|chrome|safari|firefox|msie|trident(?=\/))\/?\s*(\d+)/i) || [];
            if(/trident/i.test(M[1])){
                tem=  /\brv[ :]+(\d+)/g.exec(ua) || [];
                return 'IE '+(tem[1] || '');
            }
            if(M[1]=== 'Chrome'){
                tem= ua.match(/\b(OPR|Edge)\/(\d+)/);
                if(tem!= null) return tem.slice(1).join(' ').replace('OPR', 'Opera');
            }
            M= M[2]? [M[1], M[2]]: [navigator.appName, navigator.appVersion, '-?'];
            if((tem= ua.match(/version\/(\d+)/i))!= null) M.splice(1, 1, tem[1]);
            return M.join(' ');
        })();
        if (browserType.startsWith("IE")) {
            component.set("v.isIE11", true);
        }
        var rq = component.get("c.getFormGroup");
        rq.setCallback(this,function(re) {
            if(re.getState() == "SUCCESS") {
                var result = re.getReturnValue();
                var rs = result.onbFormGroupList;
                console.log(rs);
                component.set("v.Forms", rs);
                component.set("v.SpecialtyCommunityURL", result.communityURL);
                if(rs != null){
                    if(rs[0].Account__c != null || rs[0].Account__c != undefined){
                        component.set('v.accName', rs[0].Account__r.Name);
                        component.set('v.accNumber', rs[0].Account__r.SAP_ECC_ID__c);
                        component.set('v.recordId', rs[0].Account__c);
                        component.set('v.businessType', rs[0].Onboarding__r.RecordType.DeveloperName);
                    }
                }
            } else {
                var errors = re.getError();
                if (errors) {
                    if (errors[0] && errors[0].message) {
                        console.log("Error message: " + errors[0].message);
                        var toastEvent = $A.get("e.force:showToast");
                        toastEvent.setParams({
                            title : 'Error',
                            message: errors[0].message,
                            type: 'error',
                        });
                        toastEvent.fire();
                    }
                }
            }
        });
        $A.enqueueAction(rq);
    }
})