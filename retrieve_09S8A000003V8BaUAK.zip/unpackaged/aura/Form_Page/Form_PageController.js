({
    doInit : function(component, event, helper) {
        var urlString = window.location.href;
        var baseURL = urlString.substring(0, urlString.indexOf("s/"));
        component.set("v.SpecialtyCommunityURL", baseURL);
        var rq = component.get("c.showForms");
        rq.setParams({
            "GroupFrmName": component.get("v.recordId"),
            
        });
        $A.enqueueAction(rq);
        rq.setCallback(this,function(re) {
            if(re.getState() == "SUCCESS") {
                console.log('Success results from server.');
                var rs = re.getReturnValue();
                console.log(rs);
                component.set("v.Group", rs);
                component.set("v.businessType", rs[0].Onboarding__r.RecordType.DeveloperName);
                component.set("v.FormGroupName", rs[0].Onboarding_Form_Group__r.Name);
                component.set("v.FormGroupDescription", rs[0].Onboarding_Form_Group__r.Description__c);
                component.set('v.recordId', rs[0].Onboarding_Form_Group__r.Account__c);
                component.set('v.accName', rs[0].Onboarding_Form_Group__r.Account__r.Name);
                component.set('v.accNumber', rs[0].Onboarding_Form_Group__r.Account__r.SAP_ECC_ID__c);
                
            } else if(re.getErrors().contains("Exception")) {
                console.log("Exception " + re.getErrrors()[0]);
            }
        }); 
    },
    
    handleNavigationComplete : function (component, event, helper){
        //alert("Back Selected");
        var businessType = component.get("v.businessType");
        var vfUrl = '/form-group-standard';
        if(businessType == 'Specialty'){
            vfUrl = '/onboardingformgroup';
        }
        var urlEvent = $A.get("e.force:navigateToURL");
        urlEvent.setParams({
            "url": vfUrl
        });
        urlEvent.fire();
    }
})