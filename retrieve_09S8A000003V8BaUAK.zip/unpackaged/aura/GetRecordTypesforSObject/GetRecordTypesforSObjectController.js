({
    doInit : function(component, event, helper) {
        var objectAPIName = component.get("v.objectApiName");
        //alert('comp alert---');
        var action = component.get("c.getRecordType");
        action.setParams({"objAPIName" : objectAPIName});
        action.setCallback(this, function(response) {
            var state = response.getState();
            //alert('state---'+state);
            if (state === "SUCCESS") {
                var recTypeListResp = response.getReturnValue();
                //alert('recTypeListResp---'+recTypeListResp);
                var recTypeListObj = [];
                var i = 0;
                for(i=0; i < recTypeListResp.length; i++){
                    recTypeListObj.push({
                        'label': recTypeListResp[i].Name,
                        'value': recTypeListResp[i].Id
                    });
                }
                component.set('v.recordTypeList', recTypeListObj);
            }
        });
        $A.enqueueAction(action);
        
    
        
        
        component.set('v.validate', function() {
            var isCmpValid = true;
            if(component.find("picklistfield") && !component.find("picklistfield").reportValidity()){
                isCmpValid = false;
            }
            if(component.find("radiofield") && !component.find("radiofield").reportValidity()){
                isCmpValid = false;
            }
            
            if(isCmpValid) {
                return { isValid: true };
            }
            else {
                return { isValid: false, errorMessage: 'Please select required values' };
            }
        
        });
    },
    handleRecordTypeSelection: function (component, event) {
        //var recordTypeId = component.get('v.selectedRecordTypeId');
        component.set("v.recordTypeSelected",true);
        var recordTypeList =  component.get("v.recordTypeList");
       	recordTypeList.forEach(function(option){
            if(option.value === component.get('v.selectedRecordTypeId')){
                component.set("v.selectedRecordTypeName",option.label);
            }
       	});
		
        if(component.get('v.selectedRecordTypeName') === "Standard"){
            component.set('v.selectedpicklistValue',"CSP")
        }
        if(component.get('v.selectedRecordTypeName') === "Portfolio"){
            component.set('v.selectedpicklistValue',"HS")
        }
        //alert('recordTypeId---'+recordTypeId);
    }
})