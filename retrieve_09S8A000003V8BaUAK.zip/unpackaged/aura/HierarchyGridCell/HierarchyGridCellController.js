({
	init: function(component, event, helper){
		helper.initCellData(component, event, helper);
	}, 
    
    toggleNode: function(component, event, helper){
        var nodeId = event.getSource().get("v.name");
        component.set("v.toggleTreeNode", nodeId);
    }
})