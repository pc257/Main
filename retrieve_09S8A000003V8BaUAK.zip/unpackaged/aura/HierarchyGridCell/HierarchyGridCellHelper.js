({
	initCellData : function(component, event, helper){
		var cellData = [];
        var treeHeader = component.get("v.treeHeader");
        var treeConfig = component.get("v.treeConfig");
        var record = component.get("v.record");
        
        treeHeader.forEach(function(xHead){
            var cellDataX = {};
            Object.keys(xHead).forEach(function(xKey){
                cellDataX[xKey] = xHead[xKey];
                if(xKey == "fieldName"){
                    cellDataX["value"] = "";
                    if(record.hasOwnProperty(xHead[xKey])){
                        cellDataX["value"] = record[xHead[xKey]];
                    }
                    if(xHead[xKey] == "Name"){
                        cellDataX["url"] = "/lightning/r/" + treeConfig.SObjectName + "/" + record.Id + "/view";
                        cellDataX["target"] = "_blank";
                    }
                    if(xHead.type == "Reference" && record.hasOwnProperty(xHead[xKey])){
                        cellDataX["value"] = record[xHead[xKey]].Name;
                        cellDataX["url"] = "/lightning/r/" + xHead.referenceName + "/" + record[xHead[xKey]].Id + "/view";
                        cellDataX["target"] = "_blank";
                    }
                }
            });
            cellData.push(cellDataX);
        });
        component.set("v.cellData", cellData);
	}
})