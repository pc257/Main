({
	init : function(component, event, helper){
        var treeConfig = component.get("v.treeConfig");
		var relationship = component.get("v.relationship");
        var record = component.get("v.record");
        
        var tableData = record[relationship.name];
        var tableHeader = treeConfig[relationship.name];
        
        component.set("v.sObjectName", treeConfig.OtherRelationships[relationship.name]);
        component.set("v.tableHeader", Object.values(tableHeader));
        component.set("v.tableData", tableData);
	}
})