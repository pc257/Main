({
	init: function(component, event, helper){
		helper.initCellData(component, event, helper);
	}
})