({
    afterScriptsLoaded1: function(component, event, helper) {
        console.log("afterScriptsLoaded1");
    },
    afterScriptsLoaded2: function(component, event, helper) {
        console.log("afterScriptsLoaded2");
    },
});