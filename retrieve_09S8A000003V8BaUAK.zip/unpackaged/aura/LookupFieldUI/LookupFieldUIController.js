({
    onChangeLookup: function(component, event, helper) {
        component.set("v.lookupFieldResultId",event.getParam("value"))
		console.log("onChangeLookup: " + event.getParam("value"));
    }
})