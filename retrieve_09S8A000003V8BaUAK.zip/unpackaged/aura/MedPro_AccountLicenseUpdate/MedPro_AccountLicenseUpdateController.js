({
    doInit: function(component, event, helper) {
    var record = component.get("v.record");
    var recordId = component.get("v.recordId");
    var jsonPageParams = {};
    var AccountID_Passthrough = recordId;
    jsonPageParams.Accountid_Passthrough__c = AccountID_Passthrough;
    component.set("v.jsonPageParams", JSON.stringify(jsonPageParams));
  }
 });