({
    invoke : function(component, event, helper){
        //helper.refreshFocusedTab(component, event, helper);
    }
  
})