({
    doInit: function(cmp, event, helper) {
        var responseValue = [];
        var responsefields = [];
        var formObj = cmp.get("v.onboardingFormRec");
        var gName = cmp.get("v.formGroupName");
        var frmDesc = cmp.get("v.formDesc");
        var lineItemsVar = cmp.get("v.onboardingFormLineItems");
        var currentPgNum = cmp.get("v.pageNumber");
        var action = cmp.get("c.getContactScreenMDT");
        action.setParams({"form" : formObj, "grpName" : gName, "formDescription":frmDesc, 
                          "lineItems":lineItemsVar,"currentPg":currentPgNum});
        
        action.setCallback(this, function(response) {
            var state = response.getState();
            if (state === "SUCCESS"){
                responseValue = response.getReturnValue();
                cmp.set("v.leftSideFields",responseValue["Left"]);
                cmp.set("v.rightSideFields",responseValue["Right"]);
            }
        });
        $A.enqueueAction(action);
    },
    handlCancel : function(cmp, event, helper) {
        var formId = cmp.get("v.onboardingFormRec").Id;
        var urlEvent = $A.get("e.force:navigateToURL");
        urlEvent.setParams({
            "url": "/onboarding-form/"+formId
        });
        urlEvent.fire();
    },
    handlCreate : function(cmp, event, helper) {
        var letfFields = cmp.get("v.leftSideFields");
        var rightFields = cmp.get("v.rightSideFields");
        var onboardingFrm = cmp.get("v.onboardingFormRec");
        letfFields = letfFields.concat(rightFields);
        for(var i=0; i<letfFields.length; i++){
            if(letfFields[i].isRequired == true && (letfFields[i].value == null || letfFields[i].value == '')){
                var toastEvent = $A.get("e.force:showToast");
                toastEvent.setParams({
                    title : 'Error',
                    message: 'Please fill all the required fields on the page.',
                    type: 'error',
                });
                toastEvent.fire();
                return false;
            }
            /*if(letfFields[i].displayType == 'Phone' && (letfFields[i].value != null || letfFields[i].value != '')){
                var resp = letfFields[i].value;
                var phoneNoExtRegex = /^[0-9]{3}-[0-9]{3}-[0-9]{4}$|^[0-9]{3}-[0-9]{3}-[0-9]{4}\sext\s[0-9]{4}$/; 
                if(!phoneNoExtRegex.test(resp)){
                    var errMessage = 'Please enter valid '+letfFields[i].fieldLable+'.';
                    var toastEvent = $A.get("e.force:showToast");
                    toastEvent.setParams({
                        title : 'Error',
                        message: errMessage,
                        type: 'error',
                    });
                    toastEvent.fire();
                    return false;
                }
            }*/
        }
        var action = cmp.get("c.insertContact");
        action.setParams({"contactDTOList" : letfFields, "form" : onboardingFrm});
        action.setCallback(this, function(response) {
            var state = response.getState();
            if (state === "SUCCESS"){
                var responseValue = response.getReturnValue();
                if(responseValue["SUCCESS"] != null){
                    var toastEvent = $A.get("e.force:showToast");
                    toastEvent.setParams({
                        title : 'Success',
                        message: responseValue["SUCCESS"] ,
                        type: 'success',
                    });
                    toastEvent.fire();
                    var formId = cmp.get("v.onboardingFormRec").Id;
                    var urlEvent = $A.get("e.force:navigateToURL");
                    urlEvent.setParams({
                        "url": "/onboarding-form/"+formId
                    });
                    urlEvent.fire();
                }else if(responseValue["ERROR"] != null){
                    var toastEvent = $A.get("e.force:showToast");
                    toastEvent.setParams({
                        title : 'Error',
                        message: responseValue["ERROR"] ,
                        type: 'error',
                    });
                    toastEvent.fire();
                }
                
            }
        });
        $A.enqueueAction(action);
    },
    validatePhone : function(component,event,helper){
        var phoneNumber = event.getSource().get("v.value");
        var index = event.getSource().get("v.name");
        var leftFields = component.get("v.leftSideFields");
        var cleanPhoneNumber = helper.formatPhoneText(phoneNumber);
        leftFields[index].value = cleanPhoneNumber
        component.set("v.leftSideFields", leftFields);
    },
    validatePhoneRight : function(component,event,helper){
        var phoneNumber = event.getSource().get("v.value");
        var index = event.getSource().get("v.name");
        var rightFields = component.get("v.rightSideFields");
        var cleanPhoneNumber = helper.formatPhoneText(phoneNumber);
        rightFields[index].value = cleanPhoneNumber
        component.set("v.rightSideFields", rightFields);
    },
})