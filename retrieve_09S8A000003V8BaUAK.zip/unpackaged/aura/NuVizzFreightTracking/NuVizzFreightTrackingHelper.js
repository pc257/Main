({
    getDate: function(component,event,helper){
        var action = component.get("c.getSystemDate");
        action.setCallback(this, function(response) {
            var state = response.getState();
            
            if (state === "SUCCESS"){
                component.set("v.selectedDate", response.getReturnValue());
                this.getAccount(component,event,helper);
            }
            else{
                
            }
        });
        $A.enqueueAction(action);
    },
    getAccount: function(component,event,helper){
        var recordId = component.get("v.recordId");
        var errorMessages = [];
        
        var action = component.get("c.getShippingInformation");
        action.setParams({"recordId":recordId});
        
        action.setCallback(this, function(response) {
            var state = response.getState();
            
            if (state === "SUCCESS"){
                var sfdcObject = response.getReturnValue();
                component.set("v.sfdcObject", sfdcObject);
                
                if(sfdcObject.sapAccountNumber === undefined){
                    errorMessages.push("SAP Account Number is blank");
                }
                if(sfdcObject.accountStatus === undefined){
                    errorMessages.push("Account Status is blank");
                }
                if(sfdcObject.shippingSystemTracking === undefined){
                    errorMessages.push("Shipping System Tracking is blank");
                }
                if(sfdcObject.distributionCenter === undefined){
                    errorMessages.push("Primary Distribution Center is blank");
                }
                
                this.fetchFreightDetails(component,event,helper,errorMessages);
            }
            else{
                
            }
        });
        $A.enqueueAction(action);
    },
    fetchFreightDetails: function(component,event,helper,errorMessages){
        console.log("fetchFreightDetails");
        var sfdcObject = component.get("v.sfdcObject");
        var customerNumber = sfdcObject.sapAccountNumber;
        var selectedDate = component.get("v.selectedDate");
        
        console.log("customerNumber: " + customerNumber);
        console.log("selectedDate: " + selectedDate);
        
        var action = component.get("c.fetchFreightDetails");
        action.setParams({
            "customerNumber":customerNumber,
            "selectedDate":selectedDate
        });
        
        action.setCallback(this, function(response) {
            var state = response.getState();
            var responseItems = response.getReturnValue();
          
            if (state === "SUCCESS"){
                if(responseItems.deliveries){
                    (responseItems.deliveries).forEach(function(item){
                        if(item.timeZone != '' || item.schDelTime != '' || item.expDelTime != ''){
                            if(item.timeZone === "CDT" || item.timeZone === "CST"){
                                item.timeZoneLong = "America/Chicago";
                            }
                            else if(item.timeZone === "EDT" || item.timeZone === "EST"){
                                item.timeZoneLong = "America/New_York";
                            }
                            else if(item.timeZone === "MDT" || item.timeZone === "MST"){
                                item.timeZoneLong = "America/Denver";
                            }
                            else if(item.timeZone === "PDT" || item.timeZone === "PST"){
                                item.timeZoneLong = "America/Los_Angeles";
                            }
                            else if(item.timeZone === "ALA"){
                                item.timeZoneLong = "America/Anchorage";
                            }
                            else if(item.timeZone === "MSTNO"){
                                item.timeZoneLong = "America/Phoenix";
                            }
                            else if(item.timeZone === "HAW"){
                                item.timeZoneLong = "Pacific/Honolulu";
                            }
                            else if(item.timeZone === "UTC-4"){
                                item.timeZoneLong = "America/Puerto_Rico";
                            }
                            
                            if(item.timeDelayedStatus === "Red"){
                                item.truckImage = "/ShipmentStatusRed.png";
                            }
                            else if(item.timeDelayedStatus === "Yellow"){
                                item.truckImage = "/ShipmentStatusYellow.png";
                            }
                            else if(item.timeDelayedStatus === "Green"){
                                item.truckImage = "/ShipmentStatusGreen.png";
                            }
                            else{
                                item.truckImage = "/ShipmentStatusNone.png";
                            }
                        }
                        else{
                            errorMessages.push("We have run into a data parsing issue. Please contact the ABCForce Admin for more information ");
                        }                                   
                    });
                    component.set("v.showDetails", true);
                    component.set("v.response", responseItems.deliveries);
                }
                else if (responseItems.noData === "No Data Found")
                {
                   errorMessages.push("No data found");
                }
                else if ( responseItems.noData === "Connectivity Issue"){
                   errorMessages.push("We have run into a connectivity issue. Please contact ABCForce Admin for more information");
                }
            }
            else{
                errorMessages.push("We have run into a connectivity issue. Please contact ABCForce Admin for more information");
            }
            console.log("error message length: " + errorMessages.length);
            console.log("showDetails: " + component.get("v.showDetails"));
            console.log("showError: " + component.get("v.showError"));

            if(errorMessages.length > 0){
                component.set("v.showDetails", false);
                component.set("v.showError", true);
                component.set("v.errorMessages", errorMessages[0]);
            }
            
        });
        $A.enqueueAction(action);
    },
});