({
    doInit : function(component, event, helper){
        var action = component.get("c.presenceStatusJSON");
        action.setCallback(this,function(result){
            var state = result.getState();
            if(state == "SUCCESS"){
                console.log('result.getReturnValue() : ' + result.getReturnValue());
                component.set("v.presenceStatusJSON", result.getReturnValue());
            }
        });
        $A.enqueueAction(action);
    },
    onWorkAccepted : function(component, event, helper) {
        var workItemId = event.getParam("workItemId");
        var workId = event.getParam("workId");
        const presenceMap = JSON.parse(component.get("v.presenceStatusJSON"));
        var action = component.get("c.isInChatServiceChannel");
        action.setParams({workItemId : workItemId
                         });
        action.setCallback(this, function(data){
            var state = data.getState();
            if(state == "SUCCESS"){
                if(data.getReturnValue()){
                    var omniAPI = component.find("omniToolkit");   
                    omniAPI.getServicePresenceStatusId().then(function(result){
                        if(result.statusId != presenceMap['Busy_Chat']){
                            console.log('Status Id is: ' + result.statusId);
                            var action = component.get("c.updateAgentStatusOnAcceptance");
                            action.setParams({status : result.statusId
                                             });
                            action.setCallback(this,function(result){
                                var state = result.getState();
                                if(state == "SUCCESS")
                                {
                                    console.log('presenceMap busy chat : ' + presenceMap['Busy_Chat']);
                                    omniAPI.setServicePresenceStatus({statusId: presenceMap['Busy_Chat']}).then(function(result){
                                        console.log('Current statusId is: ' + result.statusId);
                                        var action = component.get("c.fetchAccountRelatedToWork");
                                        action.setParams({workItemId : workItemId
                                                         });
                                        action.setCallback(this,function(result){
                                            var state = result.getState();
                                            if(state == "SUCCESS"){
                                                console.log('data.getReturnValue() : here :'+ result.getReturnValue());
                                                if(result.getReturnValue()!=null){
                                                    var workspaceAPI = component.find("workspace");
                                                    workspaceAPI.getFocusedTabInfo().then(function(response){
                                                        var focusedTabId = response.tabId;
                                                        console.log('focusedTabId : ' + focusedTabId);
                                                        workspaceAPI.openSubtab({
                                                            parentTabId : focusedTabId,
                                                            url : '/lightning/r/Account/'+result.getReturnValue()+'/view',
                                                            recordId :result.getReturnValue(),
                                                            focus : false
                                                        });
                                                    }).catch(function(error){
                                                        console.log(error);
                                                    });
                                                    
                                                }
                                            }
                                        });
                                        $A.enqueueAction(action);
                                    }).catch(function(error){
                                        console.log(error);
                                    });
                                }
                            });
                            $A.enqueueAction(action);
                        }
                        else{
                            if(result.statusId == presenceMap['Busy_Chat']){
                                var action = component.get("c.fetchAccountRelatedToWork");
                                action.setParams({workItemId : workItemId
                                                 });
                                action.setCallback(this,function(result){
                                    var state = result.getState();
                                    if(state == "SUCCESS"){
                                        console.log('data.getReturnValue() : here :'+ result.getReturnValue());
                                        if(result.getReturnValue()!=null){
                                            var workspaceAPI = component.find("workspace");
                                            workspaceAPI.getFocusedTabInfo().then(function(response){
                                                var focusedTabId = response.tabId;
                                                console.log('focusedTabId : ' + focusedTabId);
                                                workspaceAPI.openSubtab({
                                                    parentTabId : focusedTabId,
                                                    url : '/lightning/r/Account/'+result.getReturnValue()+'/view',
                                                    recordId :result.getReturnValue(),
                                                    focus : false
                                                });
                                            }).catch(function(error){
                                                console.log(error);
                                            });
                                            
                                        }
                                    }
                                });
                                $A.enqueueAction(action);
                            }
                        }
                    }).catch(function(error) {
                        console.log(error);
                    }); 
                }   
            }
        });
        $A.enqueueAction(action);
    },
    onWorkClosed : function(component, event, helper){
        var workItemId = event.getParam("workItemId");
        var workId = event.getParam("workId");
        const presenceMap = JSON.parse(component.get("v.presenceStatusJSON"));
        var action = component.get("c.isInChatServiceChannel");
        action.setParams({workItemId : workItemId
                         });
        action.setCallback(this,function(data){
            var state = data.getState();
            if(state == "SUCCESS"){	
                if(data.getReturnValue()){
                    var omniAPI = component.find("omniToolkit");
                    omniAPI.getServicePresenceStatusId().then(function(result){
                        console.log('When Work Closed status Id is: ' + result.statusId);
                        const orgStatus = result.statusId;
                        omniAPI.getAgentWorkload().then(function(result){
                            console.log('Agent\'s configured capacity is: ' + result.configuredCapacity);
                            console.log('Agent\'s currently assigned workload is: ' + result.currentWorkload);
                            if((orgStatus == presenceMap['Busy_Chat'] || orgStatus == presenceMap['Unavailable']) && (result.currentWorkload == 0 || result.currentWorkload == 4)){
                            var action = component.get("c.getOrgStatus");
                            action.setCallback(this,function(data){
                                var state = data.getState();
                                if(state == "SUCCESS" && data.getReturnValue()!=null){
                                    omniAPI.setServicePresenceStatus({statusId : data.getReturnValue()}).then(function(result){
                                        console.log('Status set on work closed');
                                    }).catch(function(error){
                                        console.log(error);
                                    });
                                }
                            });
                            $A.enqueueAction(action);
                        }
                        }).catch(function(error){ console.log(error); });       
                    }).catch(function(error){
                        console.log('error : ' +  error);
                    });
                }
            }
        });
        $A.enqueueAction(action);
    }
})