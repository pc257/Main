({
    doInit: function(cmp, event, helper) {
        var responseValue;
        var sPageURL = decodeURIComponent(window.location.search.substring(1));
        var sURLVariables = sPageURL.split('&');
        var accountIdFromURL;
        var totalOnboardingForms;
        for (var i = 0; i < sURLVariables.length; i++) {
            var sParameterName = sURLVariables[i].split('=');
            if(sParameterName[0] == 'accountId'){
                accountIdFromURL = sParameterName[1];
            }
        }
        var specialtyCommunityName;
        var fullLineCommunityName = $A.get("$Label.c.CommunityName");
        var heroHeader = 'Welcome to AmerisourceBergen'; 
        var heroSubHeader = 'Thank you for your consideration. We\'re ready to answer any questions you may have.' ;
        var urlHero = $A.get('$Resource.CommunityHeroImage');
        cmp.set('v.backgroundImageURL',urlHero);
        var action = cmp.get("c.getUserLoginDetails");
        	action.setParams({"accountIdFromURL" : accountIdFromURL});
            action.setCallback(this, function(response) {
                var state = response.getState();
                if (state === "SUCCESS"){
                    responseValue = response.getReturnValue();
                    var redUrl = '/form-group-standard';
                    cmp.set('v.isNewUser', true);
                    cmp.set('v.targetGoLive',responseValue.targetGoLiveDate);
                    cmp.set('v.targetFormCompletion',responseValue.targetFormCompletionDate);
                    cmp.set('v.daysOverDue',responseValue.daysOverDue);
                    cmp.set('v.isPortfolioType', responseValue.isPortfolio);
                    cmp.set('v.status', responseValue.onbStatus);
                    cmp.set('v.onbType', responseValue.onbType);
                    if(responseValue.isPortfolio){
                        heroSubHeader = 'We\'re ready to answer any questions you may have as you monitor the status of your onboards.'
                    }
                    cmp.set('v.locCount', responseValue.locCount);
                    cmp.set('v.heroHeaderText', heroHeader);
                    cmp.set('v.heroSubHeaderText', heroSubHeader);
                    cmp.set('v.cardHeaderText',"Getting Started");
                    cmp.set('v.cardSubHeaderText',"We've made it easier for you to submit all of the required information and documents we need to get you on board.");
                    cmp.set('v.iconURL',"");
                    cmp.set('v.iconStyle',"");
                    specialtyCommunityName = responseValue.communityURL;
                    //alert('specialtyCommunityName-->'+specialtyCommunityName);
                    var onbUser = responseValue.onboardingUserList;
                    var onbUserListObj = [];
                    if(onbUser.length > 0){
                        for(var j=0; j<onbUser.length; j++){
                            var onbUserObj = {};
                            if(onbUser[j].SmallPhotoUrl.includes('/005/')){
                                onbUser[j].SmallPhotoUrl = '';
                            }
                            onbUserObj.User = onbUser[j];
                            onbUserObj.initials = '';
                            if(onbUser[j].FirstName != null){
                                onbUserObj.initials = onbUser[j].FirstName.substring(0, 1) + onbUser[j].LastName.substring(0, 1);
                                onbUserObj.initials = onbUserObj.initials.toUpperCase();
                            }else{
                                onbUserObj.initials = onbUser[j].LastName.substring(0, 2);
                                onbUserObj.initials = onbUserObj.initials.toUpperCase();
                            }
                            onbUserListObj.push(onbUserObj);
                        }
                    }
                    cmp.set('v.onboardingUserListObject',onbUserListObj);
                    var OnbUserListLength;
                    if(responseValue.onboardingUserList != undefined){
                    	OnbUserListLength = responseValue.onboardingUserList.length - 1;    
                    }
                    cmp.set('v.onboardingUserListLength', OnbUserListLength);
                    var progress;
                    var loginHistory = responseValue.userLoginHistory;
                    //debugger;
                    //console.log('login->'+Math.round((responseValue.userLoginHistory[0].Account__r.of_Completed_Forms__c/responseValue.userLoginHistory[0].Account__r.Total_Onboarding_Forms__c)*100));
                    if(loginHistory[0].Account__c != undefined){
                    	progress = Math.round((loginHistory[0].Account__r.of_Completed_Forms__c/loginHistory[0].Account__r.Total_Onboarding_Forms__c)*100);    
                        totalOnboardingForms = loginHistory[0].Account__r.Total_Onboarding_Forms__c;
                        console.log('Progress->'+progress);
                    }
                    if(loginHistory[0].Account__r.Total_Onboarding_Forms__c == 0){
                        progress = 0;
                    }
                    cmp.set('v.progressCompletion', progress);
                    cmp.set('v.userLoginHistoryList',responseValue.userLoginHistory);
                    cmp.set('v.totalOnboardingForms', totalOnboardingForms);
                    if(responseValue.isFormGroup == true){
                        heroHeader = 'Welcome back!';
                        heroSubHeader = 'We\'re here to help make this a smooth onboarding process for you.';
                        cmp.set('v.isNewUser', false);
                        cmp.set('v.isReturningUser', true);
                        cmp.set('v.formGrpName', responseValue.formName);
                        cmp.set('v.cardHeaderText',"Continue Where You Left Off");
                        cmp.set('v.cardSubHeaderText',"Last time you were here, you were working on your <b>"+responseValue.formName+"</b> forms.");
                        cmp.set('v.iconURL',"");
                        cmp.set('v.iconStyle',"");
                        //var fullLineCommunityName = $A.get("$Label.c.CommunityName");
                        if(responseValue.onbType == 'Specialty'){
                            redUrl = specialtyCommunityName+'s/onboarding-form-group/'+responseValue.formId;
                        }else{
                            redUrl = fullLineCommunityName+'s/form/'+responseValue.formId;
                        }
                    }else if(responseValue.isFormGroup == false){
                        heroHeader = 'Welcome back!';
                        heroSubHeader = 'We\'re here to help make this a smooth onboarding process for you.';
                        cmp.set('v.isNewUser', false);
                        cmp.set('v.isReturningUser', true);
                        cmp.set('v.cardHeaderText',"Continue Where You Left Off");
                        cmp.set('v.cardSubHeaderText',"Last time you were here, you were working on your <b>"+responseValue.formName+"</b> forms.");
                        cmp.set('v.iconURL',"");
                        cmp.set('v.iconStyle',"");
                        cmp.set('v.formGrpName', responseValue.formName);
                        if(responseValue.onbType == 'Specialty'){
                            redUrl = specialtyCommunityName + 's/onboarding-form/'+responseValue.formId;
                            //redUrl = 
                        }else{
                            redUrl = fullLineCommunityName +'s/onboarding-form/'+responseValue.formId;
                        }
                    }
                    if(responseValue.onboardingComplete == true){
                        heroHeader = 'Thank you!';
                        heroSubHeader = 'You\'ve completed your onboarding requirements.';
                        cmp.set('v.cardHeaderText',"All of your forms have been submitted.");
                        cmp.set('v.cardSubHeaderText',"AmerisourceBergen associates are working to review your information.<br/>We'll let you know when you've been cleared to begin ordering.");
                        cmp.set('v.iconURL',$A.get('$Resource.CongratsIcon')+"#congrats_icon");
                        cmp.set('v.iconStyle',"height:100px;width:100px;padding-bottom: 10.8%;");
                       
                        cmp.set('v.isOnboardingComplete',true);
                        cmp.set('v.isNewUser', false);
                    }
                    if(responseValue.orderReady == true){
                        heroHeader = 'You\'re ready to order!';
                        heroSubHeader = 'Your onboarding is complete.';
                        cmp.set('v.isOrderReady', true);
                        cmp.set('v.isOnboardingComplete',false);
                        cmp.set('v.isNewUser', false);
                        
                        cmp.set('v.cardHeaderText',"Thank you for choosing AmerisourceBergen");
                        cmp.set('v.cardSubHeaderText',"Check your email for information on how to begin placing orders. We're glad to have you on board!");
                        cmp.set('v.iconURL',$A.get('$Resource.RTOIcon')+"#order_ready");
                        cmp.set('v.iconStyle',"width:180px;margin-left: 44%;");
                    }
                    if(responseValue.isInactive == true){
                        heroHeader = 'This account is inactive.';
                        heroSubHeader = 'You have no assigned tasks at this time.';
                        cmp.set('v.isOrderReady', false);
                        cmp.set('v.isOnboardingComplete',false);
                        cmp.set('v.isNewUser', false);
                        cmp.set('v.isInactive', true);
                        cmp.set('v.cardHeaderText',"Your onboarding process is on hold.");
                        cmp.set('v.cardSubHeaderText',"All forms have been locked. If you have any questions, please contact your Sales Representative.");
                        cmp.set('v.iconURL',$A.get('$Resource.InactiveIcon')+"#inActiveIcon");
                        cmp.set('v.iconStyle',"height:100px;width:70px;padding-bottom: 10.8%;");
                    }
                    cmp.set('v.formDetails', responseValue);
                    cmp.set('v.redirectionUrl', redUrl);
                    cmp.set('v.heroHeaderText', heroHeader);
                    cmp.set('v.heroSubHeaderText', heroSubHeader);
                }else{
                    
                    var errors = response.getError();
                    if (errors) {
                        if (errors[0] && errors[0].message) {
                            alert("Error message: " + errors[0].message);
                        }
                    }
                }
            });
        $A.enqueueAction(action);
    },
	goToNewPage: function(cmp, event, helper) {
        var redirectUrl = cmp.get("v.redirectionUrl");
        var urlEvent = $A.get("e.force:navigateToURL");
        urlEvent.setParams({
            "url": redirectUrl
        });
        urlEvent.fire();
	},
    goToFormGroupPage: function(cmp, event, helper) {
        var redirectUrl = '/form-group-standard';
        var urlEvent = $A.get("e.force:navigateToURL");
        urlEvent.setParams({
            "url": redirectUrl
        });
        urlEvent.fire();
	}
})