({
    loadForms: function(component, event, helper) {
        helper.onLoad(component, event);
    },
    selectAll: function(component, event, helper) {
        var selectedHeaderCheck = event.getSource().get("v.value");
        var getAllId = component.find("boxPack");
        if(! Array.isArray(getAllId)){
            if(selectedHeaderCheck == true){
                component.find("boxPack").set("v.value", true);
            }else{
                component.find("boxPack").set("v.value", false);
            }
        }else{
            // check if select all (header checkbox) is true then true all checkboxes on table in a for loop
            // and set the all selected checkbox length in selectedCount attribute.
            // if value is false then make all checkboxes false in else part with play for loop
            // and select count as 0
            if (selectedHeaderCheck == true) {
                for (var i = 0; i < getAllId.length; i++) {
                    component.find("boxPack")[i].set("v.value", true);
                }
            } else {
                for (var i = 0; i < getAllId.length; i++) {
                    component.find("boxPack")[i].set("v.value", false);
                }
            }
        }
    },
    upadateSite: function(component, event, helper) {
        var updateId = [];
        var getAllId = component.find("boxPack");
        if(! Array.isArray(getAllId)){
            if (getAllId.get("v.value") == true) {
                updateId.push(getAllId.get("v.text"));
            }
        }else{
            for (var i = 0; i < getAllId.length; i++) {
                if (getAllId[i].get("v.value") == true) {
                    updateId.push(getAllId[i].get("v.text"));
                }
            }
        }
        if(updateId.length == 0){
            var toastEvent = $A.get("e.force:showToast");
            toastEvent.setParams({
                title : 'Error',
                message: 'Please select at least one form to remove.',
                type: 'error',
            });
            toastEvent.fire();
            return false;
        }
        helper.SelectedHelper(component, event, updateId);
    
    },
    showAddNewForm : function(component, event, helper) {
        component.set("v.showFormModal", true);
    },
    parentPress : function(component, event, helper) {         
        var objChild = component.find('compB');
        //alert(objChild.get('v.isModalOpen'));
        var state = objChild.get('v.isModalOpen');
        component.set("v.showFormModal", state)
    },
    showSpinner: function (component, event, helper){
        var spinner = component.find("mySpinner");
        $A.util.removeClass(spinner, "slds-hide");
    },
    hideSpinner: function (component, event, helper){
        var spinner = component.find("mySpinner");
        $A.util.addClass(spinner, "slds-hide");
    },
})