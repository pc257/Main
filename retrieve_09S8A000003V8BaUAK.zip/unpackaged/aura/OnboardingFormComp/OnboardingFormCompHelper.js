({
    onLoad: function(component, event) {
        var recordId = component.get("v.recordId");   
        var action = component.get("c.fetchFormList");
        action.setParams({
            recId: recordId
        });
        action.setCallback(this, function(response) {
            var state = response.getState();
            if (state === "SUCCESS") {
                var formList = response.getReturnValue();
                if(formList.length > 0){
                    component.set('v.hideRemoveButton', formList[0].hideRemoveButton);
                    component.set('v.hideAddButton', formList[0].hideAddButton);
                    if(formList[0].sObjectType == 'Account'){
                        component.set('v.showRemoveColumn', false);
                    }
                }
                component.set('v.ListOfForms', formList);
            }
        });
        $A.enqueueAction(action);
    },
    SelectedHelper: function(component, event, RecordsIds) {
        var action = component.get('c.deleteRecord');
        action.setParams({
            "lstRecordId": RecordsIds
        });
         
        action.setCallback(this, function(response) {
            var state = response.getState();
            if (state === "SUCCESS") {
                
                var toastEvent = $A.get("e.force:showToast");
        		toastEvent.setParams({
            	title : 'Success',
            	message: 'Forms Removed Successfully',
            	type: 'Success',
        		});  
                toastEvent.fire();
                
                this.onLoad(component, event);
            }
        });
        $A.enqueueAction(action);
    },
})