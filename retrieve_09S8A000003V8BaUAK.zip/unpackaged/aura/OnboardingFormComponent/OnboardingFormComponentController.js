({
    init : function (component) {
        var flow = component.find("flowData");
        var OnbRecId = component.get("v.recordId");
        //alert('OnbRecId---'+OnbRecId);
        if(OnbRecId != null){
            var inputVariables = [
                {
                    name : "onboardingFomId",
                    type : "String",
                    value: OnbRecId
                }
            ];
            // In the component whose aura:id is "flowData, start your flow
            // and initialize the account sObject variable. Reference the flow's
            // Unique Name.
            //alert('Start flow');
            flow.startFlow("Onboarding_Form_Screen", inputVariables);
            //flow.startFlow("Test_Flow_for_Community");
        }
    }
})