({
   openModel: function(component, event, helper) {
      component.set("v.isModalOpen", true);
      var recId = component.get("v.recordId");
   },
 
   closeModel: function(component, event, helper) {
      component.set("v.isModalOpen", false);
   },
 
   deletenClose: function(component, event, helper) {
      alert('Document deleted :)');
      component.set("v.isModalOpen", false);
   },
})