({
    getForms : function(component, event, helper) {
        component.set('v.myColumns', [
            {label: 'Form Name', fieldName: 'linkName', type: 'url',
             typeAttributes: {label: { fieldName: 'Name' },target: '_blank'}},                
        ]);
            var recId = component.get("v.recordId");
            var action = component.get("c.fetchForms");
            action.setParams({
            	onbId: recId
            });
            action.setCallback(this, function(response){
            	var state = response.getState();
            	if (state === "SUCCESS") {
            		var formList =response.getReturnValue();
            		formList.forEach(function(record){
            			record.linkName = '/'+record.Id;
            		});
            	component.set("v.formList", formList);
            	}
            });
            $A.enqueueAction(action);
	},
            
            handleRowAction : function(component, event, helper){
            var selRows = event.getParam('selectedRows');
            component.set("v.selIDs",selRows);
            },
            
            addForms : function(component, event, helper) {
            var selectedRows = component.get("v.selIDs");
            var formName = '';
            /*for(var j = 0; j < selectedRows.length; j++){
            	if(selectedRows[j].Directly_Send_for_E_Sign__c && selectedRows[j].Name != 'HPG Payment Terms Agreement' &&
                     selectedRows[j].Name != 'VIZIENT Payment Terms Agreement'){
            		checkPractitionerContact = true;
            		formName = selectedRows[j].Name;
        		}
            }
    		if(checkPractitionerContact){
    			if(conList.length == 0){
        			var toastEvent = $A.get("e.force:showToast");
                	toastEvent.setParams({
                	title : 'Error',
                	message: 'Please add Practitioner/ Physician first and then add '+formName+' form',
                	type: 'error',
                	});
                	toastEvent.fire();
                	return false;
				}
			}*/
            if(selectedRows.length == 0){
            var toastEvent = $A.get("e.force:showToast");
            toastEvent.setParams({
            title : 'Error',
            message: 'Please select at least one form to add.',
            type: 'error',
            });
            toastEvent.fire();
            return false;
            }
            
            var action = component.get('c.addOnboardingForms');
            action.setParams({
            formList: selectedRows,
            onbId: component.get("v.recordId")
            });	
            action.setCallback(this, function(response){
            var state = response.getState();
            if (state === "SUCCESS") {
            var resp = response.getReturnValue();
            if(resp == 'Forms Added Successfully'){
            var toastEvent = $A.get("e.force:showToast");
            toastEvent.setParams({
            title : 'Success',
            message: 'Forms Added Successfully',
            type: 'Success',
            });
            toastEvent.fire();
            }else{
            var toastEvent = $A.get("e.force:showToast");
            toastEvent.setParams({
            title : 'Error',
            message: resp,
            type: 'Error',
            });
            toastEvent.fire();
            }
            
            $A.get('e.force:refreshView').fire();
            $A.get("e.force:closeQuickAction").fire();
            helper.helperCloseModel(component, event, helper);
            }
            else if (state === "ERROR") {
            var errors = response.getError();
            if (errors) {
            if (errors[0] && errors[0].message) {
            console.log("Error message: " + 
                        errors[0].message);
        }
    } 
    else {
    console.log("Unknown Error");
}
 }
 });
$A.enqueueAction(action);
},
	closeModel: function(component, event, helper) {
      helper.helperCloseModel(component, event, helper);
    },
        showSpinner: function (component, event, helper){
        var spinner = component.find("mySpinner");
        $A.util.removeClass(spinner, "slds-hide");
    },
    hideSpinner: function (component, event, helper){
        var spinner = component.find("mySpinner");
        $A.util.addClass(spinner, "slds-hide");
    },
})