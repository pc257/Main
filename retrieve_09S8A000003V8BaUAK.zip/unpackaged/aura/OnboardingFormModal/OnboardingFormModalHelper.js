({
	helperCloseModel: function(component, event, helper) {
      // Set isModalOpen attribute to false 
      component.set("v.isModalOpen", false);
      var vx = component.get("v.method");
      $A.enqueueAction(vx);
    },
})