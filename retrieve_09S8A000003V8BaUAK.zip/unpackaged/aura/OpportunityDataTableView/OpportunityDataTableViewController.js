({
    /*
     * This finction defined column header
     * and calls getAccounts helper method for column data
     * editable:'true' will make the column editable
     * */
    doInit : function(component, event, helper) { 
        
        var actions = [
            { label: 'Show details', name: 'show_details' },
            { label: 'Delete', name: 'delete' }
        ];
        
        component.set('v.columns', [
            {type:  'action', typeAttributes: { rowActions: actions } },
            {label: 'Opportunity Name', fieldName: 'Name', editable:'true', type: 'text'},
            {label: 'Account ID', fieldName: 'AccountId', editable:'true', type: 'text'},
            {type:  'button', typeAttributes: { label: 'View Definitive Data', name: 'viewdefinitivedata', title: 'viewdefinitivedata', disabled: false, value: 'viewdefinitivedata'}}
        ]);        
        helper.getOpportunities(component, helper);
    },
    
    /*
     * This function is calling saveDataTable helper function
     * to save modified records
     * */
    onSave : function (component, event, helper) {
        helper.saveDataTable(component, event, helper);
    },
    handleRowAction: function (cmp, event, helper) {
        console.log('click kela click!!');
        alert('Click kela click!!');
        var action = event.getParam('action');
        var row = event.getParam('row');
        var accountId = row.AccountId;
        alert('Account maane khata!! : '+accountId);
        console.log('sohel action : '+JSON.stringify(action));
        console.log('sohel row : '+JSON.stringify(row));
        if(action.name == 'viewdefinitivedata'){
			//cmp.set("v.isOpen", true);
			helper.openModel(cmp, event, helper, accountId);
        }
        
    },
    openModel: function(cmp, event, helper) {
        alert('Modal open zhal re!!!');
        // for Display Model,set the "isOpen" attribute to "true"
       
        cmp.set("v.isOpen", true);
    },
    
    closeModel: function(component, event, helper) {
        // for Hide/Close Model,set the "isOpen" attribute to "Fasle"
        component.set("v.isOpen", false);
    },
    
    likenClose: function(component, event, helper) {
        // Display alert message on the click on the "Like and Close" button from Model Footer
        // and set set the "isOpen" attribute to "False for close the model Box.
        alert('thanks for like Us :)');
        component.set("v.isOpen", false);
    }

})