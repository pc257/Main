({
    init : function(component, event, helper) {
        helper.createOpportunity(component, event, helper);
    },
    closeModel: function(component, event, helper) {
        component.set("v.isOpen", false);
        var aId = component.get( "v.pageReference" ).state.c__accountId;
        if(aId == null){
            aId = "";
        }
        if(aId === ""){
            /*var homeEvent = $A.get("e.force:navigateToObjectHome");  
            homeEvent.setParams({  
                "scope": "Opportunity"  
            });  
            homeEvent.fire();*/
            
            helper.navigateToURL('/lightning/o/Account/list');
            
        }else{
            /*var recEvent = $A.get("e.force:navigateToSObject");  
            recEvent.setParams({  
                "recordId": aId,
                "slideDevName": "related"
            });  
            recEvent.fire();*/
            
            helper.navigateToURL('/lightning/r/Account/'+ aId +'/view');

        }
        
    }
})