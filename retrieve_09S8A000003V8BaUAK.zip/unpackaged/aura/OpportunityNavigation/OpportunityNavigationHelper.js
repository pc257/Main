({
    createOpportunity : function(component, event, helper) {
        var accId = component.get( "v.pageReference" ).state.c__accountId;
        if(accId == null){
            accId = '';
        }
        var action = component.get("c.checkCustomPermissionAccess");
        action.setCallback(this, function(response){
            console.log('response'+JSON.stringify(response));
            var state = response.getState();
            if(state === "SUCCESS"){
                var resp = response.getReturnValue();
                component.set("v.isAccess", resp);
                component.set("v.isOpen", true);
                if(resp){
                    
                    var flow = component.find("flowData");
                    var inputVariables = [
                        {
                            name : "var_AccountId",
                            type : "String",
                            value : accId
                        }
                    ];
                    flow.startFlow("HS_SS_Opportunity_Creation",inputVariables);
                }
            }else{
                var errors = response.getError();
                var errorMsg = '';
                if (errors) {
                    if (errors[0] && errors[0].message) {
                        errorMsg = "Error message: " + errors[0].message;
                    }
                } else {
                    errorMsg = 'Some issue occurred. Contact your Administrator!';
                }
                
                var toastEvent = $A.get("e.force:showToast");
                toastEvent.setParams({
                    title: 'Error',
                    type: 'error',
                    message: errorMsg
                });
                toastEvent.fire();
            }
        });
        $A.enqueueAction(action);
    },
    navigateToURL : function(url){
        var hiddenElement = document.createElement('a');
        hiddenElement.href = url;
        hiddenElement.target = '_self'; 
        document.body.appendChild(hiddenElement);
        hiddenElement.click();
    }
})