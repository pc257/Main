({
    doInit : function(component, event, helper) {
        //alert('picklist component called---'+component.get("v.fieldApiName")+'---'+component.get("v.objectApiName")+'---'+component.get("v.selectedRecordTypeId"));
        if(sessionStorage.getItem("isVisited")){
             if(sessionStorage.getItem(component.get("v.fieldApiName"))){
                component.set("v.selectedpicklistValue",sessionStorage.getItem(component.get("v.fieldApiName")));
                sessionStorage.removeItem(component.get("v.fieldApiName"));
            }
            
            if(sessionStorage.getItem(component.get("v.fieldApiName1"))){
                component.set("v.selectedpicklistValue1",sessionStorage.getItem(component.get("v.fieldApiName1")));
                sessionStorage.removeItem(component.get("v.fieldApiName1"));
            }
            
            if(sessionStorage.getItem(component.get("v.fieldApiName2"))){
                component.set("v.selectedpicklistValue2",sessionStorage.getItem(component.get("v.fieldApiName2")));
                sessionStorage.removeItem(component.get("v.fieldApiName2"));
            }
             if(sessionStorage.getItem(component.get("v.fieldApiName3"))){
                component.set("v.selectedpicklistValue3",sessionStorage.getItem(component.get("v.fieldApiName3")));
                sessionStorage.removeItem(component.get("v.fieldApiName3"));
            }
            //sessionStorage.removeItem("isVisited");
        }
           
        
        component.set('v.validate', function() {
            var isCmpValid = true;
            sessionStorage.setItem("isVisited","true");
            if(!component.get("v.Isdependentpicklist")){
                if(component.find("field") && !component.find("field").reportValidity()){
                    isCmpValid = false;
                }else{
                    if(component.find("field") && component.find("field").get("v.value") != undefined)
                    	sessionStorage.setItem(component.get("v.fieldApiName"), component.find("field").get("v.value"));
                }
            }
            
            if(component.get("v.Isdependentpicklist")){
                /*if(component.find("field1") && !component.find("field1").reportValidity() 
                   || component.find("field2") && !component.find("field2").reportValidity()
                   || component.find("field3") && !component.find("field3").reportValidity()){
                    isCmpValid = false;
                    component.find("field1").setErrors("Please Select Value");
                }*/
                
                if(component.find("field1") && !component.find("field1").reportValidity()){
                    isCmpValid = false;
                    component.find("field1").setErrors("Please Select Value");
                }else{
                     if(component.find("field1") && component.find("field1").get("v.value") != undefined)
                    	sessionStorage.setItem(component.get("v.fieldApiName"), component.find("field1").get("v.value"));
                }
                
                if(component.find("field2") && !component.find("field2").reportValidity()){
                    isCmpValid = false;
                    component.find("field2").setErrors("Please Select Value");
                }else{
                     if(component.find("field2") && component.find("field2").get("v.value") != undefined)
                    	sessionStorage.setItem(component.get("v.fieldApiName2"), component.find("field2").get("v.value"));
                } 
                
                if(component.find("field3") && !component.find("field3").reportValidity()){
                    isCmpValid = false;
                    component.find("field3").setErrors("Please Select Value");
                }else{
                     if(component.find("field3") && component.find("field3").get("v.value") != undefined)
                    	sessionStorage.setItem(component.get("v.fieldApiName3"), component.find("field3").get("v.value"));
                } 
                
                
            }
           
            if(isCmpValid) {
                return { isValid: true };
            }
            else {
                return { isValid: false, errorMessage: 'Please select required values' };
            }});
        
    }
})