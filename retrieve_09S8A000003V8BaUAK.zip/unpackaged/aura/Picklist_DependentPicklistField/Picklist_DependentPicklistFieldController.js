({
	refreshcmp : function(component, event, helper) {
		$A.get('e.force:refreshView').fire();
        console.log("In Refresh...");
	}
})