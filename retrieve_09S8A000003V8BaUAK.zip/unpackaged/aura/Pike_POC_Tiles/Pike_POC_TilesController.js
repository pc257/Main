({
    doInit: function(component,event){

    },
    addContact: function(component,event,helper){
        //construct a dummy contact for insert for UI
        //These just needs to be empty strings
        function Contact() {
            String.random = function (length) {
                let radom13chars = function () {
                    return Math.random().toString(16).substring(2, 15)
                }
                let loops = Math.ceil(length / 13)
                return new Array(loops).fill(radom13chars).reduce((string, func) => {
                    return string + func()
                }, '').substring(0, length)
            }

            this.FirstName = String.random(5);
            this.LastName = String.random(7);
            this.Email = String.random(8) + "@" + String.random(8) + ".com";
            this.Phone = Math.floor(100000000 + Math.random() * 900000000);
        }

        //populate values
        var contacts = component.get("v.contacts");
        var newContact = new Contact();
        contacts.push(newContact);
        component.set("v.contacts", contacts);
        component.set("v.selectedContact", newContact);

        //update click colors
        helper.removeColors();
    },
    clickContact: function(component,event,helper){
        var index = event.currentTarget.id;
        console.log("index: " + index );

        var contacts = component.get("v.contacts");
        var selectedContact = contacts[index];
        component.set("v.selectedContact",selectedContact);

        //update click colors
        helper.removeColors();
        helper.addColor(index);
    }
});