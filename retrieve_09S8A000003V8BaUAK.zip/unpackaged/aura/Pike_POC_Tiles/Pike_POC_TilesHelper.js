({
    removeColors: function(){
        var els = document.querySelectorAll(".clickColor")
        console.log("els: " + els.length);
        for (var i = 0; i < els.length; i++) {
            els[i].classList.remove("clickColor")
        }
    },
    addColor: function(index){
        var elem = document.getElementById(index);
        $A.util.addClass(elem, 'clickColor');
    }
});