({
	doInitGetCases : function(component, event, helper) {
		var action = component.get("c.fetchOpenActivitesRecords");
        var parentIdVal = component.get("v.parentIdVal");
        action.setParams({
            parentIdValue : parentIdVal
        });
        action.setCallback(this, function(response) {
            var state = response.getState();
            if(state === "SUCCESS"){
                var responseVal = response.getReturnValue();
                component.set( "v.cases", responseVal.cases);
                component.set( "v.tasks", responseVal.openTasks);
                component.set( "v.events", responseVal.openEvents);
                component.set( "v.onboard", responseVal.onboard);
            }else if(state === "ERROR"){
                var errors = response.getError();
                if(errors){
                    if(errors[0] && errors[0].message){
                        console.log("Error message: " + errors[0].message);
                    }
                }else{
                    console.log("Unknown error");
                }
            }
        });
         $A.enqueueAction(action);    
	}
})