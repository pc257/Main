({
   next : function(component, event, helper) {
      // get the current selected tab value
       var currentTab1 = component.get("v.selTabId");
       console.log("currentTab1 : :" + currentTab1);
       
       var currentTab = currentTab1.split(',');
       console.log("currentTab : :" + currentTab);
        if(currentTab == 'red'){
          component.set("v.selTabId" , 'blue');   
        }else if(currentTab == 'blue'){
          component.set("v.selTabId" , 'green');     
        }else if(currentTab == 'green'){
          component.set("v.selTabId" , 'yellow');             
        }else if(currentTab == 'yellow'){
             alert('Complete !');  
        } 
	}
});