({
	doInit : function(component, event, helper) {
		var recordID = component.get("v.recordId"); 
        var accRecordID = component.get("v.accountRecordID"); 
        console.log('--recordID----'+recordID);
        console.log('--accRecordID----'+accRecordID);
        var action;
        
        if(accRecordID != ''){           
            
             action = component.get("c.checkRequiredFieldsFromAccount");
             action.setParams({
                recordID : accRecordID                     
            });
        }  
        else{
              action = component.get("c.checkRequiredFields");
                 action.setParams({
                recordID : recordID                     
            });
        }
        //var action = component.get("c.checkRequiredFields"); // checkRequiredFieldsFromAccount
       
        action.setCallback(this, function(response){
            var state = response.getState();  
            component.set("v.showSpinner", false); 
            if(state == "SUCCESS"){
                var recVal = response.getReturnValue();                                                               
                var errorMsg = component.get("v.showErrorMsg");  
                component.set("v.showErrorMsg",recVal.errorMsg);                                
                
                var errorType;
                if(recVal.errorType == 'success'){
                    errorType = 'slds-notify slds-notify_toast slds-theme_success';
                }
                else if(recVal.errorType == 'warning'){
                    errorType = 'slds-notify slds-notify_toast slds-theme_warning';
                }
                    else if(recVal.errorType == 'error'){
                        errorType = 'slds-notify slds-notify_toast slds-theme_error';
                    }
                component.set("v.showErrorType",errorType);                                
                                               
            } else if(state == "ERROR"){
                console.log('Error in calling server side action');
            }
        });
        $A.enqueueAction(action);
	}
          
})