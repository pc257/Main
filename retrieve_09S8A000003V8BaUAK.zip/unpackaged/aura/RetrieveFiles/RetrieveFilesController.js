({
    init: function (cmp, event, helper) {
        
        var idRec = cmp.get("v.recordId")
        /*if(idRec.startsWith("a1q"))
        {
            cmp.set('v.showUploadButton',true);
            cmp.set('v.fromFormPage' ,false);
           
        }*/
        cmp.set('v.mycolumns', [
            { label: 'Name',fieldName:'FileLeafRef',type: 'text'},
            //{ label: 'Download', fieldName: 'EncodedAbsUrl',type: 'button', initialWidth: 0, typeAttributes: { label: '', name: 'download_file', title: '',iconName: "action:download"}},
            // {label: 'Download',fieldName: 'File_x0020_Type',type: 'button', initialWidth: 0, typeAttributes: { label: '', name: 'download_file', title: '',iconName: "action:download"}},
            { label: 'Preview', fieldName: 'FileRef', type: 'button',initialWidth: 0, typeAttributes: { label: '', name: 'preview_file', title: '',iconName: "utility:preview"}},
            {label: 'Delete',fieldName: 'DocURL',type: 'button', initialWidth: 0, typeAttributes: { label: '', name: 'delete_details', title: '',iconName: "action:delete"}}
            
        ]);
        helper.fetchData(cmp);
        //helper.getParentId(cmp);

    },
    
    
    handleRowAction: function (component, event, helper) {
        var action = event.getParam('action');
        var row = event.getParam('row');
        //var selectedRows = event.getParam('selectedRows');
        switch (action.name) {
            case 'view_details':
                helper.showRowDetails(row);
                break;
            case 'delete_details':
                var strConfirmtion = '';
                if (confirm("Are you sure you want to delete?")) {
                    strConfirmtion = "OK";
                } else {
                    strConfirmtion = "Cancel";
                }
                if (strConfirmtion == 'OK'){
                    helper.deleteRow(component,row);
                }
                break;
            case 'download_file':
                helper.downloadFile(component,row);
                break; 
            case 'preview_file':
                helper.previewFile(component,row);
                break;   
            default:
                helper.showRowDetails(row);
                break;
        }
    },
    
    handleFilesChange: function(component, event, helper) {      
        
        if (component.find("fileId").get("v.files").length > 0) {
            helper.uploadHelper(component, event);
        } 
    },
})