({
    fetchData: function (cmp) {
        var action = cmp.get('c.fetchRecords');
        var idRec = cmp.get("v.recordId")
        console.log('=======>',idRec);
        var fromPage = cmp.get('v.fromFormPage');
        action.setParams({ "recordID" : idRec, "isFormId" : fromPage});
        action.setCallback(this, $A.getCallback(function (response) {
            var state = response.getState();
            if (state === "SUCCESS") {
                if(response.getReturnValue() != null) {
                    var records = response.getReturnValue();  
                    cmp.set("v.mydata",records);
                } else {
                    cmp.set("v.noResults", "No records to display");
                }
            } else if (state === "ERROR") {
                var errors = response.getError();
                console.error(errors);
                cmp.set("v.noResults", "No records to display");
                cmp.set("v.mydata","");

            }
        }));
        $A.enqueueAction(action);
        
        
    },
    
    MAX_FILE_SIZE: 4500000, //Max file size 4.5 MB 
    CHUNK_SIZE: 750000,      //Chunk Max size 750Kb 
    
    
    uploadHelper: function(component, event) {
        
        // start/show the loading spinner   
        //component.set("v.showLoadingSpinner1", true);
        // get the selected files using aura:id [return array of files]
        var fileInput = event.getParam("files"); //component.find("fileId").get("v.files");
        // get the first file using array index[0]  
        var file = fileInput[0];
        var self = this;
        // check the selected file size, if select file size greter then MAX_FILE_SIZE,
        // then show a alert msg to user,hide the loading spinner and return from function  
        /*if (file.size > self.MAX_FILE_SIZE) {
            //component.set("v.showLoadingSpinner1", false);
            component.set("v.fileName1", 'Alert : File size cannot exceed ' + self.MAX_FILE_SIZE + ' bytes.\n' + ' Selected file size: ' + file.size);
            return;
        }
        */
        // create a FileReader object 
        var objFileReader = new FileReader();
        // set onload function of FileReader object   
        objFileReader.onload = $A.getCallback(function() {
            var fileContents = objFileReader.result;
            var base64 = 'base64,';
            var dataStart = fileContents.indexOf(base64) + base64.length;
            
            fileContents = fileContents.substring(dataStart);
            // call the uploadProcess method 
            self.uploadProcess(component, file, fileContents);
        });
        
        objFileReader.readAsDataURL(file);
        
    },
    
    uploadProcess: function(component, file, fileContents) {
        
        // set a default size or startpostiton as 0 
        var startPosition = 0;
        // calculate the end size or endPostion using Math.min() function which is return the min. value   
        var endPosition = Math.min(fileContents.length, startPosition + this.CHUNK_SIZE);
        
        // start with the initial chunk, and set the attachId(last parameter)is null in begin
        this.uploadInChunk(component, file, fileContents, startPosition, endPosition, '');
    },
    
    uploadInChunk: function(component, file, fileContents, startPosition, endPosition, attachId) {
        // call the apex method 'saveChunk'
        
        var getchunk = fileContents.substring(startPosition, endPosition);
        
        var idRec = cmp.get("v.recordId")
        var formId = '';
        var action = component.get("c.getOAuthToken");
        action.setParams({
            fileName: file.name,
            fileContent:getchunk,
            fileType: file.type,
            onboardingId : idRec,
            formId : formId
            
        });
        
        // set call back 
        action.setCallback(this, function(response) {
            // store the response / Attachment Id   
            attachId = response.getReturnValue();
            var state = response.getState();
            if (state === "SUCCESS") {
                // update the start position with end postion
                startPosition = endPosition;
                endPosition = Math.min(fileContents.length, startPosition + this.CHUNK_SIZE);
                // check if the start postion is still less then end postion 
                // then call again 'uploadInChunk' method , 
                // else, diaply alert msg and hide the loading spinner
                if (startPosition < endPosition) {
                    this.uploadInChunk(component, file, fileContents, startPosition, endPosition, attachId);
                } else {
                    component.set("v.showLoadingSpinner1", false);
                }
                // handel the response errors        
            } /*else if (state === "INCOMPLETE") {
            } else if (state === "ERROR") {
                var errors = response.getError();
                if (errors) {
                    if (errors[0] && errors[0].message) {
                        console.log("Error message: " + errors[0].message);
                    }
                } else {
                    console.log("Unknown error");
                }
            }*/
        }); 
        // enqueue the action
        $A.enqueueAction(action);
    },
    deleteRow : function(component,row) {
       debugger;
        var fileName = row.FileLeafRef ;
        var action = component.get("c.deleteFile");
        action.setParams({
            fileName: fileName ,
            path : row.FileRef
        });
        
        // set call back 
        action.setCallback(this, function(response) {
            // store the response / Attachment Id   
            var state = response.getState();
            if (state === "SUCCESS") {
                // update the start position with end postion
                var response = response.getReturnValue();
                if (response == 200){
                    var toastEvent = $A.get("e.force:showToast");
                    toastEvent.setParams({
                        title : 'Success',
                        message: 'File deleted successfully',
                        type: 'success',
                    });
                    toastEvent.fire();
                }
                this.fetchData(component);

                // document.location.reload(true);
                // handel the response errors        
            } /*else if (state === "INCOMPLETE") {
                alert("From server: " + response.getReturnValue());
            } else if (state === "ERROR") {
                var errors = response.getError();
                if (errors) {
                    if (errors[0] && errors[0].message) {
                        console.log("Error message: " + errors[0].message);
                    }
                } else {
                    console.log("Unknown error");
                }
            }*/
        }); 
        // enqueue the action
        $A.enqueueAction(action);
    },
    downloadFile : function(component,row) {
        //window.open(https://amerisourcebergen.sharepoint.com/sites/EnterpriseSecurityPOC/Shared%20Documents/CreditApplForms/DriverLicenses/TestDemoFile23.txt"")
        var fileName = row.EncodedAbsUrl ;
        console.log('===========',fileName);
        var urlEvent = $A.get("e.force:navigateToURL");
        urlEvent.setParams({
            "url": fileName
        });
        urlEvent.fire();  
    },
    previewFile : function(component,row) {
        console.log('*******=>',row.FileRef);
        // window.open("https://amerisourcebergen.sharepoint.com/sites/EnterpriseSecurityPOC/Shared%20Documents/Chirag%20TEST1.docx?web=1","MsgWindow", "width=600,height=500");
        var websitelink = "https://amerisourcebergen.sharepoint.com" + row.FileRef + "?web=1";
        console.log('*******=>',websitelink);
        // window.open("https://amerisourcebergen.sharepoint.com/sites/EnterpriseSecurityPOC/Shared%20Documents/Chirag%20TEST1.docx?web=1","MsgWindow", "width=600,height=500");
        window.open(websitelink,"ViewWindow", "width=600,height=500");  
    },
    uploadHelper: function(component, event) {
        // alert('hi uploadHelper');
        
        // start/show the loading spinner   
        component.set("v.showLoadingSpinner", true);
        // get the selected files using aura:id [return array of files]
        var fileInput = component.find("fileId").get("v.files");
        // get the first file using array index[0]  
        var file = fileInput[0];
        var self = this;
        // check the selected file size, if select file size greter then MAX_FILE_SIZE,
        // then show a alert msg to user,hide the loading spinner and return from function  
        if (file.size > self.MAX_FILE_SIZE) {
            component.set("v.showLoadingSpinner", false);
            return;
        }
        
        // create a FileReader object 
        var objFileReader = new FileReader();
        // set onload function of FileReader object   
        objFileReader.onload = $A.getCallback(function() {
            var fileContents = objFileReader.result;
            //   alert('fileContents--' + fileContents);
            var base64 = 'base64,';
            var dataStart = fileContents.indexOf(base64) + base64.length;
            
            fileContents = fileContents.substring(dataStart);
            // call the uploadProcess method 
            // alert('hi befre')
            self.uploadProcess(component, file, fileContents);
        });
        
        objFileReader.readAsDataURL(file);
    },
    
    uploadProcess: function(component, file, fileContents) {
        // alert('hi uploadProcess' + fileContents);
        
        // set a default size or startpostiton as 0 
        var startPosition = 0;
        // calculate the end size or endPostion using Math.min() function which is return the min. value   
        var endPosition = Math.min(fileContents.length, startPosition + this.CHUNK_SIZE);
        
        // start with the initial chunk, and set the attachId(last parameter)is null in begin
        this.uploadInChunk(component, file, fileContents, startPosition, endPosition, '');
    },
    
    uploadInChunk: function(component, file, fileContents, startPosition, endPosition, attachId) {
        
        var getchunk = fileContents.substring(startPosition, endPosition);
        
        var url = new URL(window.location.href);
        var id = url.href.split("/");
                
        var onboardId = component.get("v.recordId");
        var formId = component.get("v.formId");
        
        var action = component.get("c.getOAuthToken");
        action.setParams({
            fileName: file.name,
            fileContent:getchunk,
            fileType: file.type,
            onboardingId :  onboardId,
            formId : formId
        });
        
        // set call back 
        action.setCallback(this, function(response) {
            // store the response / Attachment Id   
            attachId = response.getReturnValue();
            var state = response.getState();
            if (state === "SUCCESS") {
                // update the start position with end postion
                startPosition = endPosition;
                endPosition = Math.min(fileContents.length, startPosition + this.CHUNK_SIZE);
                // check if the start postion is still less then end postion 
                // then call again 'uploadInChunk' method , 
                // else, diaply alert msg and hide the loading spinner
                if (startPosition < endPosition) {
                    this.uploadInChunk(component, file, fileContents, startPosition, endPosition, attachId);
                } else {
                    var toastEvent = $A.get("e.force:showToast");
                    toastEvent.setParams({
                        title : 'Success',
                        message: 'Your File is uploaded successfully',
                        type: 'success',
                    });
                    toastEvent.fire();
                    //alert('Your File is uploaded successfully');
                    component.set("v.showLoadingSpinner", false);
                    this.fetchData(component);
                }
                // handel the response errors        
            } /*else if (state === "INCOMPLETE") {
                //alert("From server: " + response.getReturnValue());
            } else if (state === "ERROR") {
                var errors = response.getError();
                if (errors) {
                    if (errors[0] && errors[0].message) {
                        console.log("Error message: " + errors[0].message);
                    }
                } else {
                    console.log("Unknown error");
                }
            }*/
        }); 
        // enqueue the action
        $A.enqueueAction(action);
    },
    
    getParentId : function(component) {
        var actionForm = component.get("c.getParentId");
        
        actionForm.setParams({
            onboardingId :  component.get("v.recordId")
        });
        
        actionForm.setCallback(this, function(response) {
            var state = response.getState();
            if (state === "SUCCESS") {
                component.set("v.formId",response.getReturnValue()); 
            } 
        }); 
        $A.enqueueAction(actionForm);
    }
    
})