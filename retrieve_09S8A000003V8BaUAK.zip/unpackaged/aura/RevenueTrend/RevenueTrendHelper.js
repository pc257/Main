({
    fetchMonthlyData: function (component, helper) {
        var action = component.get("c.getMonthlyRevenue");
        action.setParams({
            'accountECCId' : component.get("v.accountECCId")
        });
        action.setCallback(this,function(response) {
            component.set('v.loaded', false);
            var state = response.getState();
            if(state === "SUCCESS"){
                var resp = JSON.parse(response.getReturnValue());
                if(resp){
                    var records = [];
                    resp.forEach(function setRecords(item){
                        var record = {};
                        record["name"] = item.Name;
                        record["accountName"] = item.accountName;
                        record["sapECCId"] = item.sapECCId;
                        record["month"] = item.month;
                        record["totalRevenue"] = item.totalRevenue;
                        records.push(record);
                    });
                    component.set("v.data", records);
                    component.set("v.showDetails", true);
                }else{
                    var errorMsg = 'NO Data found!!!';
                    var toastEvent = $A.get("e.force:showToast");
                    toastEvent.setParams({
                        title: 'Error',
                        type: 'error',
                        message: errorMsg
                    });
                    toastEvent.fire();     
                }
            }else{
                var errorMsg = action.getError()[0].message;
                var toastEvent = $A.get("e.force:showToast");
                toastEvent.setParams({
                    title: 'Error',
                    type: 'error',
                    message: errorMsg
                });
                toastEvent.fire();
            }
        });
        $A.enqueueAction(action);
    },
    fetchWeeklyData: function (component, helper) {
        var action = component.get("c.getWeeklyRevenue");
        action.setParams({
            'accountECCId' : component.get("v.accountECCId")
        });
        action.setCallback(this,function(response) {
            component.set('v.loaded', false);
            var state = response.getState();
            if(state === "SUCCESS"){
                var resp = JSON.parse(response.getReturnValue());
                console.log(response.getReturnValue());
                console.log(JSON.stringify(resp));
                if(resp){
                    var records = [];
                    resp.forEach(function setRecords(item){
                        var record = {};
                        record["name"] = item.Name;
                        record["accountName"] = item.accountName;
                        record["sapECCId"] = item.sapECCId;
                        record["week"] = item.week;
                        record["totalRevenue"] = item.totalRevenue;
                        records.push(record);
                    });
                    //alert(JSON.stringify(records));
                    component.set("v.weeklyData", records);
                    component.set("v.showDetails", true);
                }else{
                    var errorMsg = 'NO Data found!!!';
                    var toastEvent = $A.get("e.force:showToast");
                    toastEvent.setParams({
                        title: 'Error',
                        type: 'error',
                        message: errorMsg
                    });
                    toastEvent.fire();     
                }
            }else{
                var errorMsg = action.getError()[0].message;
                var toastEvent = $A.get("e.force:showToast");
                toastEvent.setParams({
                    title: 'Error',
                    type: 'error',
                    message: errorMsg
                });
                toastEvent.fire();
            }
        });
        $A.enqueueAction(action);
    },
    convertArrayOfObjectsToCSV : function(component, dkeys, columns, dataSet){
        // declare variables
        var csvStringResult, counter, keys, columnDivider, lineDivider;
       
        // check if "objectRecords" parameter is null, then return from function
        if (dataSet == null || !dataSet.length) {
            return null;
         }
        // store ,[comma] in columnDivider variabel for sparate CSV values and 
        // for start next line use '\n' [new line] in lineDivider varaible  
        columnDivider = ',';
        lineDivider =  '\n';
 
        // in the keys valirable store fields API Names as a key 
        // this labels use in CSV file header  
        keys = dkeys;
        
        csvStringResult = '';
        csvStringResult += columns.join(columnDivider);
        csvStringResult += lineDivider;
 
        for(var i=0; i < dataSet.length; i++){   
            counter = 0;
           
             for(var sTempkey in keys) {
                var skey = keys[sTempkey] ;  
 
              // add , [comma] after every String value,. [except first]
                  if(counter > 0){ 
                      csvStringResult += columnDivider; 
                   }   
               
               csvStringResult += '"'+ dataSet[i][skey]+'"'; 
               
               counter++;
 
            } // inner for loop close 
             csvStringResult += lineDivider;
          }// outer main for loop close 
       
       // return the CSV formate String 
        return csvStringResult;        
    }
});