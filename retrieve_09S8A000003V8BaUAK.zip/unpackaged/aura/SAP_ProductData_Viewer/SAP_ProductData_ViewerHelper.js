({
    radioGroupChange : function(component, event, helper) {
        var selectedCode = event.getSource().get("v.value");
        component.set('v.SelectedSAPRecord', selectedCode);     
    },
    productDetails : function(component, event, helper) {
        var selectedSAPData = component.get('v.SelectedSAPRecord');                        
        
        if(selectedSAPData != null && selectedSAPData != ''){
            
            component.set('v.spinner', true);    
            console.log('--sObjectName---'+component.get('v.sObjectName'));
            var action = component.get("c.updateRecord");
            action.setParams({
                SAPData : selectedSAPData,
                recordID : component.get("v.recordId"),
                objectAPIName : component.get('v.sObjectName')
            });
            
            action.setCallback(this, function(response){
                var state = response.getState();  
                console.log('--state--'+state); 
                component.set('v.spinner', false);
                if(state == "SUCCESS"){ 
                    
                    var returnRecordID = response.getReturnValue();                    
                    // if no record ID returned then show error
                    if(returnRecordID.length != 18){
                        component.set('v.showRecordErrorMessage', true);
                        component.set('v.showSAPColumns', false);
                        component.set('v.RecordUpdateError', returnRecordID);
                    }
                    else if(returnRecordID.length == 18){
                        var navEvt = $A.get("e.force:navigateToSObject");
                        navEvt.setParams({
                            "recordId": returnRecordID,
                            "slideDevName": "related"
                        });
                        navEvt.fire();
                    }                                       
                }            
            });
            $A.enqueueAction(action);                    
            
        }                    
        else{
            alert('Please select record first !!');
        }
    },
    
    continuation : function(component, event, helper) {
        component.set('v.showErrorMessage', false);
        component.set('v.showRecordErrorMessage', false);
        component.set('v.TotalSAPRecords', '0');
        component.set('v.SelectedSAPRecord', ''); 
        //component.set('v.sobjecttype', component.get('v.sObjectName'));        
        
        var strProductNode = component.get("v.ProductName");
        
        if(strProductNode != null && strProductNode != ''){
            
            component.set('v.spinner', true);
            var action = component.get("c.startRequest");
            action.setParams({              
                productName :  strProductNode     
            });
            action.setCallback(this, function(response) {
                
                var state = response.getState();
                component.set('v.spinner', false);
                
                if (state === "SUCCESS") {
                    console.log('--Success---');
                    var returnObject = response.getReturnValue();   
                    
                    if(returnObject.errors.length > 0){
                        component.set('v.lstSAPErrors', returnObject.errors);
                        component.set("v.showErrorMessage", true);
                        component.set('v.showSAPColumns', false);
                        
                    }
                    else if(returnObject.data.length > 0 ){                        
                        component.set('v.lstSAPData', returnObject.data[0].pharmacyProducts) 
                        //console.log('--lstSAPData length--'+component.get('v.lstSAPData').length);
                        component.set("v.showErrorMessage", false);
                        component.set('v.showSAPColumns', true);
                        component.set('v.TotalSAPRecords', returnObject.data[0].totalResultsCount);             	       
                    }  
                }
                else if (state === "INCOMPLETE") {
                    alert("Continuation action is INCOMPLETE");
                }
                    else if (state === "ERROR") {
                        var errors = response.getError();
                        if (errors) {
                            if (errors[0] && errors[0].message) {
                                console.log("Error message: " +
                                            errors[0].message);
                            }
                        } else {
                            console.log("Unknown error");
                        }
                    }
            });
            // Enqueue action that returns a continuation
            $A.enqueueAction(action);
        }
        else{
            alert(' Please enter SAP Product Name or NDC first !!' );
        }
    }
    
})