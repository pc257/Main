({     
    init : function(component, event, helper) {
        
        var recordID = component.get("v.recordId"); 
        var action = component.get("c.checkRequiredFields");
        action.setParams({
            recordID : recordID,            
        });
        action.setCallback(this, function(response){
            var state = response.getState();   
            component.set("v.showSpinner", false); 
            if(state == "SUCCESS"){
                var recVal = response.getReturnValue();                                                               
                var errorMsg = component.get("v.showErrorMsg");  
                component.set("v.showErrorMsg",recVal.errorMsg);                                
                
                var errorType;
                if(recVal.errorType == 'success'){
                    errorType = 'slds-notify slds-notify_toast slds-theme_success';
                  //  console.log('--success in ctrl--'); helper.helperSendToSAP(component);
                }               
                else if(recVal.errorType == 'error'){
                    errorType = 'slds-notify slds-notify_toast slds-theme_error';
                }
                component.set("v.showErrorType",errorType);                                
                
            } else if(state == "ERROR"){
                console.log('Error in calling server side action');
            }
        });
        $A.enqueueAction(action);
        
        
    }
    
})