({
    doinit: function (component, event, helper) {
        debugger;
        var requestType = component.get("v.RequestType");
        if (requestType == "Installation") {
            helper.fetchequipmentIns(component, event, helper);
            helper.getShipperPicklist(component, event);
        } else if (requestType == "De-Installation") {
            helper.fetchequipmentDeIns(component, event, helper);
        } else if (requestType == "AddOn"){
            debugger;
            helper.fetchequipmentAddOn(component, event, helper);
        }

    },
    handleSave: function (component, event, helper) {
        var requestType = component.get("v.RequestType");
        if (requestType == "AddOn"){
            helper.saveAddOnEquipment(component, event, helper);
        }
        else{
        helper.saveEquipment(component, event, helper);
        }
    },
    updateServiceEquipments: function (component, event, helper) {
        helper.updateServiceEquipmentsEdit(component, event, helper);
    },
    loadInstalledEquipments: function (component, event, helper) {
        $A.util.addClass(component.find("EquipmentEdit"), "slds-hide");
        $A.util.removeClass(component.find("EquipmentSelection"), "slds-hide");
    },
    saveServiceEquipments: function(component, event, helper){
        helper.updateServiceEquipmentRecords(component, event, helper);
    }
})