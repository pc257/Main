({
    fetchequipmentIns: function (component, event, helper) {
        var action = component.get("c.fetchEquipments");
        action.setParams({
            recId: component.get("v.RecordId"),
        });
        action.setCallback(this, function (data) {
            var state = data.getState();
            if (state == "SUCCESS") {
                console.log(data.getReturnValue());
                var rows = data.getReturnValue();
                console.log('rows size' + Object.keys(rows).length);
                var xData = {};
                Object.keys(rows).forEach(function (key) {
                    var value = rows[key];
                    for (var count = 0; count < value; count++) {
                        var row = {};
                        row.equipmentName = key;
                        var newkey = key + "_" + count;
                        xData[newkey] = row;
                    }
                });
                component.set("v.EquipmentList", Object.values(xData));
                console.log('xData Length: ' + Object.keys(xData).length);
                console.log('xData : ' + Object.values(xData));
                var action = component.get("c.getSobjectList");
                action.setParams({
                    equipmentList: Object.values(xData),
                });
                action.setCallback(this, function (data) {
                    var state = data.getState();
                    if (state == "SUCCESS") {
                        console.log(data.getReturnValue());
                        component.set("v.equipmentObj", data.getReturnValue());
                    }
                });
                $A.enqueueAction(action);
            }
        });
        $A.enqueueAction(action);
    },
    getShipperPicklist: function (component, event) {
        var action = component.get("c.getShipper");
        action.setCallback(this, function (response) {
            var state = response.getState();
            if (state === "SUCCESS") {
                var result = response.getReturnValue();
                var shipperMap = [];
                for (var key in result) {
                    shipperMap.push({ key: key, value: result[key] });
                }
                component.set("v.shipperMap", shipperMap);
            }
        });
        $A.enqueueAction(action);
    },
    saveEquipment: function (component, event, helper) {
        debugger;
        var inventoryService = component.get("v.InventontoryServiceId");
        var equipments = component.get("v.equipmentObj");
        console.log(JSON.stringify(equipments));
        var action = component.get("c.saveServiceEquipment");
        action.setParams({
            equipmentList: JSON.stringify(equipments),
            inventoryServiceId: inventoryService,
        });
        action.setCallback(this, function (data) {
            var state = data.getState();
            if (state === "SUCCESS") {
                component.set("v.isButtonInActive", true);
                helper.showToastSuccess(component, event, helper);
            }
            else {
                helper.showToastFail(component, event, helper);
            }
        });
        $A.enqueueAction(action);
    },
    showToastSuccess: function (component, event, helper) {
        console.log('Inside Show Toast');
        var toastEvent = $A.get("e.force:showToast");
        toastEvent.setParams({
            "type": "success",
            "title": "Success!",
            "message": "Service Equipment record has been created/updated successfully"
        });
        toastEvent.fire();
    },
    showToastFail: function (component, event, helper) {
        console.log('Inside Show Toast');
        var toastEvent = $A.get("e.force:showToast");
        toastEvent.setParams({
            "type": "error",
            "title": "Error",
            "message": "Process failed while creating the records"
        });
        toastEvent.fire();
    },
    fetchequipmentDeIns: function (component, event, helper) {
        debugger;
        var action = component.get("c.fetchEquipmentsDeIns");
        action.setParams({
            recId: component.get("v.RecordId"),
        });
        action.setCallback(this, function (data) {
            var state = data.getState();
            if (state == "SUCCESS") {
                debugger;
                console.log(data.getReturnValue());
                var listitems = [];
                listitems = data.getReturnValue();
                for (var count = 0; count < listitems.length; count++) {
                    listitems[count].isSelected = false;
                }
                component.set("v.EquipmentList", listitems);
            }
        });
        $A.enqueueAction(action);
    },
    updateServiceEquipmentsEdit: function (component, event, helper) {
        var equipmentList = component.get("v.EquipmentList");
        var selectedEquipmentList = [];
        debugger;
        for (var count = 0; count < equipmentList.length; count++) {
            if (equipmentList[count].isSelected) {
                selectedEquipmentList.push(equipmentList[count]);
            }
        }
        component.set("v.SelectedEquipmentList", selectedEquipmentList);
        $A.util.addClass(component.find("EquipmentSelection"), "slds-hide");
        $A.util.removeClass(component.find("EquipmentEdit"), "slds-hide");
    },
    updateServiceEquipmentRecords: function (component, event, helper) {
        component.find("Id_spinner").set("v.class" , 'slds-show');
        $A.util.addClass(component.find("DeInstallScreen1"), "slds-hide");
        var recList = component.get("v.SelectedEquipmentList");
        var inventoryServiceRecId = component.get("v.InventontoryServiceId");
        var action = component.get("c.updateServiceEquipment");
        action.setParams({
            equipmentList: JSON.stringify(recList),
            recId : inventoryServiceRecId,
        });
        action.setCallback(this,function(data){
            var state = data.getState();
            if (state === "SUCCESS") {
                component.set("v.isButtonInActive", true);
                component.find("Id_spinner").set("v.class" , 'slds-hide');
                $A.util.removeClass(component.find("DeInstallScreen2"), "slds-hide");
                helper.showToastSuccess(component, event, helper);
            }
            else{
                helper.showToastFail(component, event, helper);
            }
        });
        $A.enqueueAction(action);
    },
    fetchequipmentAddOn: function(component, event, helper){
        debugger;
        var equipmentMap = new Map();
        var equipmentList = new Array();
        equipmentMap.set('AUX Single',component.get("v.AUXSingle"));
        equipmentMap.set('ERL',component.get("v.ERL"));
        equipmentMap.set('LAD',component.get("v.LAD"));
        equipmentMap.set('UAC Single',component.get("v.UACSingle"));
        equipmentMap.set('VPM',component.get("v.VPM"));
        for(let[key, value] of equipmentMap){
            for(var count = 0;count<value;count++){
                var row = {};
                row.Equipment_Type__c = key;
                equipmentList.push(row);
            }
        }
        component.set("v.EquipmentList",equipmentList);
    },
    saveAddOnEquipment: function (component, event, helper) {
        debugger;
        var inventoryService = component.get("v.InventontoryServiceId");
        var equipments = component.get("v.EquipmentList");
        console.log(JSON.stringify(equipments));
        var action = component.get("c.saveAddOnEquipment");
        action.setParams({
            equipmentList: JSON.stringify(equipments),
            inventoryServiceId: inventoryService,
        });
        action.setCallback(this, function (data) {
            var state = data.getState();
            if (state === "SUCCESS") {
                component.set("v.isButtonInActive", true);
                helper.showToastSuccess(component, event, helper);
            }
            else {
                helper.showToastFail(component, event, helper);
            }
        });
        $A.enqueueAction(action);
    }
})