({
	onLoad: function(component, event) {
        var recId = component.get("v.recordId");
        //var recordTypeId = component.get("v.pageReference").state.recordTypeId;
        var action1 = component.get("c.getContractRecordTypeID");
        action1.setParams({
            recId : recId
        });
        action1.setCallback(this, function(response) {
            var state = response.getState();
            if (state === "SUCCESS") {
                var recordTypename = response.getReturnValue();
                console.log(recordTypename);
                if((recordTypename!= "Drug Contract") && (recordTypename!= "Drug Amendment") ){
                component.set('v.subfolderName',recordTypename);
                }    
                else{
                component.set('v.subfolderName','Choose One..');     
                }
                
            }
            else{
                console.log('Error Occured')
            }
        });
        var action = component.get("c.fetchRecords");
        action.setParams({
            conId : recId
        });
        action.setCallback(this, function(response) {
            var state = response.getState();
            if (state === "SUCCESS") {
                var formList = response.getReturnValue();
                //component.set('v.ListOfDocuments', formList.fDTOList);
                component.set('v.showUploadBtn', formList.showUploadButton);
                if(formList.fDTOList.length == 0){
                    component.set('v.noDocuments', true);
                }else{
                    component.set('v.ListOfDocuments', formList.fDTOList);
                    component.set('v.noDocuments', false);
                }
            }
        });
        $A.enqueueAction(action1);
        $A.enqueueAction(action);
    },
    
    MAX_FILE_SIZE: 4500000, //Max file size 4.5 MB 
    CHUNK_SIZE: 750000,      //Chunk Max size 750Kb 
    
    
    uploadHelper: function(component, event) {
        // get the selected files using aura:id [return array of files]
        var fileInput = event.getParam("files"); //component.find("fileId").get("v.files");
        var file = fileInput[0];
        var self = this;
        // create a FileReader object 
        var objFileReader = new FileReader();
        // set onload function of FileReader object   
        objFileReader.onload = $A.getCallback(function() {
            var fileContents = objFileReader.result;
            var base64 = 'base64,';
            var dataStart = fileContents.indexOf(base64) + base64.length;
            
            fileContents = fileContents.substring(dataStart);
            // call the uploadProcess method 
            self.uploadProcess(component, file, fileContents);
        });
        
        objFileReader.readAsDataURL(file);
        
    },
    
    uploadProcess: function(component, file, fileContents) {
        
        // set a default size or startpostiton as 0 
        var startPosition = 0;
        // calculate the end size or endPostion using Math.min() function which is return the min. value   
        var endPosition = Math.min(fileContents.length, startPosition + this.CHUNK_SIZE);
        
        // start with the initial chunk, and set the attachId(last parameter)is null in begin
        this.uploadInChunk(component, file, fileContents, startPosition, endPosition, '');
    },
    
    uploadInChunk: function(component, file, fileContents, startPosition, endPosition, attachId) {
        // call the apex method 'saveChunk'
        
        var getchunk = fileContents.substring(startPosition, endPosition);
        var idRec = component.get("v.recordId");
        var fName = component.get("v.folderName");
        console.log(component.get("v.subfolderName"));
        var sName = component.get("v.subfolderName");
        var formId = '';
        var action = component.get("c.getOAuthToken");
        action.setParams({
            fileName: file.name,
            fileContent:getchunk,
            fileType: file.type,
            recId : idRec,
            folderName : fName,
            Subfolder :sName
        });
        
        // set call back 
        action.setCallback(this, function(response) {
            // store the response / Attachment Id   
            attachId = response.getReturnValue();
            var state = response.getState();
            if (state === "SUCCESS") {
                // update the start position with end postion
                startPosition = endPosition;
                endPosition = Math.min(fileContents.length, startPosition + this.CHUNK_SIZE);
                // check if the start postion is still less then end postion 
                // then call again 'uploadInChunk' method , 
                // else, diaply alert msg and hide the loading spinner
                if (startPosition < endPosition) {
                    this.uploadInChunk(component, file, fileContents, startPosition, endPosition, attachId);
                } else {
                    var toastEvent = $A.get("e.force:showToast");
                    toastEvent.setParams({
                        title : 'Success',
                        message: 'File has been uploaded successfully',
                        type: 'Success',
                    });  
                    toastEvent.fire();
                    component.set("v.showFileUploadModal", false);
                    component.set("v.folderName", '');
                    $A.get('e.force:refreshView').fire();
                }
                // handel the response errors        
            }
        }); 
        // enqueue the action
        $A.enqueueAction(action);
    },
})