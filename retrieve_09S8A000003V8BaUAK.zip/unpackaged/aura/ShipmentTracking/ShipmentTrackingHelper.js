({
    getAccount: function(component,event,helper){
        var recordId = component.get("v.recordId");
        var errorMessages = [];

        var action = component.get("c.getShippingInformation");
        action.setParams({"recordId":recordId});

        action.setCallback(this, function(response) {
            var state = response.getState();

            if (state === "SUCCESS"){
                var sfdcObject = response.getReturnValue();
                component.set("v.sfdcObject", sfdcObject);
            }
            else{

            }
        });
        $A.enqueueAction(action);
    }
});