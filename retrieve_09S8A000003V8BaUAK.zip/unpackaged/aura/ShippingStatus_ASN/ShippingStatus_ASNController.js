({
    doInit: function(component,event,helper) {
        helper.getDate(component,event,helper);
    },
    getAccount: function(component,event,helper) {
        helper.getAccount(component,event,helper);
    }
});