({
    getDate: function(component,event,helper){

        var action = component.get("c.getSystemDate");

        action.setCallback(this, function(response) {
            var state = response.getState();

            if (state === "SUCCESS"){
                component.set("v.selectedDate", response.getReturnValue());
                this.getAccount(component,event,helper);
            }
            else{

            }
        });
        $A.enqueueAction(action);
    },
    getAccount: function(component,event,helper){
        var recordId = component.get("v.recordId");
        var errorMessages = [];

        var action = component.get("c.getShippingInformation");
        action.setParams({"recordId":recordId});

        action.setCallback(this, function(response) {
            var state = response.getState();

            if (state === "SUCCESS"){
                var sfdcObject = response.getReturnValue();
                component.set("v.sfdcObject", sfdcObject);

                if(sfdcObject.sapAccountNumber === undefined){
                    errorMessages.push("SAP Account Number is blank");
                }
                if(sfdcObject.accountStatus === undefined){
                    errorMessages.push("Account Status is blank");
                }
                if(sfdcObject.shippingSystemTracking === undefined){
                    errorMessages.push("Shipping System Tracking is blank");
                }
                if(sfdcObject.distributionCenter === undefined){
                    errorMessages.push("Primary Distribution Center is blank");
                }

                this.fetchShipmentStatus(component,event,helper,errorMessages);
            }
            else{

            }
        });
        $A.enqueueAction(action);
    },
    fetchShipmentStatus: function(component,event,helper,errorMessages){
        var sfdcObject = component.get("v.sfdcObject");
        var selectedDate = component.get("v.selectedDate");

        var action = component.get("c.fetchShipmentStatusByCase");
        action.setParams({"sfdcObject":sfdcObject,
            "selectedDate":selectedDate
        });

        action.setCallback(this, function(response) {
            var state = response.getState();
            var responseItems = response.getReturnValue();

            //testing parameters
            //console.log("Fetch Response: " + JSON.stringify(responseItems));
            //responseItems = "";

            if (state === "SUCCESS"){
                if(responseItems){
                    responseItems.forEach(function(item){

                        console.log("hubDepartureVariance: " + item.hubDepartureVariance);
                        console.log("deliveryVariance: " + item.deliveryVariance);
                        console.log("status: " + item.status);
                        console.log("ampmStatus: " + item.ampmStatus);
                        console.log("custTimeZone: " + item.custTimeZone);
                        console.log("custDelTime: " + item.custDelTime);
                        console.log("expDelTime: " + item.expDelTime);
                        console.log("scheduledDeliveryDateTime: " + item.scheduledDeliveryDateTime);
                        console.log("custDeliveryDateTime: " + item.custDeliveryDateTime);
                        console.log("expectedDeliveryDateTime: " + item.expectedDeliveryDateTime);

                        if(item.custTimeZone === "CDT" || item.custTimeZone === "CST"){
                            item.timeZoneLong = "America/Chicago";
                        }
                        else if(item.custTimeZone === "EDT" || item.custTimeZone === "EST"){
                            item.timeZoneLong = "America/New_York";
                        }
                        else if(item.custTimeZone === "MDT" || item.custTimeZone === "MST"){
                            item.timeZoneLong = "America/Denver";
                        }
                        else if(item.custTimeZone === "PDT" || item.custTimeZone === "PST"){
                            item.timeZoneLong = "America/Los_Angeles";
                        }
                        else if(item.custTimeZone === "AKDT" || item.custTimeZone === "AKST"){
                            item.timeZoneLong = "America/Anchorage";
                        }
                        else if(item.custTimeZone === "HDT" || item.custTimeZone === "HST"){
                            item.timeZoneLong = "America/Honolulu";
                        }
                        else if(item.custTimeZone === "GMT"){
                            item.timeZoneLong = "UTC";
                        }

                        console.log("timeZoneLong: " + item.timeZoneLong);

                        if(item.deliveryVarianceStatus === 'Red'){
                            item.truckImage = "/ShipmentStatusRed.png";
                        }
                        else if(item.deliveryVarianceStatus === 'Yellow'){
                            item.truckImage = "/ShipmentStatusYellow.png";
                        }
                        else if(item.deliveryVarianceStatus === 'Green'){
                            item.truckImage = "/ShipmentStatusGreen.png";
                        }
                        else{
                            item.truckImage = "/ShipmentStatusNone.png";
                        }

                        console.log("truckImage: " + item.truckImage);
                    });

                    component.set("v.response", response.getReturnValue());
                }
                else{
                    errorMessages.push("No records are found");
                }
            }
            else{
                errorMessages.push("No records are found");
            }

            console.log("error message length: " + errorMessages.length);
            console.log("showDetails: " + component.get("v.showDetails"));
            console.log("showError: " + component.get("v.showError"));
            if(errorMessages.length > 0){
                component.set("v.showDetails", false);
                component.set("v.showError", true);
                component.set("v.errorMessages", errorMessages);
            }
        });
        $A.enqueueAction(action);
    },
});