({
    init: function (cmp, event, helper) {
        cmp.set('v.columns', [
            {label: 'Employee Name', fieldName: 'EmployeeName', type: 'text'},
            {label: 'Employee ID', fieldName: 'EmpId', type: 'text'},
            {label: 'Functional Role', fieldName: 'FunctionalRole', type: 'text'},
            {label: 'Account Assignment Start Date', fieldName: 'startDate', type: 'date', typeAttributes: {  
                                                                            day: 'numeric',  
                                                                            month: 'short',  
                                                                            year: 'numeric',  
                                                                            hour12: true}}
        ]);
        cmp.set('v.accountColumns', [
            {label: 'AS Support', fieldName: 'ASSupport', type: 'text'},
            {label: 'AS Support Type', fieldName: 'ASSupportType', type: 'text'},
            {label: 'Assigned AS Specialist', fieldName: 'AssignedASSpecialist', type: 'text'}
        ]);
        cmp.set('v.additionalAccountColumns', [
            {label: 'District Director Inside Sales(DDIS)', fieldName: 'DistrictDirectorInsideSalesDDIS', type: 'text'},
            {label: 'Inside Sales Executive(ISE)', fieldName: 'InsideSalesExecutiveISE', type: 'text'}
        ]);
        helper.fetchData(cmp, helper);    
    }
});