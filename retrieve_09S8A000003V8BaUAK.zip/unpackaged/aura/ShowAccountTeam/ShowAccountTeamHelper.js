({
    fetchData: function (component, helper) {
        component.set('v.loaded', false);
        var action = component.get("c.getData");
        action.setParams({
            'accountId' : component.get("v.recordId")
        });
        action.setCallback(this,function(response) {
            component.set('v.loaded', true);
            var state = response.getState();
            if(state === "SUCCESS"){
                var resp = JSON.parse(response.getReturnValue());
                if(resp && resp.totalSize > 0){
                    component.set("v.renderData", true);
                    var records = [];
                    if(resp.records[0].Assignments != null && resp.records[0].Assignments.totalSize > 0){
                        component.set("v.renderNoData", false);
                        for(var iCount = 0; iCount < resp.records[0].Assignments.totalSize; iCount++){
                            var record = {};
                            var xRecord = resp.records[0].Assignments.records[iCount];
                            record["EmployeeName"] = xRecord.Employee.Name;
                            record["EmpId"] = xRecord.Empl_ID;
                            record["FunctionalRole"] = xRecord.Functional_Role;
                            record["startDate"] = xRecord.Account_Assignment_Start_Date;
                            records.push(record);
                        }
                        component.set("v.data", records);
                    }else{
                        component.set("v.renderNoData", true);
                    }
                    var accountRecords = [];
                    var additionalAccountRecords = [];
                    if(resp.totalSize > 0){
                        var accountRecord = {};
                        var additionalAccountRecord = {};
                        accountRecord["ASSupport"] = resp.records[0].AS_Support == null || resp.records[0].AS_Support == false ? 'NO' : 'YES';
                        accountRecord["ASSupportType"] = resp.records[0].AS_Support_Type == null ? '' : resp.records[0].AS_Support_Type;
                        accountRecord["AssignedASSpecialist"] = resp.records[0].Assigned_AS_Specialist == null ? 'Not Assigned' : resp.records[0].Assigned_AS_Specialist.Name == null ? 'Not Assigned' : resp.records[0].Assigned_AS_Specialist.Name;
                        accountRecords.push(accountRecord);
                        component.set("v.accountData", accountRecords);
                        
                        component.set("v.primarySalesContact", resp.records[0].Primary_Sales_Contact == null ? 'Not Assigned' : resp.records[0].Primary_Sales_Contact);
                    	
                        additionalAccountRecord["DistrictDirectorInsideSalesDDIS"] = resp.records[0].District_Director_Inside_Sales_DDIS == null ? 'Not Assigned' : resp.records[0].District_Director_Inside_Sales_DDIS;
                        additionalAccountRecord["InsideSalesExecutiveISE"] = resp.records[0].Inside_Sales_Executive_ISE == null ? 'Not Assigned' : resp.records[0].Inside_Sales_Executive_ISE;
                        additionalAccountRecords.push(additionalAccountRecord);
                        component.set("v.additionalAccountData", additionalAccountRecords);
                    }  
                }else{
                    component.set("v.renderData", false);
                    var errorMsg = 'The SAP Account Number is incorrect.';
                    var toastEvent = $A.get("e.force:showToast");
                    toastEvent.setParams({
                        title: 'Error',
                        type: 'error',
                        message: errorMsg
                    });
                    toastEvent.fire();     
                }   
            }else{
                component.set("v.renderData", false);
                var errorMsg = action.getError()[0].message;
                var toastEvent = $A.get("e.force:showToast");
                toastEvent.setParams({
                    title: 'Error',
                    type: 'error',
                    message: errorMsg
                });
                toastEvent.fire();
            }
        });
        $A.enqueueAction(action);
    }
});