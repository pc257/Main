({
	doInit : function(component, event, helper) {
        
		var recId = component.get("v.recordId");
        console.log('===',recId);
        
        var action = component.get("c.showAllTask");
        action.setParams({
            "recordId" : recId
        })
        action.setCallback(this,function(response){
            var state = response.getState();
            console.log("state",state);
            if(state === "SUCCESS"){
                var lstcnt = response.getReturnValue();                
                console.log("lstcnt",lstcnt);
                component.set("v.data",lstcnt);
                console.log("Data",component.get("v.data"));
            }
        })
        $A.enqueueAction(action);
	}
})