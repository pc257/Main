({
    doInit : function(component, event, helper){
        helper.loadRecordType(component);
        
    },
   handleSelect : function(component, event, helper) {
       var allrec = component.get("v.allrec");
       var allRecList = component.get("v.allRecList");
       //Get the selected option: "Referral", "Social Media", or "All"
       var selected = event.getSource().get("v.value");
       if(selected == "Event"){
           component.set("v.selRecTy",'');
       }
       component.set("v.selected",selected);
       helper.loadAllData(component);
   },
   getRecType : function(component, event, helper) {
       var recType = event.getSource().get("v.value");
       component.set("v.selRecTy",recType);
       helper.loadAllData(component);   	
   }
})