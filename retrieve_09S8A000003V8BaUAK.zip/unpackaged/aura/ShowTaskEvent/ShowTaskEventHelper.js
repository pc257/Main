({
    loadRecordType : function(component){
        var action = component.get("c.getRecordTypes");
        action.setCallback(this,function(response){
            var state = response.getState();
            console.log('@@State:',state);
             var newlst =[];
            if (state === "SUCCESS") {
                component.set("v.RecTypes", response.getReturnValue());
                console.log('@@@@@@@@@@@:::',response.getReturnValue());
               /* var finalVal = response.getReturnValue();
                 console.log('===============',finalVal);
                for(var key in finalVal){
                  	 console.log('===============>');
                     console.log('===============',finalVal[key]);
                     newlst.push(finalVal[key]);
                }
                console.log('&&&&&&&&&&&&&&&&&&&&&&&&&&&&&7',newlst)
                component.set("v.RecTypes",newlst);*/
            }
        });
        $A.enqueueAction(action);
    },
    loadTask : function(component){
        var action = component.get("c.getTask");
        action.setCallback(this, function(response) {
            var state = response.getState();
            if (state === "SUCCESS") {
                component.set("v.taskRecs", response.getReturnValue());
                component.set("v.TaskList", response.getReturnValue());
                console.log('@@@@@@@@@@@',response.getReturnValue());
                // this.updateTotal(cmp);
            }
            // Display toast message to indicate load status
            var toastEvent = $A.get("e.force:showToast");
            if (state === 'SUCCESS'){
                toastEvent.setParams({
                    "title": "Success!",
                    "message": " Your contacts have been loaded successfully."
                });
            }
            else {
                toastEvent.setParams({
                    "title": "Error!",
                    "message": " Something has gone wrong."
                });
            }
            toastEvent.fire();
        });
        $A.enqueueAction(action);
    },
    loadAllData : function(component){
        var selectval = component.get("v.selected");
        console.log('LoadDta',selectval);
        console.log('66666666666666',component.get("v.recordId"));
        var action = component.get("c.getAllRecords");
        action.setParams({
            "type" : selectval,
            "recId": component.get("v.recordId"),
            "recType": component.get("v.selRecTy")
        });
        action.setCallback(this, function(response) {
            var state = response.getState();
            if (state === "SUCCESS") {
                component.set("v.allrec", response.getReturnValue());
                component.set("v.allRecList", response.getReturnValue());
                console.log('@@@@@@@@@@@Global',response.getReturnValue().length);
                console.log('-----------------------',component.get("v.allRecList"));
            }
        });
        $A.enqueueAction(action);
    }
})