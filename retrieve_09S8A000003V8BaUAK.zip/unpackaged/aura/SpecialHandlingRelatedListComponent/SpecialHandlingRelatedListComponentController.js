({
	doInit : function(component, event, helper) {
        helper.fetchSpecialHandlingData(component, event, helper);
        helper.fetchBusinessRule(component, event, helper);
        helper.fetchSignalCode(component, event, helper);
	},
     panelOne : function(component, event, helper) {
        helper.toggleAction(component, event, 'panelOne');
    },
    panelTwo : function(component, event, helper) {
        helper.toggleAction(component, event, 'panelTwo');
    },
    toggleSection : function(component, event, helper) {
        
        var sectionAuraId = event.target.getAttribute("data-auraId");
        var sectionDiv = component.find(sectionAuraId).getElement();
        var sectionState = sectionDiv.getAttribute('class').search('slds-is-open'); 
        if(sectionState == -1){
            sectionDiv.setAttribute('class' , 'slds-section slds-is-open');
        }else{
            sectionDiv.setAttribute('class' , 'slds-section slds-is-close');
        }
    }
    
})