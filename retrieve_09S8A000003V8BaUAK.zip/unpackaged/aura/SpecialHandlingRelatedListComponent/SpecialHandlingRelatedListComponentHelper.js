({
    fetchSpecialHandlingData : function(component, event, helper) {
        var action = component.get("c.getSpecialHandlingData");
        action.setParams({accountId : component.get("v.recordId"),
                         });
        action.setCallback(this, function(data){
            var state = data.getState();
            if(state == "SUCCESS"){
                var rows = data.getReturnValue();
                var xData = {};
                if(rows!=null){
                    for(var iCount = 0; iCount < rows.length; iCount++){
                        var row = rows[iCount];
                        if(row.Id){row.id = row.Id;}
                        if(row.Account_Level__c){row.AccountLevel = row.Account_Level__c;}
                        if(row.Alert_Description__c){row.Description = row.Alert_Description__c;}
                        if(row.Visibility__c){row.Visibility = row.Visibility__c;}
                        if(row.AlertType__c){row.Type = row.AlertType__c;}
                        if(row.Subtype__c){row.SubType = row.Subtype__c;}
                        row.IsActive = row.IsActive__c;
                        var key = ""+row.SubType +"-" + row.AccountLevel + "-" + row.Description + "-" + row.Visibility + "-" + row.Type + "";
                        xData[key] = row;
                    }
                    console.log('xData : values : '+xData);
                    component.set("v.SpecialHandlingList", Object.values(xData));
                    component.set("v.SpecialHandlingTitle", "Special Handling (" + Object.values(xData).length + ")");
                }
            }
        });
        $A.enqueueAction(action);
    },
    fetchBusinessRule : function(component, event, helper) {
        var action = component.get("c.getBusinessRuleData");
        var accountId = component.get("v.recordId");
        action.setParams({
            accountId: accountId
        });
        action.setCallback(this, function(response) {
            var state = response.getState();
            if(state === 'SUCCESS') {
                
                var businessRuleList = response.getReturnValue();
                var xData = {};
                if(businessRuleList!=null){
                    for(var iCount = 0; iCount < businessRuleList.length; iCount++){
                        var row = businessRuleList[iCount];
                        if(row.Id){row.id = row.Id;}
                        if(row.Rule_Name__c){row.RuleName = row.Rule_Name__c;}
                        if(row.Rule_Description__c){row.RuleDescription = row.Rule_Description__c;}
                        if(row.Start_Date__c){row.StartDate = row.Start_Date__c;}
                        if(row.End_Date__c){row.EndDate = row.End_Date__c;}
                        var key = ""+row.RuleName +"-" + row.RuleDescription + "-" + row.StartDate + "-" + row.EndDate + "";
                        xData[key] = row;
                    }
                }
                component.set("v.businessRuleList",Object.values(xData));
                component.set("v.BusinessRule", "Business Rule (" + Object.values(xData).length + ")");
            }
            else {
                alert('Error in getting data');
            }
        });
        $A.enqueueAction(action);
    },
    fetchSignalCode : function(component, event, helper) {
        var action = component.get("c.getSignalCodeData");
        var accountId = component.get("v.recordId");
        action.setParams({
            accountId: accountId
        });
        action.setCallback(this, function(response) {
            var state = response.getState();
            if(state === 'SUCCESS') {
                var signalCodeList = response.getReturnValue();
                var xData = {};
                if(signalCodeList!=null){
                    for(var iCount = 0; iCount < signalCodeList.length; iCount++){
                        var row = signalCodeList[iCount];
                        if(row.Id){row.id = row.Id;}
                        if(row.Signal_Code__c){row.SignalCode = row.Signal_Code__c;}
                        if(row.Valid_From_Date__c){row.ValidFromDate = row.Valid_From_Date__c;}
                        if(row.Valid_To_Date__c){row.ValidToDate = row.Valid_To_Date__c;}
                        var key = ""+row.SignalCode +"-" + row.ValidFromDate + "-" + row.ValidToDate + "";
                        xData[key] = row;
                    }
                    component.set("v.signalCodeList",Object.values(xData));
                    component.set("v.SignalCode", "Signal Code (" + Object.values(xData).length + ")");
                }                
            }
            else {
                alert('Error in getting data');
            }
        });
        $A.enqueueAction(action);
    },
    toggleAction : function(component, event, secId) {
        var acc = component.find(secId);
        for(var cmp in acc) {
            $A.util.toggleClass(acc[cmp], 'slds-show');  
            $A.util.toggleClass(acc[cmp], 'slds-hide');  
        }
    }
})