({
   doInit : function(component, event, helper) {
       helper.getRecords(component,event,helper);
     //  helper.geraccounttype(component,event,helper);
       helper.getFieldsFromAccFieldSet1(component,event,helper);
       helper.getFieldsFromAccFieldSet2(component,event,helper);                
   },
   processSlectedRows: function (component, event,helper) {
       var selectedRows = event.getParam('selectedRows');
       var rowIdList =[];
       if(selectedRows){            
           for(var i=0;i<selectedRows.length;i++){
               if(selectedRows[i] && selectedRows[i].Id){                
                rowIdList.push(selectedRows[i].Id);  
               }
           }
           component.set("v.selectedRows",rowIdList);
           helper.renderSubmitButton(component, event, helper);
       }
   },
    renderSubmitButton : function(component, event, helper) {
        helper.renderSubmitButton(component, event, helper);
    },
   updateSelectedAff :function(component, event, helper) {        
       helper.updateAccountAffiliation(component, event, helper);
   }
});