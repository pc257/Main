({
    getAccountAffiliation : function(component, event, helper) {
        alert ('enter get affiliations');
        component.set('v.columns', [
            	{label: 'Account Affiliation', fieldName: 'AffLink', type: 'url', initialWidth: 150,
            	typeAttributes: {label: { fieldName: 'Name' }, target: '_blank'}},
                {label: 'Affiliation Type', fieldName: 'Affiliation_Type__c', type: 'text', initialWidth: 150},
                {label: 'Source', fieldName: 'Source__c', type: 'text', initialWidth: 150},
                {label: 'Status', fieldName: 'Status__c', type: 'text', initialWidth: 150},
            	{label: 'Start Date', fieldName: 'Start_Date__c', type: 'Date', initialWidth: 150},
            	{label: 'End Date', fieldName: 'End_Date__c', type: 'Date', initialWidth: 150},
            	{label: 'Account', fieldName: 'AccLink', type: 'url', initialWidth: 150,
            	typeAttributes: {label: { fieldName: 'AccountName' }, target: '_blank'}},
            	{label: 'Account Number', fieldName: 'AccountEccId', type: 'Number', initialWidth: 150},
            	{label: 'Account Record Type', fieldName: 'AccountRecrdType', type: 'text', initialWidth: 150},
            	{label: 'Order Block', fieldName: 'AccountOrderblck', type: 'text', initialWidth: 150},
            	{label: 'Shipping street', fieldName: 'AccountStreet', type: 'text', initialWidth: 150},
            	{label: 'Shipping City', fieldName: 'AccountCity', type: 'text', initialWidth: 150},
            	{label: 'Shipping State', fieldName: 'AccountState', type: 'text', initialWidth: 150},
            	{label: 'Shipping Postal Code', fieldName: 'AccountPostalCode', type: 'text', initialWidth: 150},
            	{label: 'Shipping Country', fieldName: 'AccountCountry', type: 'text', initialWidth: 150}           
            ]);
        var action = component.get("c.getAccountAffiliation");
        action.setParams({ accId: component.get("v.AccId")});
        action.setCallback(this, function(response){
            var state = response.getState();
            if (state === "SUCCESS") {
               var records = response.getReturnValue();
                 console.log('print row count'+records.length);
                 var accType = [];
                for(var iCount = 0; iCount < records.length; iCount++){
                     var row = records[iCount];
                    if(records[iCount].Related_Account__r.Type=='Enterprise Business Partner Location'){
                   accType.push(records[iCount].Related_Account__r.Type); 
                }
                }
                console.log('accType--->'+accType);
                   if(accType.length>0){
                    alert("size");
                    component.set("v.isRelatedAccEBP", true);
                }
                console.log('isRelatedAccEBP--->'+component.get("v.isRelatedAccEBP"));
               records.forEach(function(record){
                   if(record.Account__r.Id){
                       record.AccLink = '/lightning/r/Account/' + record.Account__r.Id + '/view';
                       record.AccountName = record.Account__r.Name;
                   } 
                   
                   /* for(var i = 0; i < records.length; i++){
                   for(var i in records){
                        accType.push(records[i].Related_Account__r.Type); 
                   }
                   /* if(record.Related_Account__r.Id){
                       var key = record.Related_Account__r.Type;
                        accType.push(key);
                   } */
                 
                    record.AffLink = '/lightning/r/Account/' + record.Id + '/view';
                    record.AccountEccId = record.Account__r.SAP_ECC_ID__c;
                    record.AccountRecrdType = record.Account__r.RecordType.Name;
                    record.AccountOrderblck = record.Account__r.Order_Block__c;
                    record.AccountStreet = record.Account__r.ShippingStreet;
                    record.AccountCity = record.Account__r.ShippingCity; 
                    record.AccountState = record.Account__r.ShippingState;
                    record.AccountPostalCode = record.Account__r.ShippingPostalCode;
                    record.AccountCountry = record.Account__r.ShippingCountry;
               });
                
             
               component.set("v.affList", records);
                component.set("v.accounttypeEBP", records[0].Related_Account__r.Type);
                 console.log('get account type--->'+ component.get("v.accounttypeEBP"));
                console.log('show affiliation--->'+ component.get("v.affList"));
                 // component.set("v.relatedAcctype" ,accType);
                 //  console.log('populate related acc type--->'+ component.get("v.relatedAcctype"));
           }
        });
        $A.enqueueAction(action);
    },
    getFieldsFromAccFieldSet1 : function(component, event, helper) {
        var action = component.get("c.readFieldSet");
        action.setParams({ fieldSetName: "Account_Closure_Field_Set", ObjectName: "Account"});
        action.setCallback(this, function(response){
            var state = response.getState();
            if (state === "SUCCESS") {
                component.set("v.AccountFieldSet1", response.getReturnValue());
            }
        });
        $A.enqueueAction(action);
    },
    getFieldsFromAccFieldSet2 : function(component, event, helper) {
        var action = component.get("c.readFieldSet");
        action.setParams({ fieldSetName: "AccountClosureRequest_AccountFields", ObjectName: "Account"});
        action.setCallback(this, function(response){
            var state = response.getState();
            if (state === "SUCCESS") {
                component.set("v.AccountFieldSet2", response.getReturnValue());
            }
        });
        $A.enqueueAction(action);
    },
    
    geraccounttype: function(component, event, helper){
        alert('enter get account type');
         component.set("v.isRelatedAccEBP", false);
        component.set('v.columns1', [
       //    {label: 'Account Name', fieldName: 'Name', type: 'text'}
            {label: 'Account Name', fieldName: 'linkname', type: 'url', initialWidth: 150,
            	typeAttributes: {label: { fieldName: 'Name' }, target: '_blank'}},
           
        ]); 
        var action = component.get("c.getAccountType");
          action.setParams({ accId: component.get("v.AccId")});
          action.setCallback(this, function(data){
            var state = data.getState();
            if(state == "SUCCESS"){
                var results = data.getReturnValue();
                
/*results.forEach(function(record){
                   if(record.Name){
                       record.AccLink = '/lightning/r/Account/' + record.Account__r.Id + '/view';
                       record.AccountName = record.Account__r.Name;
                   } */                
                if(results){
                    alert('result success');
          results[0].linkname= '/lightning/r/Account/' + results[0].Name + '/view';
         //   results.AccLink = '/' +results[0].Id;
                      component.set("v.accName", results);
                    console.log('data in list-->'+component.get("v.accName"));
                    component.set("v.accounttypeEBP", results[0].Type);
                      component.set("v.accontName", results[0].Name);
        console.log('account name***'+ component.get("v.accontName"));
                   console.log('type of account is***'+ component.get("v.accounttypeEBP"));
         console.log('account name***'+ component.get("v.accName"));
                }
              //  helper.getAccountAffiliation(component, event, helper);
            }
            else if(state == "ERROR"){
                var toastEvent = $A.get("e.force:showToast");
                toastEvent.setParams({
                    title : 'Error',
                    message: 'An error has occurred. Please contact your system administrator',
                    type: 'error',
                });
                toastEvent.fire();
            }
        });
        $A.enqueueAction(action);
    },
     getRecords: function(component, event, helper) {
         alert('enter get records');
        var action = component.get("c.getRecordDetails");
         action.setParams({ recordID: component.get("v.recordId"), sobjectType: component.get("v.sObjectName"),opportunityId :  component.get("v.OpportunityId")});
        action.setCallback(this, function(response){
            var state = response.getState();
            if(state == "SUCCESS"){               
                var responseString = response.getReturnValue(); 
                if(responseString == 'Success Opportunity'){
                    this.getAccountId(component,event,helper);
           			this.getFieldsFromOpptyFieldSet1(component,event,helper);
                }else if(responseString == 'Success Account'){
                    component.set("v.AccId",component.get("v.recordId"));
           			this.getAccountAffiliation(component, event, helper);
                }else if(responseString == 'Invalid Stage'){
                    alert('Invalid stage');
                    component.set("v.showErrorMessage", true); 
                    component.set("v.ErrorMessage", $A.get("$Label.c.Opportunity_Closure_Error_Message"));                                          
                    this.toggleSpinner(component);
                }else if(responseString == 'Blank Account'){
                    component.set("v.showErrorMessage", true); 
                    component.set("v.ErrorMessage",   $A.get("$Label.c.Account_Closure_Request_Account_Error"));                                        
                    this.toggleSpinner(component);
                }else if(responseString == 'Invalid Account Record Type'){
                    alert('enter non EBP account');
                     component.set("v.AccId",component.get("v.recordId"));
           			this.geraccounttype(component, event, helper);
                   // component.set("v.showErrorMessage", true); 
                   // component.set("v.ErrorMessage",   'This is applicable for only Customer Record Type Account with Type = Enterprise Business Partner Location');                                        
                    this.toggleSpinner(component);
                }else if(responseString == 'Blank Account Type'){
                    alert('blank account type');
                     component.set("v.AccId",component.get("v.recordId"));
           			//this.geraccounttype(component, event, helper);
                   component.set("v.showErrorMessage", true); 
                   component.set("v.ErrorMessage",   'Account Type of current account has not been selected');                                        
                    this.toggleSpinner(component);
                }else{
                    alert('non EBP account on opportunity is selected');
                    component.set("v.showErrorMessage", true); 
                    component.set("v.ErrorMessage",   'Error on server side : Contact System Admin.');                                        
                    this.toggleSpinner(component);
                }
            }
            else{
                component.set("v.showErrorMessage", true);                                                                                
                helper.toggleSpinner(component);
            }
        });
        $A.enqueueAction(action);
    },
    toggleSpinner: function(component){
        var spinner = component.find("loading_spinner");
        $A.util.toggleClass(spinner, "slds-hide");
    },
    getFieldsFromOpptyFieldSet1 : function(component, event, helper) {
        var action = component.get("c.readFieldSet");
        action.setParams({ fieldSetName: "AccountClosureRequest_OpportunityFields", ObjectName: "Opportunity"});
        action.setCallback(this, function(response){
            var state = response.getState();
            if (state === "SUCCESS") {
                component.set("v.OpportunityFieldSet", response.getReturnValue());
            }
        });
        $A.enqueueAction(action);
    },
    getAccountId : function(component, event, helper) {
        var action = component.get("c.getAccountId");
        action.setParams({ opptyId: component.get("v.OpportunityId")});
        action.setCallback(this, function(response){
            var state = response.getState();
            if (state === "SUCCESS") {
                component.set("v.AccId", response.getReturnValue());
               
                this.getAccountAffiliation(component, event, helper);
            }
        });
        $A.enqueueAction(action);
    },
    updateAccountAffiliation : function(component, event,helper){
        var action = component.get("c.updateAccountAffiliationAndCreateCase");
        var accDeactiveReason = component.get("v.AccontDeactivationReason"); //component.find('Account_Deactivation_Reason__c').get("v.value");
       // var effcDate = component.find('Effective_Date__c').get("v.value");
        action.setParams({ idLst: component.get("v.selectedRows"), fieldVal:accDeactiveReason, accountID: component.get("v.AccId"),caseID : component.get("v.CaseId")});
        action.setCallback(this, function(response){
            var state = response.getState();
            if (state === "SUCCESS") {
              // this.showToast(event, 'Success', 'Update Successful');
              // this.closeModal(event);
               component.set("v.showErrorMessage",true);
               component.set("v.successMessage",true);
               component.set("v.ErrorMessage", 'Success! Update Successful');
           }
        });
        $A.enqueueAction(action);
    },
    showToast : function(event, type, message) {
       var toastEvent = $A.get("e.force:showToast");
       toastEvent.setParams({
           "title": type,
           "type": type,
           "message": message
       });
       toastEvent.fire();
   },
    renderSubmitButton : function(component, event, helper) {
           //var deactivationReason = component.find('Account_Deactivation_Reason__c').get("v.value");
           //var effectiveDate = component.find('Effective_Date__c').get("v.value");
           var rowIdList = component.get("v.selectedRows");
           var submitButton= component.find('Submit Button');
           if(rowIdList.length>0 /*&& deactivationReason*/){
               submitButton.set("v.disabled",false);
           }
        else{
            submitButton.set("v.disabled",true);
        }
    },
   closeModal : function(event){
       var dismissActionPanel = $A.get("e.force:closeQuickAction");
       dismissActionPanel.fire();
   }
})