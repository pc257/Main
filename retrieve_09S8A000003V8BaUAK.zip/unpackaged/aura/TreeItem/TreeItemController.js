({
    doInit : function(component, event, helper) {
        console.log('----Item Controller 1 doInit-----');
        var action = component.get("c.getAccounts");
        console.log('----get Item record ID--'+component.get("v.record.Id"));
        action.setParams({"parentId":component.get("v.record.Id")}); 
        action.setCallback(this, function(response) {
            var state = response.getState();
            console.log('--Item getAccounts Value---'+(JSON.stringify(response.getReturnValue())));
            if (state === "SUCCESS") {
                var retVal=response.getReturnValue();
                
                component.set("v.records",retVal);
                console.log('----set Item record ID--'+JSON.stringify(retVal));
            }
        });
        $A.enqueueAction(action);	
        
    }
})