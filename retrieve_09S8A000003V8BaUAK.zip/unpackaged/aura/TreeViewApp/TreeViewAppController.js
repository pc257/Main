({
    doInit : function(component, event, helper) {
        console.log('----Application Controller 1 doInit-----');
        var action = component.get("c.getRootParentAccount");
        action.setParams({"recordId":component.get("v.current")});
        action.setCallback(this, function(response) {
            var state = response.getState();
            //alert(JSON.stringify(response.getReturnValue())); 
            var retVal=response.getReturnValue();
            console.log('--Application retVal 1----'+(JSON.stringify(response.getReturnValue())));
            console.log('--Application retVal 2----'+retVal);
            console.log('--Application retVal ParentId----'+retVal.ParentId);
            if (state === "SUCCESS") {
                if(!retVal.ParentId){
                component.set("v.record",retVal);
                }
                else{
                action.setParams({"recordId":retVal.ParentId});
                console.log('--Application retVal ParentId in else----'+retVal.ParentId);
                $A.enqueueAction(action);   
                }
            }
        });
        $A.enqueueAction(action);	
    }
})