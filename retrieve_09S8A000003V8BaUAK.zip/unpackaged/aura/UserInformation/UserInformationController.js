({
    handleSubmit : function(cmp, event, helper) {
        //alert(event);
    },
    handleOnLoad : function(cmp, event, helper){
        alert('its loaded');
    }
})