({
	closeModel : function(component, event, helper) {
        component.set("v.isModalOpen",false);
	}
    
})