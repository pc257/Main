({
	doInit : function(component, event, helper) {
		var pageNumber = component.get("v.PageNumber");
        console.log("pn "+pageNumber);
        var pageSize = component.get("v.PageSize");
        console.log("ps "+pageSize);
        helper.getAccountData(component,pageNumber,pageSize);        
    },
    handleNext : function(component,event,helper){
        var pageNumber = component.get("v.PageNumber");  
        var pageSize = component.get("v.PageSize");
        pageNumber++;
        helper.getAccountData(component, pageNumber, pageSize);
    },
    handlePrev: function(component, event, helper) {
        var pageNumber = component.get("v.PageNumber");  
        var pageSize = component.get("v.PageSize");
        pageNumber--;
        helper.getAccountData(component, pageNumber, pageSize);
    },
})