({
	getAccountData : function(component , pageNumber , pageSize) {
		var action = component.get("c.fetchAccountRecords");
        var parentIdValue = component.get("v.parentIdVal");
        action.setParams({
            "pNumber" : pageNumber,
            "pSize" : pageSize,
            "parentIdValue" : parentIdValue
        });
        action.setCallback(this,function(response){
  			var state = response.getState();
        if(component.isValid() && state === "SUCCESS"){
            var resultData = response.getReturnValue();
            component.set("v.PageNumber", resultData.pageNumber);
            component.set("v.TotalRecords", resultData.totalRecords);
            console.log('totl recs '+resultData.totalRecords);
            component.set("v.RecordStart", resultData.recordStart);
            component.set("v.RecordEnd", resultData.recordEnd);
            component.set("v.TotalPages", Math.ceil(resultData.totalRecords / resultData.pageSize));
            var acctListVal = resultData.accountList;
            for(var i=0 ; i < acctListVal.length ; i++){
                var cmpltedFrms = acctListVal[i].of_Completed_Forms__c;
                var ttlOnbFrms = acctListVal[i].Total_Onboarding_Forms__c;
                if(ttlOnbFrms > 0){
                    var progress = (cmpltedFrms/ttlOnbFrms)*100;
                    if(progress == 0){
                        acctListVal[i].Progress__c = '0';
                    }
                    else if(progress <=20){
                            console.log('prg 20');
                            acctListVal[i].Progress__c = '20';
                        }
                        else if(progress <=40){
                            console.log('prg 40');
                            acctListVal[i].Progress__c = '40';
                        }
                        else if(progress <=60){
                            console.log('prg 60');
                            acctListVal[i].Progress__c = '60';
                        }
                        else if(progress <=99){
                            console.log('prg 80');
                            acctListVal[i].Progress__c = '80';
                        }
                        else if(progress == 100){
                            console.log('prg 100');
                            acctListVal[i].Progress__c = '100';
                        }
                }
                else{
                        console.log('onb not started');
                        acctListVal.Progress__c = 'Onboarding Not started';
                    }
            }
            component.set("v.allAccounts", acctListVal);            
        }                          
        });
        $A.enqueueAction(action);
	}
})