({
    doInit : function(component, event, helper){
        helper.loadRecordType(component);
        helper.getTypePicklist(component, event);
        helper.getSubTypePicklist(component, event);
        helper.loadEventRecordType(component, event);
        helper.getEventTypePicklist(component, event);
        var controllingFieldAPI = component.get("v.controllingFieldAPI");
        var dependingFieldAPI = component.get("v.dependingFieldAPI");
        var objDetails = component.get("v.objDetail");
        // call the helper function
        
        // Commented below line for CRM: 30541.
        // We don't have : component.get("c.getDependentMap"); in the Apex Class.
        //helper.fetchPicklistValues(component,objDetails,controllingFieldAPI, dependingFieldAPI);
    },
    handleClick : function(component, event, helper){
        helper.loadAllData(component);
    },
    handleSelect : function(component, event, helper) {
        var allrec = component.get("v.allrec");
        var allRecList = component.get("v.allRecList");
        var selected = event.getSource().get("v.value");
        if(selected == "Event"){
            component.set("v.selRecTy",'');
        }
        component.set("v.selected",selected);
    },
    getRecType : function(component, event, helper) {
        var recType = event.getSource().get("v.value");
        component.set("v.selRecTy",recType);
    },
    handleType : function(component, event, helper) {
        var rType = event.getSource().get("v.value");
        component.set("v.selType",rType);
    },
    handleTypeOnChange : function(component, event, helper) {
        var taskType = component.get("v.acc.Type");
        component.set("v.selType",taskType);
    },
    handleSubTypeOnChange : function(component, event, helper) {
        var indutry1 = component.get("v.acc.SubType__c");
        component.set("v.selRecTy",indutry1);
    },
    getRecordType : function(component, event, helper) {
        var recType1 = event.getSource().get("v.value");
        component.set("v.selRecordType",recType1);
    },
    getEventRecordType : function(component, event, helper) {
        var recType2 = event.getSource().get("v.value");
        component.set("v.selRecordType",recType2);
    },
    handleEventTypeOnChange : function(component, event, helper) {
        var eventType = component.get("v.eve.Type");
        component.set("v.selType",eventType);
    },
    onControllerFieldChange: function(component, event, helper) {     
        var controllerValueKey = event.getSource().get("v.value"); // get selected controller field value
        var depnedentFieldMap = component.get("v.depnedentFieldMap");
        alert('************');
        if (controllerValueKey != '--- None ---') {
            var ListOfDependentFields = depnedentFieldMap[controllerValueKey];
            
            if(ListOfDependentFields.length > 0){
                component.set("v.bDisabledDependentFld" , false);  
                helper.fetchDepValues(component, ListOfDependentFields);    
            }else{
                component.set("v.bDisabledDependentFld" , true); 
                component.set("v.listDependingValues", ['--- None ---']);
            }  
            
        } else {
            component.set("v.listDependingValues", ['--- None ---']);
            component.set("v.bDisabledDependentFld" , true);
        }
    }
})