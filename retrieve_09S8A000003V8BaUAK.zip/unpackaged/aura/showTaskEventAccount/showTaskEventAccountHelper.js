({
    loadRecordType : function(component){
        var action = component.get("c.getRecordTypes");
        action.setCallback(this,function(response){
            var state = response.getState();
            var newlst =[];
            console.log('response*****' ,response.getReturnValue())
            if (state === "SUCCESS") {
                component.set("v.RecTypes", response.getReturnValue());
            }
        });
        $A.enqueueAction(action);
    },
    loadEventRecordType : function(component){
        var actionEvent = component.get("c.getTaskSubTypeRecordTypes");
        actionEvent.setCallback(this,function(response){
            var eventState = response.getState();
            var newlst =[];
            if (eventState === "SUCCESS") {
                component.set("v.RecEvent", response.getReturnValue());
            }
        });
        $A.enqueueAction(actionEvent);
    },
   loadTask : function(component){
        var action = component.get("c.getTask");
        action.setCallback(this, function(response) {
            var state = response.getState();
            if (state === "SUCCESS") {
                component.set("v.taskRecs", response.getReturnValue());
                component.set("v.TaskList", response.getReturnValue());
            }
            // Display toast message to indicate load status
            var toastEvent = $A.get("e.force:showToast");
            if (state === 'SUCCESS'){
                toastEvent.setParams({
                    "title": "Success!",
                    "message": " Your contacts have been loaded successfully."
                });
            }
            else {
                toastEvent.setParams({
                    "title": "Error!",
                    "message": " Something has gone wrong."
                });
            }
            toastEvent.fire();
        });
        $A.enqueueAction(action);
    },
    loadAllData : function(component){
        var selectval = component.get("v.selected");
        var action = component.get("c.getAllRecords");
        action.setParams({
            "type" : selectval,
            "recId": component.get("v.recordId"),
            "recType": component.get("v.selRecTy"),
            "rType": component.get("v.selType"),
            "recordType":component.get("v.selRecordType")
        });
        action.setCallback(this, function(response) {
            var state = response.getState();
            if (state === "SUCCESS") {
                component.set("v.allrec", response.getReturnValue());
                component.set("v.allRecList", response.getReturnValue());
            }
        });
        $A.enqueueAction(action);
    },
    getTypePicklist: function(component, event) {
        var action = component.get("c.getTaskType");
        action.setCallback(this, function(response) {
            var state = response.getState();
            if (state === "SUCCESS") {
                var result = response.getReturnValue();
                var typeMap = [];
                for(var key in result){
                    typeMap.push({key: key, value: result[key]});
                }
                component.set("v.typeMap", typeMap);
            }
        });
        $A.enqueueAction(action);
    },
     getSubTypePicklist: function(component, event) {
        var action = component.get("c.getTaskSubType");
        action.setCallback(this, function(response) {
            var state1 = response.getState();
            if (state1 === "SUCCESS") {
                var resultSubType = response.getReturnValue();
                var subTypeMap = [];
                for(var key1 in resultSubType){
                    subTypeMap.push({key1: key1, value1: resultSubType[key1]});
                }
                component.set("v.subTypeMap", subTypeMap);
            }
        });
        $A.enqueueAction(action);
    },
    getEventTypePicklist: function(component, event) {
        var action = component.get("c.getEventType");
        action.setCallback(this, function(response) {
            var state = response.getState();
            if (state === "SUCCESS") {
                var result = response.getReturnValue();
                var eventMap = [];
                for(var key in result){
                    eventMap.push({key: key, value: result[key]});
                }
                component.set("v.eventMap", eventMap);
            }
        });
        $A.enqueueAction(action);
    },
    fetchPicklistValues: function(component,objDetails,controllerField, dependentField) {
        // call the server side function  
        var action = component.get("c.getDependentMap");
        // pass paramerters [object definition , contrller field name ,dependent field name] -
        // to server side function 
        action.setParams({
            'objDetail' : objDetails,
            'contrfieldApiName': controllerField,
            'depfieldApiName': dependentField 
        });
        //set callback   
        action.setCallback(this, function(response) {
            if (response.getState() == "SUCCESS") {
                //store the return response from server (map<string,List<string>>)  
                var StoreResponse = response.getReturnValue();
                
                // once set #StoreResponse to depnedentFieldMap attribute 
                component.set("v.depnedentFieldMap",StoreResponse);
                
                // create a empty array for store map keys(@@--->which is controller picklist values) 
                var listOfkeys = []; // for store all map keys (controller picklist values)
                var ControllerField = []; // for store controller picklist value to set on lightning:select. 
                
                // play a for loop on Return map 
                // and fill the all map key on listOfkeys variable.
                for (var singlekey in StoreResponse) {
                    listOfkeys.push(singlekey);
                }
                
                //set the controller field value for lightning:select
                if (listOfkeys != undefined && listOfkeys.length > 0) {
                    ControllerField.push('--- None ---');
                }
                
                for (var i = 0; i < listOfkeys.length; i++) {
                    ControllerField.push(listOfkeys[i]);
                }  
                // set the ControllerField variable values to country(controller picklist field)
                component.set("v.listControllingValues", ControllerField);
            }else{
                alert('Something went wrong..');
            }
        });
        $A.enqueueAction(action);
    },
    
    fetchDepValues: function(component, ListOfDependentFields) {
        // create a empty array var for store dependent picklist values for controller field  
        var dependentFields = [];
        dependentFields.push('--- None ---');
        for (var i = 0; i < ListOfDependentFields.length; i++) {
            dependentFields.push(ListOfDependentFields[i]);
        }
        // set the dependentFields variable values to store(dependent picklist field) on lightning:select
        component.set("v.listDependingValues", dependentFields);
        
    }
})