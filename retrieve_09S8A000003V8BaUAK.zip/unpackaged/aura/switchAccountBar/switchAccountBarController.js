({	
    doInit: function(cmp, event, helper) {
        var accName = cmp.get('v.accountName');
        var responseValue = [];
        //alert(accName);
        if(accName == null || accName == undefined){
            var action = cmp.get("c.getAccountDetails");
            action.setCallback(this, function(response) {
                var state = response.getState();
                //alert('state---'+state);
                if (state === "SUCCESS"){
                    responseValue = response.getReturnValue();
                    //alert(responseValue.length);
                    cmp.set('v.recordID', responseValue[0].Account__c);
                    cmp.set('v.accountName', responseValue[0].Account__r.Name);
                    cmp.set('v.accountNumber', responseValue[0].Account__r.SAP_ECC_ID__c);
                    
                }
            });
            $A.enqueueAction(action);
        }
        //var accNumber = cmp.get();
    },
    goToAccountsPage : function (component, event, helper){
        //alert("Back Selected---"+component.get("v.accountNumber"));
        var vfUrl = '/switchaccount';
        var urlEvent = $A.get("e.force:navigateToURL");
        urlEvent.setParams({
            "url": vfUrl
        });
        urlEvent.fire();
    },
    goToAccount : function (component, event, helper){
        //alert("Clicked URL---"+component.get("v.recordID"));
        var redirectUrl = component.get("v.recordID"); 
        var vfUrl = '/detail/'+redirectUrl;
        var urlEvent = $A.get("e.force:navigateToURL");
        urlEvent.setParams({
            "url": vfUrl 
        });
        urlEvent.fire();
    },
})