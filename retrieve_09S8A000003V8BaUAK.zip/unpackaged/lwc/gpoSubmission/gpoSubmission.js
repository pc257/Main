import { LightningElement } from 'lwc';

export default class GpoSubmission extends LightningElement {}