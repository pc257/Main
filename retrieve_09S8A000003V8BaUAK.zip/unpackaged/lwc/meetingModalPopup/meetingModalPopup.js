import {
    LightningElement,
    api,
    track,
    wire
} from 'lwc';
import {
    getPicklistValuesByRecordType
} from 'lightning/uiObjectInfoApi';
import {
    getObjectInfo
} from 'lightning/uiObjectInfoApi';
import AccessDates_OBJECT from '@salesforce/schema/GPO_LPP_Access_Date__c';

export default class MeetingModalPopup extends LightningElement {
    @api isModalOpen = false;
    @api compno;
    @api finalobjlist;
    @api ischecked;
    @api gpoaccessdates;
    @api meetingwrapper;
    @api wrapperObj = {};
    @track controllingValues = [];
    @track dependentValues = [];
    @track projectorSiteValues = [];
    @track screenSiteValues = [];

    @track selectedCountry;
    @track selectedState;
    @track isEmpty = false;
    @track error;
    controlValues;
    totalDependentValues = [];


    @track firstname;
    @track lastname;
    @track title;
    @track email1;
    @track phone1;
    @track altfirstname;
    @track altlastname;
    @track alttitle;
    @track altemail;
    @track altphone;
    @track practiceNotes;
    @track offSite;
    @track ippPracticeAddress;
    @track Additionalstaff;
    @track AdditionalHCP;
    @track Physicians;



    @wire(getObjectInfo, {
        objectApiName: AccessDates_OBJECT
    })
    objectInfo;

    @wire(getPicklistValuesByRecordType, {
        objectApiName: AccessDates_OBJECT,
        recordTypeId: '$objectInfo.data.defaultRecordTypeId'
    })
    countryPicklistValues({
        error,
        data
    }) {
        if (data) {
            this.error = null;
            let projectorSiteOptions = [{
                label: '--None--',
                value: '--None--'
            }];
            data.picklistFieldValues.Projector_on_site__c.values.forEach(key => {
                projectorSiteOptions.push({
                    label: key.label,
                    value: key.value
                })
            });
            this.projectorSiteValues = projectorSiteOptions;
            let screenSiteOptions = [{
                label: '--None--',
                value: '--None--'
            }];
            data.picklistFieldValues.Screen_on_site__c.values.forEach(key => {
                screenSiteOptions.push({
                    label: key.label,
                    value: key.value
                })
            });
            this.screenSiteValues = screenSiteOptions;

            let LocationPref = [{
                label: '--None--',
                value: '--None--'
            }];
            data.picklistFieldValues.Location_Preference__c.values.forEach(key => {
                LocationPref.push({
                    label: key.label,
                    value: key.value
                })
            });
            this.controllingValues = LocationPref;

            let pharmaMeals = [{
                label: '--None--',
                value: '--None--'
            }];
            this.controlValues = data.picklistFieldValues.PharmaMeals__c.controllerValues;
            this.totalDependentValues = data.picklistFieldValues.PharmaMeals__c.values;
            this.totalDependentValues.forEach(key => {
                pharmaMeals.push({
                    label: key.label,
                    value: key.value
                })
            });

            this.dependentValues = pharmaMeals;

        } else if (error) {
            this.error = JSON.stringify(error);
        }
    }


    handleCountryChange(event) {
        console.log('picklist change');
        this.selectedCountry = event.target.value;
        this.isEmpty = false;
        let dependValues = [];

        if (this.selectedCountry) {
            // if Selected country is none returns nothing
            if (this.selectedCountry === '--None--') {
                this.isEmpty = true;
                dependValues = [{
                    label: '--None--',
                    value: '--None--'
                }];
                this.selectedCountry = null;
                this.selectedState = null;
                return;
            }

            this.totalDependentValues.forEach(conValues => {

                conValues.validFor.forEach(validFor => {

                    if (validFor === this.controlValues[this.selectedCountry]) {
                        dependValues.push({
                            label: conValues.label,
                            value: conValues.value
                        })
                    }

                })

            })


            this.dependentValues = dependValues;
        }
    }
    connectedCallback() {

        this.isEmpty = true;
        this.dependentValues = [{
            label: '--None--',
            value: '--None--'
        }];
        console.log('finalobjlist' + JSON.stringify(this.finalobjlist));
        let finalobjlst = JSON.parse(JSON.stringify(this.finalobjlist));
        if (finalobjlst) {
            for (var i = 0; i < finalobjlst.length; i++) {

                if (this.compno == finalobjlst[i].compno) {
                    this.selectedCountry = finalobjlst[i].selectedCountry;
                    if (finalobjlst[i].selectedCountry != null && finalobjlst[i].selectedCountry != '--Select--') {
                        this.isEmpty = false;
                    }
                    this.selectedState = finalobjlst[i].selectedState;
                    this.selectedProjectorSite = finalobjlst[i].selectedProjectorSite;
                    this.selectedScreenSite = finalobjlst[i].selectedScreenSite;
                    this.firstname = finalobjlst[i].firstname;
                    this.lastname = finalobjlst[i].lastname;
                    this.title = finalobjlst[i].title;
                    this.email1 = finalobjlst[i].email1;
                    this.phone1 = finalobjlst[i].phone1;
                    this.altfirstname = finalobjlst[i].altfirstname;
                    this.altlastname = finalobjlst[i].altlastname;
                    this.alttitle = finalobjlst[i].alttitle;
                    this.altemail = finalobjlst[i].altemail;
                    this.altphone = finalobjlst[i].altphone;
                    this.Physicians = finalobjlst[i].Physicians;
                    this.AdditionalHCP = finalobjlst[i].AdditionalHCP;
                    this.Additionalstaff = finalobjlst[i].Additionalstaff;
                    this.ippPracticeAddress = finalobjlst[i].ippPracticeAddress;
                    this.offSite = finalobjlst[i].offSite;
                    this.practiceNotes = finalobjlst[i].practiceNotes;
                }
            }
        }
    }
    closeModal() {
        let isError = this.getinputval();
        console.log('isError' + isError);
        if (!isError) {
            this.isModalOpen = false;
            this.wrapperObj = {
                firstname: this.firstname ? this.firstname : '',
                lastname: this.lastname ? this.lastname : '',
                title: this.title ? this.title : '',
                email1: this.email1 ? this.email1 : '',
                phone1: this.phone1 ? this.phone1 : '',
                altfirstname: this.altfirstname ? this.altfirstname : '',
                altlastname: this.altlastname ? this.altlastname : '',
                alttitle: this.alttitle ? this.alttitle : '',
                altemail: this.altemail ? this.altemail : '',
                altphone: this.altphone ? this.altphone : '',
                Physicians: this.Physicians ? this.Physicians : '',
                AdditionalHCP: this.AdditionalHCP ? this.AdditionalHCP : '',
                Additionalstaff: this.Additionalstaff ? this.Additionalstaff : '',
                ippPracticeAddress: this.ippPracticeAddress ? this.ippPracticeAddress : '',
                offSite: this.offSite ? this.offSite : '',
                practiceNotes: this.practiceNotes ? this.practiceNotes : '',
                selectedCountry: this.selectedCountry ? this.selectedCountry : null,
                selectedState: this.selectedState ? this.selectedState : null,
                selectedProjectorSite: this.selectedProjectorSite ? this.selectedProjectorSite : null,
                selectedScreenSite: this.selectedScreenSite ? this.selectedScreenSite : null
            }
            const selectedEvent = new CustomEvent("closepopup", {
                detail: {
                    isModalOpen: this.isModalOpen,
                    wrapperObj: this.wrapperObj
                }
            });
            this.dispatchEvent(selectedEvent);
        }

    }

    firstnameChange(event) {
        this.firstname = event.target.value;
    }
    lastnameChange(event) {
        this.lastname = event.target.value;
    }
    titleChange(event) {
        this.title = event.target.value;
    }
    email1Change(event) {
        this.email1 = event.target.value;
    }
    phone1Change(event) {
        this.phone1 = event.target.value;
    }
    altfirstnameChange(event) {
        this.altfirstname = event.target.value;
    }
    altlastnameChange(event) {
        this.altlastname = event.target.value;
    }
    alttitleChange(event) {
        this.alttitle = event.target.value;
    }
    altemailChange(event) {
        this.altemail = event.target.value;
    }
    altphoneChange(event) {
        this.altphone = event.target.value;
    }
    PhysiciansChange(event) {
        this.Physicians = event.target.value;
    }
    AdditionalHCPChange(event) {
        this.AdditionalHCP = event.target.value;
    }
    AdditionastaffChange(event) {
        this.Additionalstaff = event.target.value;
    }
    ippPracticeAddressChange(event) {
        this.ippPracticeAddress = event.target.value;
    }
    offSiteChange(event) {
        this.offSite = event.target.value;
    }
    practiceNotesChange(event) {
        this.practiceNotes = event.target.value;
    }
    handleMealChange(event) {
        this.selectedState = event.target.value;
    }
    projectorSiteChange(event) {
        this.selectedProjectorSite = event.target.value;
    }
    screenSiteValuesChange(event) {
        this.selectedScreenSite = event.target.value;
    }
    getinputval() {
        let showValidationError = false;
        let physiciansCmp = this.template.querySelector(".physiciansCmp");
        let hcpCmp = this.template.querySelector(".hcpCmp");
        let staffCmp = this.template.querySelector(".staffCmp");
        let locationCmp = this.template.querySelector(".locationCmp");
        let mealCmp = this.template.querySelector(".mealCmp");
        let ippCmp = this.template.querySelector(".ippCmp");
        let offsiteCmp = this.template.querySelector(".offsiteCmp");
        let projCmp = this.template.querySelector(".projCmp");
        let screenCmp = this.template.querySelector(".screenCmp");
        let practiceCmp = this.template.querySelector(".practiceCmp");
        let ippEmailCmp = this.template.querySelector(".ippEmailCmp");
        let altEmailCmp = this.template.querySelector(".altEmailCmp");
        let ippPhoneCmp = this.template.querySelector(".ippPhoneCmp");
        let altPhoneCmp = this.template.querySelector(".altPhoneCmp");
        let fnameCmp = this.template.querySelector(".fnameCmp");
        let lnameCmp = this.template.querySelector(".lnameCmp");
        let titleCmp = this.template.querySelector(".titleCmp");
        let fname = this.firstname;
        let lname = this.lastname;
        let ippTitle = this.title;
        let physiciansVal = this.Physicians;
        let hcpval = this.AdditionalHCP;
        let staffVal = this.Additionalstaff;
        let locationVal = this.selectedCountry;
        let mealVal = this.selectedState;
        let ippVal = this.ippPracticeAddress;
        let offsiteVal = this.offSite;
        let projVal = this.selectedProjectorSite
        let screenVal = this.selectedScreenSite;
        let practiceVal = this.practiceNotes;
        let emailVal = this.email1;
        let altemailVal = this.altemail;
        let phoneVal = this.phone1;
        let altPhoneVal = this.altphone;
        var regExpEmailformat = /^(([^<>()\[\]\\.,;:\s@"]+(\.[^<>()\[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;
        var numbersReg = /^[0-9]+$/;
        if (emailVal) {
            if (emailVal.match(regExpEmailformat)) {
                ippEmailCmp.setCustomValidity("");
            } else {
                ippEmailCmp.setCustomValidity("IPP Contact Email: Please Enter a Valid Email Address");
                showValidationError = true;
            }
            ippEmailCmp.reportValidity();
        } else {
            ippEmailCmp.setCustomValidity("IPP Contact: Email is required");
            showValidationError = true;
            ippEmailCmp.reportValidity();
        }
        if (altemailVal) {
            if (altemailVal.match(regExpEmailformat)) {
                altEmailCmp.setCustomValidity("");
            } else {
                altEmailCmp.setCustomValidity("Alternative IPP Contact Email: Please Enter a Valid Email Address");
                showValidationError = true;
            }
            altEmailCmp.reportValidity();
        }
        else
        {
            altEmailCmp.setCustomValidity("");
            altEmailCmp.reportValidity();
        }
        if (phoneVal) {
            if (phoneVal.length == 10 && phoneVal.match(numbersReg)) {
                ippPhoneCmp.setCustomValidity("");
            } else {
                ippPhoneCmp.setCustomValidity("IPP Contact phone: Please Enter a Valid 10 digit Phone Number");
                showValidationError = true;
            }
            ippPhoneCmp.reportValidity();
        } else {
            ippPhoneCmp.setCustomValidity("IPP Contact : phone is required");
            showValidationError = true;
            ippPhoneCmp.reportValidity();
        }
        if (altPhoneVal) {
            if (altPhoneVal.length == 10 && altPhoneVal.match(numbersReg)) {
                altPhoneCmp.setCustomValidity("");
            } else {
                altPhoneCmp.setCustomValidity("Alternative IPP Contact Phone: Please Enter a Valid 10 digit Phone Number");
                showValidationError = true;
            }
            altPhoneCmp.reportValidity();
        }
        else{
            altPhoneCmp.setCustomValidity("");
            altPhoneCmp.reportValidity();
        }

        if (!physiciansVal || physiciansVal == '') {
            physiciansCmp.setCustomValidity("# Physicians: value is required");
            showValidationError = true;
        } else {
            physiciansCmp.setCustomValidity(""); // clear previous value
        }
        physiciansCmp.reportValidity();
        if (!hcpval || hcpval == '') {
            hcpCmp.setCustomValidity("# Additional HCPs (RNs, NPs, PAs, CPHTs, Pharm Ds): value is required");
            showValidationError = true;
        } else {
            hcpCmp.setCustomValidity(""); // clear previous value
        }
        hcpCmp.reportValidity();
        if (!staffVal || staffVal == '') {
            staffCmp.setCustomValidity("# Additional Office Staff: value is required");
            showValidationError = true;
        } else {
            staffCmp.setCustomValidity(""); // clear previous value
        }
        staffCmp.reportValidity();
        if (!locationVal || locationVal == null) {
            locationCmp.setCustomValidity("Meeting Location Preference: value is required");
            showValidationError = true;
        } else {
            locationCmp.setCustomValidity(""); // clear previous value
        }
        locationCmp.reportValidity();
        if (!mealVal || mealVal == null) {
            mealCmp.setCustomValidity("Would you like for the sponsoring pharma company to provide meals for the attendees?: value is required");
            showValidationError = true;
        } else {
            mealCmp.setCustomValidity(""); // clear previous value
        }
        mealCmp.reportValidity();
        if (!ippVal || ippVal == '') {
            ippCmp.setCustomValidity("IPP/Practice Address: value is required");
            showValidationError = true;
        } else {
            ippCmp.setCustomValidity(""); // clear previous value
        }
        ippCmp.reportValidity();
        if (!offsiteVal || offsiteVal == '') {
            offsiteCmp.setCustomValidity("Off-site venue/caterer preferences: value is required");
            showValidationError = true;
        } else {
            offsiteCmp.setCustomValidity(""); // clear previous value
        }
        offsiteCmp.reportValidity();
        if (!projVal || projVal == null || projVal == '--None--') {
            projCmp.setCustomValidity("Do you have a Projector on site?: value is required");
            showValidationError = true;
        } else {
            projCmp.setCustomValidity(""); // clear previous value
        }
        projCmp.reportValidity();
        if (!screenVal || screenVal == null || screenVal == '--None--') {
            screenCmp.setCustomValidity("Do you have a Screen on site?: value is required");
            showValidationError = true;
        } else {
            screenCmp.setCustomValidity(""); // clear previous value
        }
        screenCmp.reportValidity();
        if (!practiceVal || practiceVal == '') {
            practiceCmp.setCustomValidity("Practice Notes/Special Requirements: value is required");
            showValidationError = true;
        } else {
            practiceCmp.setCustomValidity(""); // clear previous value
        }
        practiceCmp.reportValidity();
        if (!fname || fname == '') {
            fnameCmp.setCustomValidity("IPP Contact: First name is required");
            showValidationError = true;
        } else {
            fnameCmp.setCustomValidity(""); // clear previous value
        }
        fnameCmp.reportValidity();
        if (!fname || fname == '') {
            fnameCmp.setCustomValidity("IPP Contact: First name is required");
            showValidationError = true;
        } else {
            fnameCmp.setCustomValidity(""); // clear previous value
        }
        fnameCmp.reportValidity();
        if (!lname || lname == '') {
            lnameCmp.setCustomValidity("IPP Contact: last name is required");
            showValidationError = true;
        } else {
            lnameCmp.setCustomValidity(""); // clear previous value
        }
        lnameCmp.reportValidity();

        if (!ippTitle || ippTitle == '') {
            titleCmp.setCustomValidity("IPP Title: Title is required");
            showValidationError = true;
        } else {
            titleCmp.setCustomValidity(""); // clear previous value
        }
        titleCmp.reportValidity();
        return showValidationError;
    }
}