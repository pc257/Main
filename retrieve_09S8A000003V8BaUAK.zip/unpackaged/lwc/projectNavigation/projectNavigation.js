/* eslint-disable @lwc/lwc/no-async-operation */
/* eslint-disable no-console */
import { LightningElement, api, track } from 'lwc'
import { ShowToastEvent } from 'lightning/platformShowToastEvent'
import { NavigationMixin } from 'lightning/navigation'
import GET_PROJECT_ID from '@salesforce/apex/ProjectNavigationService.getProjectId'
const DELAY = 1000
export default class ProjectNavigation extends NavigationMixin(LightningElement) {
	@api recordId // CURRENT RECORD ID
	@api objectApiName // CURRENT RECORD OBJECT TYPE
	@track parentProjectId // TRACKING PARENT PROJECT ID TO RENDER PATH ACCORDINGLY
	constructor() {
		super()
		this.toastTitle = 'Warning!'
		this.toastMessage = 'Project Navigation Warning!'
		this.toastVariant = 'warning'
	}
	renderedCallback() {
		GET_PROJECT_ID({ recordId: this.recordId })
			.then((result) => {
				this.parentProjectId = result
			})
			.catch(error => {
				this.toastMessage = `Error received: code ${error.errorCode}, message: ${error.body.message}.`
				this.fireToastAlert()
			})
	}
	fireToastAlert() {
		const toast = new ShowToastEvent({
			title: this.toastTitle,
			message: this.toastMessage,
			variant: this.toastVariant,
		})
		this.dispatchEvent(toast)
	}
	handleNavigation(event) {
		const pathButton = this.getTargetListItem(event)
		const tabName = this.formatElementId(pathButton.id)
		this.runAnimation(pathButton)
		setTimeout(() => {
			this.navigateToProject(tabName)
		}, DELAY)
	}
	getTargetListItem(event) {
		let li = event.target
		while (!li.classList.contains('slds-path__item')) li = li.parentElement
		return li
	}
	formatElementId(elementId) {
		return elementId.split('-')[0].toLowerCase()
	}
	runAnimation(pathButton) {
		pathButton.classList.add('pathItemFlip')
		setTimeout(() => {
			pathButton.classList.remove('pathItemFlip')
		}, DELAY)
	}
	navigateToProject(tabName) {
		if (this.parentProjectId !== undefined) {
			this[NavigationMixin.Navigate]({
				type: 'standard__webPage',
				attributes: {
					url: `/apex/project_cloud__projects_app?id=${this.parentProjectId}#/view/${this.parentProjectId}/${tabName}`
				}
			}, true)
		} else {
			this.toastMessage = `Make sure there is a Cloud Coach Project related to this record!`
			this.fireToastAlert()
		}
	}
}