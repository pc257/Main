import { LightningElement } from 'lwc';

export default class SampleWebComponent extends LightningElement {}